import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";

/** ——— Fallback local (por si Base44 no responde) ——— */
const LOCAL_USERS = [
  { id: "1", full_name: "Yuka",    role: "admin",      pin: "1111", active: true },
  { id: "2", full_name: "Tiffany", role: "service",    pin: "1234", active: true },
  { id: "3", full_name: "Francis", role: "technician", pin: "3407", active: true },
];

const brand = {
  bg: "bg-[#0B0B0F]",
  panel: "bg-[#121218]",
  key: "bg-[#1A1A22]",
  red: "bg-red-600 hover:bg-red-700",
  text: "text-slate-200",
  sub: "text-slate-400",
};

const Dot = ({ filled }) => (
  <span className={`inline-block w-2.5 h-2.5 rounded-full ${filled ? "bg-slate-200" : "bg-slate-700"}`} />
);

export default function PinAuthOverlay({ onAuthSuccess }) {
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [shake, setShake] = useState(false);

  useEffect(() => {
    setPin("");
    setErr("");
  }, []);

  /** ---------- Helpers ---------- */
  const showFail = (message = "PIN inválido o usuario no encontrado.") => {
    setErr(message);
    setShake(true);
    setTimeout(() => setShake(false), 450);
    setTimeout(() => setErr(""), 2000);
    setPin(""); // limpiar PIN automáticamente
  };

  const press = (val) => {
    if (loading) return;

    if (val === "back") {
      setPin((p) => p.slice(0, -1));
      setErr("");
      return;
    }
    if (val === "ok") {
      if (pin.length === 4) void login(pin);
      return;
    }
    // número
    setPin((prev) => {
      const next = (prev + String(val)).slice(0, 4);
      setErr("");
      // Auto-login cuando llega a 4
      if (next.length === 4) {
        setTimeout(() => login(next), 30);
      }
      return next;
    });
  };

  const login = async (p) => {
    if (loading) return;
    setLoading(true);
    try {
      // 1) Intento Base44 con pin string
      let user = null;
      try {
        const r1 = await base44.entities.User.filter({ pin: p, active: true });
        if (Array.isArray(r1) && r1.length) user = r1[0];
        // 2) Si no hubo match, intento con número (algunas bases guardan números)
        if (!user && /^\d+$/.test(p)) {
          const r2 = await base44.entities.User.filter({ pin: Number(p), active: true });
          if (Array.isArray(r2) && r2.length) user = r2[0];
        }
      } catch (e) {
        // cae al fallback local
      }

      // 3) Fallback local
      if (!user) {
        user = LOCAL_USERS.find((u) => String(u.pin) === String(p) && u.active);
      }

      if (!user) {
        showFail();
        return;
      }

      // cachear ponche abierto si existe
      try {
        const open = await base44.entities.TimeEntry.filter({
          employee_id: user.id,
          clock_out: null,
        });
        if (open?.length) {
          sessionStorage.setItem("timeEntryId", open[0].id);
        }
      } catch {}

      const sessionData = {
        userId: user.id,
        userName: user.full_name,
        userRole: user.role,
        authMode: "session",
        sessionStart: new Date().toISOString(),
      };
      sessionStorage.setItem("911-session", JSON.stringify(sessionData));
      onAuthSuccess?.(sessionData);
    } catch (e) {
      console.error("PIN login error:", e);
      showFail("Error de conexión.");
    } finally {
      setLoading(false);
    }
  };

  const Key = ({ label, onClick, disabled }) => (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-20 h-16 rounded-2xl ${brand.key} text-slate-100 text-xl font-semibold shadow-[0_8px_30px_rgb(0,0,0,0.35)] active:scale-95 transition disabled:opacity-40`}
    >
      {label}
    </button>
  );

  return (
    <div className={`fixed inset-0 z-[1000] ${brand.bg} ${brand.text}`}>
      <div className="max-w-3xl mx-auto min-h-screen grid place-items-center px-4">
        <div className={`w-full text-center transition ${shake ? "animate-[shake_0.45s_ease]" : ""}`}>
          <h1 className="text-2xl font-semibold">Acceso a los empleados</h1>
          <p className={`${brand.sub} mt-1`}>Ingrese su PIN de su empleado</p>

          <div className="flex items-center justify-center gap-3 mt-4">
            {[0, 1, 2, 3].map((i) => (
              <Dot key={i} filled={pin.length > i} />
            ))}
          </div>

          {err && <p className="mt-3 text-red-400 text-sm font-medium">{err}</p>}

          <div className="mt-8 grid grid-cols-3 gap-6 place-items-center">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
              <Key key={n} label={n} onClick={() => press(n)} disabled={loading} />
            ))}
            <Key label="←" onClick={() => press("back")} disabled={loading} />
            <Key label={0} onClick={() => press(0)} disabled={loading} />
            <button
              onClick={() => press("ok")}
              disabled={pin.length !== 4 || loading}
              className={`w-20 h-16 rounded-2xl text-white text-base font-semibold shadow-[0_8px_30px_rgba(220,38,38,0.45)] active:scale-95 transition ${brand.red} disabled:opacity-40`}
            >
              {loading ? <Loader2 className="mx-auto animate-spin" /> : "Ingresar"}
            </button>
          </div>
        </div>
      </div>

      {/* animación shake */}
      <style>{`
        @keyframes shake {
          10%, 90% { transform: translateX(-1px); }
          20%, 80% { transform: translateX(2px); }
          30%, 50%, 70% { transform: translateX(-4px); }
          40%, 60% { transform: translateX(4px); }
        }
      `}</style>
    </div>
  );
}