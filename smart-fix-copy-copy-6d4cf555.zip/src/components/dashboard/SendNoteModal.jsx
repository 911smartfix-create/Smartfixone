import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { X, Search } from "lucide-react";

export default function SendNoteModal({ open, onClose, initialText = "" }) {
  const [text, setText] = useState(initialText);
  const [sendToAll, setSendToAll] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [userSearch, setUserSearch] = useState("");
  const [userResults, setUserResults] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setText(initialText);
  }, [initialText]);

  useEffect(() => {
    if (open) {
      setText(initialText);
      setSendToAll(false);
      setSelectedUsers([]);
      setUserSearch("");
      setUserResults([]);
    }
  }, [open, initialText]);

  const searchUsers = async (query) => {
    if (!query.trim()) {
      setUserResults([]);
      return;
    }
    try {
      const users = await base44.entities.User.filter({ active: true });
      const filtered = users.filter(u =>
        (u.full_name || "").toLowerCase().includes(query.toLowerCase()) ||
        (u.email || "").toLowerCase().includes(query.toLowerCase())
      );
      setUserResults(filtered.slice(0, 20));
    } catch {
      setUserResults([]);
    }
  };

  const toggleUser = (user) => {
    const exists = selectedUsers.find(u => u.id === user.id);
    if (exists) {
      setSelectedUsers(selectedUsers.filter(u => u.id !== user.id));
    } else {
      setSelectedUsers([...selectedUsers, user]);
    }
    setUserResults([]);
    setUserSearch("");
  };

  const removeUser = (userId) => {
    setSelectedUsers(selectedUsers.filter(u => u.id !== userId));
  };

  const handleSend = async () => {
    if (!text.trim()) {
      alert("El texto no puede estar vacío");
      return;
    }

    if (!sendToAll && selectedUsers.length === 0) {
      alert("Selecciona al menos un destinatario o marca 'Enviar a todos'");
      return;
    }

    setLoading(true);
    try {
      let me = null;
      try { me = await base44.auth.me(); } catch {}
      
      let recipients = [];
      if (sendToAll) {
        const allUsers = await base44.entities.User.filter({ active: true });
        recipients = allUsers;
      } else {
        recipients = selectedUsers;
      }

      // Crear notificación para cada destinatario
      for (const recipient of recipients) {
        await base44.entities.CommunicationQueue.create({
          type: "in_app",
          user_id: recipient.id,
          subject: "📢 Nota del administrador",
          body_html: text,
          status: "pending",
          meta: {
            source: "dashboard_note",
            audience: sendToAll ? "all" : "targeted",
            recipients_count: recipients.length,
            editor_id: me?.id || null,
            editor_name: me?.full_name || me?.email || "Sistema"
          }
        });
      }

      // Auditar
      await base44.entities.AuditLog.create({
        action: "dashboard_note_send",
        entity_type: "config",
        entity_id: "dashboard_note",
        user_id: me?.id || null,
        user_name: me?.full_name || me?.email || "Sistema",
        user_role: me?.role || "system",
        changes: {
          audience: sendToAll ? "all" : "targeted",
          recipients: recipients.map(r => ({ id: r.id, name: r.full_name || r.email })),
          editor_id: me?.id || null
        }
      });

      onClose({ success: true, count: recipients.length });
    } catch (e) {
      console.error("Error sending note:", e);
      onClose({ success: false, error: e.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => !loading && onClose()}>
      <DialogContent className="max-w-2xl bg-gradient-to-br from-[#2B2B2B] to-black border-red-900/30">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white">📨 Enviar Nota a Usuarios</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-gray-300">Mensaje</Label>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={5}
              className="bg-black/30 text-slate-50 border-white/10"
              placeholder="Escribe el mensaje que quieres enviar..."
            />
          </div>

          <div className="flex items-center space-x-2 p-3 bg-black/30 rounded-lg border border-white/10">
            <Checkbox
              id="sendToAll"
              checked={sendToAll}
              onCheckedChange={setSendToAll}
            />
            <label
              htmlFor="sendToAll"
              className="text-sm text-gray-300 font-medium leading-none cursor-pointer"
            >
              📢 Enviar a todos los usuarios activos
            </label>
          </div>

          {!sendToAll && (
            <div className="space-y-2">
              <Label className="text-gray-300">Destinatarios específicos</Label>
              
              {selectedUsers.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-2 p-2 bg-black/30 rounded-lg border border-white/10">
                  {selectedUsers.map(u => (
                    <div
                      key={u.id}
                      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-600/20 border border-red-600/30 text-red-300 text-sm"
                    >
                      <span>{u.full_name || u.email}</span>
                      <button
                        onClick={() => removeUser(u.id)}
                        className="hover:bg-red-600/40 rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <Input
                  type="text"
                  placeholder="Buscar usuario por nombre o email..."
                  value={userSearch}
                  onChange={(e) => {
                    setUserSearch(e.target.value);
                    searchUsers(e.target.value);
                  }}
                  className="bg-black border-white/15 text-white pl-10"
                />
              </div>

              {userResults.length > 0 && (
                <div className="max-h-40 overflow-y-auto bg-black/60 border border-white/15 rounded-md">
                  {userResults.map(u => (
                    <button
                      key={u.id}
                      onClick={() => toggleUser(u)}
                      disabled={selectedUsers.find(su => su.id === u.id)}
                      className="w-full px-3 py-2 text-left text-sm hover:bg-gray-800 text-white border-b border-white/5 last:border-0 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <div className="font-medium">{u.full_name || u.email}</div>
                      {u.email && u.full_name && (
                        <div className="text-xs text-gray-400">{u.email}</div>
                      )}
                    </button>
                  ))}
                </div>
              )}
              
              {!sendToAll && selectedUsers.length === 0 && (
                <p className="text-xs text-yellow-400 mt-2">
                  💡 Busca y selecciona al menos un usuario para enviarle la nota
                </p>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onClose()}
            disabled={loading}
            className="border-gray-700"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSend}
            disabled={loading || !text.trim() || (!sendToAll && selectedUsers.length === 0)}
            className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700"
          >
            {loading ? "Enviando..." : `📨 Enviar${sendToAll ? ' a Todos' : selectedUsers.length > 0 ? ` (${selectedUsers.length})` : ''}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}