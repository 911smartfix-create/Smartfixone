import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Package, TrendingDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function InventoryAlertsWidget() {
  const [lowStockItems, setLowStockItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadLowStockItems();
    const interval = setInterval(loadLowStockItems, 300000); // Refresh every 5 min
    return () => clearInterval(interval);
  }, []);

  const loadLowStockItems = async () => {
    try {
      const products = await base44.entities.Product.filter({ active: true });
      
      const lowStock = products.filter(p => {
        const stock = p.stock || 0;
        const minStock = p.min_stock || 5;
        return stock <= minStock && stock >= 0;
      }).sort((a, b) => (a.stock || 0) - (b.stock || 0));

      setLowStockItems(lowStock.slice(0, 5)); // Top 5
      setLoading(false);
    } catch (error) {
      console.error("Error loading low stock items:", error);
      setLoading(false);
    }
  };

  const getStockLevel = (stock, minStock) => {
    if (stock === 0) return { label: "Agotado", color: "bg-red-600/20 text-red-300 border-red-600/30" };
    if (stock <= minStock / 2) return { label: "Crítico", color: "bg-orange-600/20 text-orange-300 border-orange-600/30" };
    return { label: "Bajo", color: "bg-yellow-600/20 text-yellow-300 border-yellow-600/30" };
  };

  return (
    <Card className="bg-gradient-to-br from-[#2B2B2B] to-black border-red-900/30 shadow-xl">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Alertas de Inventario
          </CardTitle>
          <Badge className="bg-orange-600/20 text-orange-300 border-orange-600/30">
            {lowStockItems.length}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-32 flex items-center justify-center">
            <div className="animate-spin w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full" />
          </div>
        ) : lowStockItems.length === 0 ? (
          <div className="text-center py-8">
            <Package className="w-12 h-12 mx-auto text-green-600/50 mb-2" />
            <p className="text-sm text-gray-400">Todo el inventario está bien</p>
          </div>
        ) : (
          <div className="space-y-2">
            {lowStockItems.map((item) => {
              const stockLevel = getStockLevel(item.stock, item.min_stock);
              return (
                <div
                  key={item.id}
                  onClick={() => navigate(createPageUrl("Inventory"))}
                  className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition cursor-pointer"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">
                      {item.name}
                    </p>
                    <p className="text-xs text-gray-400 truncate">
                      SKU: {item.sku || "N/A"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 ml-3">
                    <Badge className={stockLevel.color}>
                      {stockLevel.label}
                    </Badge>
                    <span className="text-sm font-bold text-white min-w-[40px] text-right">
                      {item.stock || 0}
                    </span>
                  </div>
                </div>
              );
            })}
            <button
              onClick={() => navigate(createPageUrl("Inventory"))}
              className="w-full mt-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-sm text-gray-300 transition"
            >
              Ver todo el inventario →
            </button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}