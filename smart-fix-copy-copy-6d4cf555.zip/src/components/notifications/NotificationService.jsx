
import { base44 } from "@/api/base44Client";

class NotificationService {
  /**
   * Verifica productos con bajo stock y envía notificaciones
   */
  static async checkAndNotifyLowStock() {
    try {
      // Obtener todos los productos activos
      const products = await base44.entities.Product.filter({ active: true });
      
      // Filtrar productos con bajo stock
      const lowStockProducts = products.filter(p => {
        const stock = Number(p.stock || 0);
        const minStock = Number(p.min_stock || 0);
        return stock > 0 && stock <= minStock;
      });

      if (lowStockProducts.length === 0) {
        return { success: true, count: 0 };
      }

      // Obtener email de alertas del sistema
      let alertEmail = "";
      try {
        const configs = await base44.entities.SystemConfig.filter({ key: "alert_email" });
        if (configs && configs.length > 0) {
          alertEmail = configs[0].value || configs[0].value_json || "";
        }
      } catch (e) {
        console.warn("Could not load alert_email config:", e);
      }

      // Si no hay email configurado, intentar obtener admin
      if (!alertEmail) {
        try {
          const admins = await base44.entities.User.filter({ role: "admin" });
          if (admins && admins.length > 0) {
            alertEmail = admins[0].email;
          }
        } catch (e) {
          console.warn("Could not load admin email:", e);
        }
      }

      if (!alertEmail) {
        console.warn("No alert email configured, skipping low stock notification");
        return { success: false, error: "No alert email configured" };
      }

      // Crear lista HTML de productos
      const productsListHtml = lowStockProducts.map(p => `
        <tr style="border-bottom: 1px solid #eee;">
          <td style="padding: 10px; font-weight: bold;">${p.name}</td>
          <td style="padding: 10px;">${p.sku || "N/A"}</td>
          <td style="padding: 10px; text-align: center; color: ${p.stock <= 0 ? '#dc2626' : '#f59e0b'};">
            <strong>${p.stock}</strong>
          </td>
          <td style="padding: 10px; text-align: center;">${p.min_stock}</td>
          <td style="padding: 10px; text-align: right;">$${Number(p.price || 0).toFixed(2)}</td>
        </tr>
      `).join('');

      const subject = `⚠️ Alerta: ${lowStockProducts.length} productos con bajo stock`;
      const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; }
    .container { max-width: 600px; margin: 20px auto; background: white; border-radius: 10px; overflow: hidden; }
    .header { background: linear-gradient(135deg, #FF0000 0%, #CC0000 100%); padding: 30px; text-align: center; color: white; }
    .content { padding: 30px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th { background-color: #f8f9fa; padding: 12px; text-align: left; border-bottom: 2px solid #dee2e6; }
    .footer { background-color: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1 style="margin: 0; font-size: 24px;">⚠️ Alerta de Inventario</h1>
      <p style="margin: 10px 0 0 0; opacity: 0.9;">911 SmartFix</p>
    </div>
    
    <div class="content">
      <p style="font-size: 16px; color: #333;">
        Se han detectado <strong style="color: #FF0000;">${lowStockProducts.length} productos</strong> 
        con stock bajo o agotado:
      </p>
      
      <table>
        <thead>
          <tr>
            <th>Producto</th>
            <th>SKU</th>
            <th style="text-align: center;">Stock</th>
            <th style="text-align: center;">Mínimo</th>
            <th style="text-align: right;">Precio</th>
          </tr>
        </thead>
        <tbody>
          ${productsListHtml}
        </tbody>
      </table>
      
      <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin-top: 30px; border-radius: 4px;">
        <p style="margin: 0; color: #856404; font-weight: bold;">
          💡 Recomendación
        </p>
        <p style="margin: 10px 0 0 0; color: #856404; font-size: 14px;">
          Considera realizar pedidos para reponer estos productos y evitar quedarte sin stock.
        </p>
      </div>
    </div>
    
    <div class="footer">
      <p style="margin: 0;">© ${new Date().getFullYear()} 911 SmartFix. Sistema de gestión de inventario.</p>
      <p style="margin: 10px 0 0 0;">Este es un correo automático. Por favor no responder.</p>
    </div>
  </div>
</body>
</html>
      `;

      // Enviar email
      try {
        await base44.integrations.Core.SendEmail({
          from_name: "911 SmartFix - Inventario",
          to: alertEmail,
          subject,
          body: htmlBody
        });
      } catch (emailError) {
        console.error("Error sending low stock email:", emailError);
        return { success: false, error: emailError.message };
      }

      // Crear notificación in-app para admins
      try {
        const admins = await base44.entities.User.filter({ role: "admin" });
        for (const admin of admins) {
          await base44.entities.CommunicationQueue.create({
            type: "in_app",
            user_id: admin.id,
            subject: `⚠️ ${lowStockProducts.length} productos con bajo stock`,
            body_html: `<p>Hay ${lowStockProducts.length} productos que necesitan reposición. Revisa el inventario.</p>`,
            status: "pending",
            meta: {
              notification_type: "inventory_alert",
              products_count: lowStockProducts.length,
              product_ids: lowStockProducts.map(p => p.id)
            }
          });
        }
      } catch (notifError) {
        console.warn("Could not create in-app notifications:", notifError);
      }

      return { success: true, count: lowStockProducts.length };
    } catch (error) {
      console.error("Error checking low stock:", error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Notifica sobre un producto específico con bajo stock
   */
  static async notifyLowStock(product) {
    try {
      // Verificar si ya se notificó recientemente (últimas 24 horas)
      const notifiedKey = `low_stock_notified_${product.id}`;
      // In a server-side context, localStorage is not available. 
      // This part would need adaptation for a universal service.
      // For now, assuming this method might be called in a client-side context as well.
      let lastNotified = null;
      if (typeof localStorage !== 'undefined') {
        lastNotified = localStorage.getItem(notifiedKey);
      }
      
      if (lastNotified) {
        const hoursSince = (Date.now() - parseInt(lastNotified)) / (1000 * 60 * 60);
        if (hoursSince < 24) {
          // Ya se notificó en las últimas 24 horas
          return { success: true, skipped: true };
        }
      }

      // Obtener email de alertas
      let alertEmail = "";
      try {
        const configs = await base44.entities.SystemConfig.filter({ key: "alert_email" });
        if (configs && configs.length > 0) {
          alertEmail = configs[0].value || configs[0].value_json || "";
        }
      } catch (e) {
        console.warn("Could not load alert_email config (single product):", e);
      }

      if (!alertEmail) {
        try {
          const admins = await base44.entities.User.filter({ role: "admin" });
          if (admins && admins.length > 0) {
            alertEmail = admins[0].email;
          }
        } catch (e) {
          console.warn("Could not load admin email (single product):", e);
        }
      }

      if (!alertEmail) {
        return { success: false, error: "No alert email configured" };
      }

      const subject = `⚠️ Stock Bajo: ${product.name}`;
      const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4;">
  <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
    <div style="background: linear-gradient(135deg, #FF0000 0%, #CC0000 100%); padding: 30px; text-align: center;">
      <h1 style="margin: 0; color: white; font-size: 24px;">⚠️ Alerta de Stock</h1>
    </div>
    
    <div style="padding: 30px;">
      <h2 style="color: #FF0000; margin-top: 0;">Producto con stock bajo</h2>
      
      <div style="background: #f8f9fa; border-left: 4px solid #FF0000; padding: 20px; margin: 20px 0; border-radius: 4px;">
        <h3 style="margin: 0 0 15px 0; color: #333;">${product.name}</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 8px 0; color: #666; font-weight: bold;">SKU:</td>
            <td style="padding: 8px 0; color: #333;">${product.sku || "N/A"}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #666; font-weight: bold;">Stock actual:</td>
            <td style="padding: 8px 0; color: #FF0000; font-weight: bold; font-size: 18px;">${product.stock || 0}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #666; font-weight: bold;">Stock mínimo:</td>
            <td style="padding: 8px 0; color: #333;">${product.min_stock || 0}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #666; font-weight: bold;">Precio:</td>
            <td style="padding: 8px 0; color: #333;">$${Number(product.price || 0).toFixed(2)}</td>
          </tr>
        </table>
      </div>
      
      <div style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 5px; padding: 15px; margin-top: 20px;">
        <p style="margin: 0; color: #856404;">
          <strong>💡 Acción requerida:</strong><br>
          Considera realizar un pedido para reponer este producto.
        </p>
      </div>
    </div>
    
    <div style="background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee;">
      <p style="margin: 0; color: #999; font-size: 12px;">
        © ${new Date().getFullYear()} 911 SmartFix. Este es un correo automático.
      </p>
    </div>
  </div>
</body>
</html>
      `;

      // Enviar email
      await base44.integrations.Core.SendEmail({
        from_name: "911 SmartFix - Inventario",
        to: alertEmail,
        subject,
        body: htmlBody
      });

      // Guardar timestamp de notificación
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(notifiedKey, String(Date.now()));
      }

      // Mostrar notificación del navegador si está permitido
      if (typeof window !== 'undefined' && "Notification" in window && Notification.permission === "granted") {
        new Notification("Stock Bajo", {
          body: `${product.name} tiene solo ${product.stock} unidades`,
          icon: "/favicon.ico",
          badge: "/favicon.ico"
        });
      }

      return { success: true };
    } catch (error) {
      console.error("Error notifying low stock:", error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Limpia el estado de notificación para un producto
   */
  static clearNotifiedStatus(productId) {
    const notifiedKey = `low_stock_notified_${productId}`;
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(notifiedKey);
    }
  }

  /**
   * Notifica cuando se asigna una orden a un técnico
   */
  static async notifyOrderAssigned(order, technician) {
    try {
      const subject = `📋 Nueva asignación: ${order.order_number}`;
      const body = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #FF0000;">Nueva Orden Asignada</h2>
          <p>Hola <strong>${technician.full_name}</strong>,</p>
          <p>Se te ha asignado una nueva orden de trabajo:</p>
          
          <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0;">📋 ${order.order_number}</h3>
            <p><strong>Cliente:</strong> ${order.customer_name}</p>
            <p><strong>Dispositivo:</strong> ${order.device_brand} ${order.device_model}</p>
            <p><strong>Problema:</strong> ${order.initial_problem || "Por diagnosticar"}</p>
            <p><strong>Estado:</strong> ${order.status}</p>
          </div>
          
          <p>Por favor revisa los detalles en el sistema.</p>
          <p>— 911 SmartFix</p>
        </div>
      `;

      // Crear notificación in-app
      await base44.entities.CommunicationQueue.create({
        type: "in_app",
        user_id: technician.id,
        subject,
        body_html: body,
        status: "pending",
        meta: {
          order_id: order.id,
          order_number: order.order_number,
          notification_type: "order_assigned",
          priority: order.priority || "normal"
        }
      });

      // Verificar preferencias de notificación
      const techProfile = await base44.entities.TechnicianProfile.filter({
        user_id: technician.id
      }).catch(() => []);

      const preferences = techProfile[0]?.notification_preferences || {
        push_enabled: true,
        email_enabled: true,
        notify_on_assignment: true
      };

      // Enviar email si está habilitado
      if (preferences.email_enabled && preferences.notify_on_assignment && technician.email) {
        try {
          await base44.integrations.Core.SendEmail({
            to: technician.email,
            subject,
            body
          });
        } catch (emailError) {
          console.warn("Could not send email notification:", emailError);
        }
      }

      return { success: true };
    } catch (error) {
      console.error("Error sending order assignment notification:", error);
      throw error;
    }
  }

  /**
   * Notifica sobre una tarea urgente
   */
  static async notifyUrgentTask(technician, message, orderId = null) {
    try {
      const subject = `🚨 URGENTE: ${message}`;
      const body = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: #FF0000; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
            <h2 style="margin: 0;">⚠️ Tarea Urgente</h2>
          </div>
          <div style="background: #f5f5f5; padding: 20px; border-radius: 0 0 8px 8px;">
            <p>Hola <strong>${technician.full_name}</strong>,</p>
            <p>${message}</p>
            <p style="color: #FF0000; font-weight: bold;">Por favor atiende esto lo antes posible.</p>
            <p>— 911 SmartFix</p>
          </div>
        </div>
      `;

      // Notificación in-app
      await base44.entities.CommunicationQueue.create({
        type: "in_app",
        user_id: technician.id,
        subject,
        body_html: body,
        status: "pending",
        meta: {
          order_id: orderId,
          notification_type: "urgent_task",
          priority: "urgent"
        }
      });

      // Verificar preferencias
      const techProfile = await base44.entities.TechnicianProfile.filter({
        user_id: technician.id
      }).catch(() => []);

      const preferences = techProfile[0]?.notification_preferences || {
        push_enabled: true,
        email_enabled: true,
        notify_on_urgent: true
      };

      // Email para tareas urgentes
      if (preferences.email_enabled && preferences.notify_on_urgent && technician.email) {
        try {
          await base44.integrations.Core.SendEmail({
            to: technician.email,
            subject,
            body
          });
        } catch (emailError) {
          console.warn("Could not send urgent email:", emailError);
        }
      }

      return { success: true };
    } catch (error) {
      console.error("Error sending urgent notification:", error);
      throw error;
    }
  }

  /**
   * Notifica a un técnico con mensaje personalizado
   */
  static async notifyTechnician(technician, message, options = {}) {
    try {
      const {
        subject = "Nuevo Mensaje",
        priority = "normal",
        orderId = null,
        includeOrderDetails = false
      } = options;

      let body = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #FF0000;">${subject}</h2>
          <p>Hola <strong>${technician.full_name}</strong>,</p>
          <p>${message}</p>
      `;

      if (includeOrderDetails && orderId) {
        try {
          const order = await base44.entities.Order.get(orderId);
          body += `
            <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0;">📋 ${order.order_number}</h3>
              <p><strong>Cliente:</strong> ${order.customer_name}</p>
              <p><strong>Dispositivo:</strong> ${order.device_brand} ${order.device_model}</p>
            </div>
          `;
        } catch (e) {
          console.warn("Could not fetch order details for technician notification:", e);
        }
      }

      body += `
          <p>— 911 SmartFix</p>
        </div>
      `;

      // Crear notificación
      await base44.entities.CommunicationQueue.create({
        type: "in_app",
        user_id: technician.id || technician.user_id,
        subject,
        body_html: body,
        status: "pending",
        meta: {
          order_id: orderId,
          notification_type: "custom_message",
          priority
        }
      });

      // Verificar preferencias y enviar email
      const techProfile = await base44.entities.TechnicianProfile.filter({
        user_id: technician.id || technician.user_id
      }).catch(() => []);

      const preferences = techProfile[0]?.notification_preferences || {
        email_enabled: true,
        notify_on_message: true
      };

      const email = technician.email || techProfile[0]?.email;
      
      if (preferences.email_enabled && preferences.notify_on_message && email) {
        try {
          await base44.integrations.Core.SendEmail({
            to: email,
            subject,
            body
          });
        } catch (emailError) {
          console.warn("Could not send email:", emailError);
        }
      }

      return { success: true };
    } catch (error) {
      console.error("Error sending technician notification:", error);
      throw error;
    }
  }

  /**
   * Notifica cuando cambia el estado de una orden
   */
  static async notifyOrderStatusChange(order, newStatus, technician) {
    try {
      if (!technician) return { success: false, error: "Technician not provided" };

      const statusLabels = {
        intake: "En Recepción",
        diagnosing: "En Diagnóstico",
        awaiting_approval: "Esperando Aprobación",
        in_progress: "En Reparación",
        ready_for_pickup: "Listo para Recoger",
        completed: "Completado",
        // Add any other status labels here if needed
      };

      const subject = `📋 Actualización: ${order.order_number}`;
      const body = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #FF0000;">Cambio de Estado</h2>
          <p>Hola <strong>${technician.full_name}</strong>,</p>
          <p>La orden <strong>${order.order_number}</strong> cambió a:</p>
          
          <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #FF0000; margin-top: 0;">${statusLabels[newStatus] || newStatus}</h3>
            <p><strong>Cliente:</strong> ${order.customer_name}</p>
            <p><strong>Dispositivo:</strong> ${order.device_brand} ${order.device_model}</p>
          </div>
          
          <p>— 911 SmartFix</p>
        </div>
      `;

      await base44.entities.CommunicationQueue.create({
        type: "in_app",
        user_id: technician.id,
        subject,
        body_html: body,
        status: "pending",
        meta: {
          order_id: order.id,
          order_number: order.order_number,
          notification_type: "status_change",
          new_status: newStatus
        }
      });

      return { success: true };
    } catch (error) {
      console.error("Error sending status change notification:", error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Envía notificación automática según configuración del sistema
   */
  static async sendAutomatedNotification(order, eventType, additionalData = {}) {
    try {
      // Cargar configuración de notificaciones
      const settingsRows = await base44.entities.AppSettings.filter({ slug: "master-settings" });
      if (!settingsRows || settingsRows.length === 0) {
        console.log("No automated notifications configured");
        return { success: false, error: "No config found" };
      }

      const config = settingsRows[0].payload;
      const notifications = config?.notifications;

      if (!notifications || !notifications.enabled) {
        console.log("Notifications disabled in settings");
        return { success: false, error: "Notifications disabled" };
      }

      // Verificar si el email está habilitado y el evento está activo
      const emailConfig = notifications.email;
      if (!emailConfig || !emailConfig.enabled) {
        console.log("Email notifications disabled");
        return { success: false, error: "Email notifications disabled" };
      }

      const eventConfig = emailConfig.events?.[eventType];
      if (!eventConfig || !eventConfig.enabled) {
        console.log(`Event ${eventType} not enabled`);
        return { success: false, error: `Event ${eventType} not enabled` };
      }

      // Verificar que el cliente tenga email
      if (!order.customer_email) {
        console.log("Customer has no email");
        return { success: false, error: "No customer email" };
      }

      // Preparar variables para reemplazar en el template
      const variables = {
        order_number: order.order_number || "",
        customer_name: order.customer_name || "",
        device_brand: order.device_brand || "",
        device_model: order.device_model || "",
        new_status: additionalData.new_status || order.status || "",
        amount: additionalData.amount ? `$${Number(additionalData.amount).toFixed(2)}` : "",
        balance: additionalData.balance ? `$${Number(additionalData.balance).toFixed(2)}` : "",
        total: order.total ? `$${Number(order.total).toFixed(2)}` : ""
      };

      // Reemplazar variables en subject y template
      let subject = eventConfig.subject || "Actualización de tu orden";
      let body = eventConfig.template || "Tu orden ha sido actualizada.";

      Object.entries(variables).forEach(([key, value]) => {
        const regex = new RegExp(`{{${key}}}`, 'g');
        subject = subject.replace(regex, value);
        body = body.replace(regex, value);
      });

      // Enviar email
      const fromName = emailConfig.from_name || "911 SmartFix";
      const replyTo = emailConfig.reply_to || undefined;

      await base44.integrations.Core.SendEmail({
        from_name: fromName,
        to: order.customer_email,
        subject,
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: linear-gradient(135deg, #FF0000 0%, #CC0000 100%); padding: 30px; text-align: center;">
              <h1 style="margin: 0; color: white; font-size: 24px;">${fromName}</h1>
            </div>
            <div style="padding: 30px; background: white;">
              <p style="font-size: 16px; color: #333; line-height: 1.6; white-space: pre-line;">
                ${body}
              </p>
              ${order.order_number ? `
                <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin-top: 20px;">
                  <h3 style="margin: 0 0 10px 0; color: #333;">Detalles de la orden</h3>
                  <p style="margin: 5px 0; color: #666;"><strong>Orden:</strong> ${order.order_number}</p>
                  ${order.device_brand && order.device_model ? `<p style="margin: 5px 0; color: #666;"><strong>Equipo:</strong> ${order.device_brand} ${order.device_model}</p>` : ''}
                  ${order.status ? `<p style="margin: 5px 0; color: #666;"><strong>Estado:</strong> ${order.status}</p>` : ''}
                </div>
              ` : ''}
            </div>
            <div style="background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee;">
              <p style="margin: 0; color: #999; font-size: 12px;">
                © ${new Date().getFullYear()} ${fromName}. Este es un correo automático.
              </p>
            </div>
          </div>
        `
      });

      // Log del envío
      await base44.entities.EmailLog.create({
        order_id: order.id,
        customer_id: order.customer_id,
        to_email: order.customer_email,
        subject,
        body_html: body,
        event_type: eventType,
        status: "sent",
        sent_at: new Date().toISOString()
      });

      console.log(`✅ Automated notification sent: ${eventType} to ${order.customer_email}`);
      return { success: true };
    } catch (error) {
      console.error("Error sending automated notification:", error);
      
      // Log del error
      try {
        await base44.entities.EmailLog.create({
          order_id: order.id,
          customer_id: order.customer_id,
          to_email: order.customer_email,
          subject: `Notification: ${eventType}`,
          body_html: "",
          event_type: eventType,
          status: "failed",
          error_message: error.message || String(error)
        });
      } catch (logError) {
        console.error("Error logging email failure:", logError);
      }

      return { success: false, error: error.message };
    }
  }

  /**
   * Marca una notificación como leída
   */
  static async markAsRead(notificationId) {
    try {
      await base44.entities.CommunicationQueue.update(notificationId, {
        status: "read",
        read_at: new Date().toISOString()
      });
      return { success: true };
    } catch (error) {
      console.error("Error marking notification as read:", error);
      throw error;
    }
  }

  /**
   * Obtiene notificaciones pendientes para un usuario
   */
  static async getPendingNotifications(userId) {
    try {
      const notifications = await base44.entities.CommunicationQueue.filter({
        user_id: userId,
        status: "pending"
      }, "-created_date", 50);

      return notifications || [];
    } catch (error) {
      console.error("Error fetching pending notifications:", error);
      return [];
    }
  }

  /**
   * Obtiene todas las notificaciones de un usuario
   */
  static async getAllNotifications(userId, limit = 100) {
    try {
      const notifications = await base44.entities.CommunicationQueue.filter({
        user_id: userId
      }, "-created_date", limit);

      return notifications || [];
    } catch (error) {
      console.error("Error fetching all notifications:", error);
      return [];
    }
  }
}

export default NotificationService;
