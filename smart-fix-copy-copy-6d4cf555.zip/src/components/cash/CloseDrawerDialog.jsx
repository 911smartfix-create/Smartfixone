
import React, { useState, useEffect, useMemo, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Wallet, X } from "lucide-react";
import { format, startOfDay, endOfDay, isWithinInterval } from "date-fns";

export default function CloseDrawerDialog({ open, onClose, onSuccess, drawer, stats }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [editingDenom, setEditingDenom] = useState(null);
  const [editValue, setEditValue] = useState("");
  
  const [denominations, setDenominations] = useState({
    coins_001: 0,
    coins_005: 0,
    coins_010: 0,
    coins_025: 0,
    bills_1: 0,
    bills_5: 0,
    bills_10: 0,
    bills_20: 0,
    bills_50: 0,
    bills_100: 0
  });

  const longPressTimer = useRef(null);
  const pressStartTime = useRef(null);

  const denomConfig = [
    { key: 'bills_100', label: '$100', value: 100, color: 'from-purple-700 to-purple-900' },
    { key: 'bills_50', label: '$50', value: 50, color: 'from-indigo-700 to-indigo-900' },
    { key: 'bills_20', label: '$20', value: 20, color: 'from-green-400 to-green-600' },
    { key: 'bills_10', label: '$10', value: 10, color: 'from-green-500 to-green-700' },
    { key: 'bills_5', label: '$5', value: 5, color: 'from-green-600 to-green-800' },
    { key: 'bills_1', label: '$1', value: 1, color: 'from-green-700 to-green-900' },
    { key: 'coins_025', label: '25¢', value: 0.25, color: 'from-gray-300 to-gray-500' },
    { key: 'coins_010', label: '10¢', value: 0.10, color: 'from-gray-400 to-gray-600' },
    { key: 'coins_005', label: '5¢', value: 0.05, color: 'from-gray-500 to-gray-700' },
    { key: 'coins_001', label: '1¢', value: 0.01, color: 'from-amber-700 to-amber-900' },
  ];

  useEffect(() => {
    if (open) {
      loadUser();
      setDenominations({
        coins_001: 0,
        coins_005: 0,
        coins_010: 0,
        coins_025: 0,
        bills_1: 0,
        bills_5: 0,
        bills_10: 0,
        bills_20: 0,
        bills_50: 0,
        bills_100: 0
      });
      setEditingDenom(null);
    }
    
    return () => {
      if (longPressTimer.current) {
        clearTimeout(longPressTimer.current);
      }
    };
  }, [open]);

  const loadUser = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
  };

  const calculateTotal = () => {
    return (
      denominations.bills_100 * 100 +
      denominations.bills_50 * 50 +
      denominations.bills_20 * 20 +
      denominations.bills_10 * 10 +
      denominations.bills_5 * 5 +
      denominations.bills_1 * 1 +
      denominations.coins_025 * 0.25 +
      denominations.coins_010 * 0.10 +
      denominations.coins_005 * 0.05 +
      denominations.coins_001 * 0.01
    );
  };

  const handleIncrement = (key) => {
    setDenominations(prev => ({
      ...prev,
      [key]: prev[key] + 1
    }));
  };

  const handlePointerDown = (key, event) => {
    event.preventDefault();
    pressStartTime.current = Date.now();
    
    longPressTimer.current = setTimeout(() => {
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }
      
      setEditingDenom(key);
      setEditValue(denominations[key].toString());
    }, 2000);
  };

  const handlePointerUp = (key) => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
    
    const pressDuration = Date.now() - (pressStartTime.current || 0);
    if (pressDuration < 2000 && !editingDenom) {
      handleIncrement(key);
    }
    
    pressStartTime.current = null;
  };

  const handlePointerLeave = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
    pressStartTime.current = null;
  };

  const handleSaveEdit = () => {
    const newValue = parseInt(editValue) || 0;
    setDenominations(prev => ({
      ...prev,
      [editingDenom]: Math.max(0, newValue)
    }));
    setEditingDenom(null);
    setEditValue("");
  };

  const handleCancelEdit = () => {
    setEditingDenom(null);
    setEditValue("");
  };

  const countedCash = calculateTotal();
  const expectedCash = (drawer?.opening_balance || 0) + (stats?.byMethod?.cash || 0);
  const difference = countedCash - expectedCash;

  const handleCloseDrawer = async () => {
    if (!drawer) {
      alert("No hay caja abierta");
      return;
    }

    setLoading(true);
    try {
      const { base44 } = await import("@/api/base44Client");
      
      // ✅ Cargar TODAS las ventas del día para el reporte
      const today = format(new Date(), "yyyy-MM-dd");
      const todayStart = startOfDay(new Date());
      const todayEnd = endOfDay(new Date());
      
      const [allSales, allTransactions] = await Promise.all([
        base44.entities.Sale.list("-created_date", 500),
        base44.entities.Transaction.list("-created_date", 500)
      ]);
      
      // Filtrar ventas y transacciones de hoy
      const todaySales = (allSales || []).filter(s => {
        if (s.voided) return false;
        try {
          const saleDate = new Date(s.created_date);
          return isWithinInterval(saleDate, { start: todayStart, end: todayEnd });
        } catch {
          return false;
        }
      });
      
      const todayRevenueTransactions = (allTransactions || []).filter(t => {
        if (t.type !== 'revenue') return false;
        try {
          const txDate = new Date(t.created_date);
          return isWithinInterval(txDate, { start: todayStart, end: todayEnd });
        } catch {
          return false;
        }
      });
      
      const totalRevenue = todayRevenueTransactions.reduce((sum, t) => sum + (t.amount || 0), 0);
      const totalSalesCount = todaySales.length;
      const netProfit = totalRevenue - (stats?.totalExpenses || 0);
      
      console.log("📊 [CloseDrawer] Ventas del día:", {
        count: totalSalesCount,
        revenue: totalRevenue,
        sales: todaySales
      });
      
      // Actualizar caja con el reporte completo
      await base44.entities.CashRegister.update(drawer.id, {
        status: 'closed',
        closing_balance: countedCash,
        closed_by: user?.full_name || user?.email,
        total_revenue: totalRevenue,
        total_expenses: stats?.totalExpenses || 0,
        net_profit: netProfit,
        estimated_tax: netProfit * 0.115
      });

      // Registrar movimiento de cierre
      await base44.entities.CashDrawerMovement.create({
        drawer_id: drawer.id,
        type: "closing",
        amount: countedCash,
        description: `Cierre de caja. Esperado: $${expectedCash.toFixed(2)}, Diferencia: $${difference.toFixed(2)}`,
        employee: user?.full_name || user?.email || "Sistema",
        denominations: denominations
      });

      // Crear log de auditoría
      await base44.entities.AuditLog.create({
        action: "close_cash_drawer",
        entity_type: "cash_register",
        entity_id: drawer.id,
        user_id: user?.id || null,
        user_name: user?.full_name || user?.email || "Sistema",
        user_role: user?.role || "system",
        changes: {
          expected: expectedCash,
          counted: countedCash,
          difference: difference,
          denominations: denominations,
          sales_count: totalSalesCount,
          total_revenue: totalRevenue
        }
      });

      // ✅ Enviar reporte detallado por email
      try {
        const admins = await base44.entities.User.filter({ role: "admin" });
        
        const emailSubject = `Cierre de Caja - ${format(new Date(), "dd/MM/yyyy")} - ${user?.full_name || user?.email}`;
        
        // Generar tabla de ventas
        const salesTable = todaySales.map((s, idx) => `
          <tr ${idx % 2 === 0 ? 'style="background: #f9f9f9;"' : ''}>
            <td style="padding: 8px; border: 1px solid #ddd;">${format(new Date(s.created_date), 'HH:mm')}</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${s.sale_number}</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${s.customer_name || 'Cliente General'}</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${s.items?.length || 0} items</td>
            <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${(s.total || 0).toFixed(2)}</td>
            <td style="padding: 8px; border: 1px solid #ddd; text-transform: capitalize;">${s.payment_method === 'ath_movil' ? 'ATH Móvil' : s.payment_method}</td>
          </tr>
        `).join('');
        
        const emailBody = `
          <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
            <h2 style="color: #FF0000;">📊 Reporte de Cierre de Caja</h2>
            <p><strong>Fecha:</strong> ${format(new Date(), "dd/MM/yyyy HH:mm")}</p>
            <p><strong>Cerrado por:</strong> ${user?.full_name || user?.email}</p>
            
            <h3 style="margin-top: 30px;">💰 Resumen Financiero</h3>
            <table style="border-collapse: collapse; width: 100%; margin: 20px 0;">
              <tr style="background: #f5f5f5;">
                <td style="padding: 12px; border: 1px solid #ddd;"><strong>Concepto</strong></td>
                <td style="padding: 12px; border: 1px solid #ddd; text-align: right;"><strong>Monto</strong></td>
              </tr>
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Total de Ventas (${totalSalesCount} transacciones)</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: green; font-weight: bold;">$${totalRevenue.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Gastos del Día</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: red;">$${(stats?.totalExpenses || 0).toFixed(2)}</td>
              </tr>
              <tr style="background: #e8f5e9;">
                <td style="padding: 12px; border: 1px solid #ddd;"><strong>Utilidad Neta</strong></td>
                <td style="padding: 12px; border: 1px solid #ddd; text-align: right;"><strong>$${netProfit.toFixed(2)}</strong></td>
              </tr>
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">IVU Estimado (11.5%)</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">$${(netProfit * 0.115).toFixed(2)}</td>
              </tr>
            </table>

            <h3 style="margin-top: 30px;">💵 Conteo de Efectivo</h3>
            <table style="border-collapse: collapse; width: 100%; max-width: 500px; margin: 20px 0;">
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Fondo Inicial</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">$${(drawer.opening_balance || 0).toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Efectivo Esperado</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">$${expectedCash.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">Efectivo Contado</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">$${countedCash.toFixed(2)}</td>
              </tr>
              <tr style="background: ${difference === 0 ? '#d4edda' : '#f8d7da'};">
                <td style="padding: 10px; border: 1px solid #ddd;"><strong>Diferencia</strong></td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><strong>${difference >= 0 ? '+' : ''}${difference.toFixed(2)}</strong></td>
              </tr>
            </table>

            <h3 style="margin-top: 30px;">🧾 Detalle de Ventas del Día</h3>
            <table style="border-collapse: collapse; width: 100%; margin: 20px 0; font-size: 13px;">
              <thead>
                <tr style="background: #333; color: white;">
                  <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Hora</th>
                  <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Recibo</th>
                  <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Cliente</th>
                  <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Items</th>
                  <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Total</th>
                  <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Método</th>
                </tr>
              </thead>
              <tbody>
                ${salesTable || '<tr><td colspan="6" style="padding: 20px; text-align: center; color: #999;">No hubo ventas hoy</td></tr>'}
              </tbody>
            </table>

            <h3 style="margin-top: 30px;">💳 Ventas por Método de Pago</h3>
            <table style="border-collapse: collapse; width: 100%; max-width: 500px; margin: 20px 0;">
              ${Object.entries(stats?.byMethod || {}).map(([method, amount]) => `
                <tr>
                  <td style="padding: 8px; border: 1px solid #ddd; text-transform: capitalize;">
                    ${method === 'ath_movil' ? 'ATH Móvil' : method}
                  </td>
                  <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${amount.toFixed(2)}</td>
                </tr>
              `).join('')}
            </table>

            <h3 style="margin-top: 30px;">💵 Desglose por Denominación</h3>
            <table style="border-collapse: collapse; width: 100%; max-width: 500px; margin: 20px 0;">
              ${denomConfig.map(d => `
                <tr>
                  <td style="padding: 6px; border: 1px solid #ddd;">${d.label}</td>
                  <td style="padding: 6px; border: 1px solid #ddd; text-align: center;">${denominations[d.key]}</td>
                  <td style="padding: 6px; border: 1px solid #ddd; text-align: right;">$${(denominations[d.key] * d.value).toFixed(2)}</td>
                </tr>
              `).join('')}
              <tr style="background: #f5f5f5; font-weight: bold;">
                <td style="padding: 8px; border: 1px solid #ddd;" colspan="2">TOTAL</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">$${countedCash.toFixed(2)}</td>
              </tr>
            </table>

            <p style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #ddd; color: #666; font-size: 12px;">
              Este es un reporte automático generado por 911 SmartFix<br>
              Generado el ${format(new Date(), "dd/MM/yyyy 'a las' HH:mm:ss")}
            </p>
          </div>
        `;

        for (const admin of admins) {
          if (admin.email) {
            try {
              await base44.integrations.Core.SendEmail({
                to: admin.email,
                subject: emailSubject,
                body: emailBody
              });
              console.log("✅ Reporte enviado a:", admin.email);
            } catch (emailErr) {
              console.warn("No se pudo enviar email a:", admin.email, emailErr);
            }
          }
        }
      } catch (emailError) {
        console.warn("Error enviando reportes por email:", emailError);
      }

      // ✅ Disparar evento para resetear dashboard
      console.log("🔔 Disparando evento drawer-closed");
      window.dispatchEvent(new CustomEvent("drawer-closed", { 
        detail: { 
          date: today,
          total_revenue: totalRevenue,
          sales_count: totalSalesCount,
          closing_balance: countedCash
        } 
      }));
      window.dispatchEvent(new Event("force-refresh"));

      onSuccess?.();
      
    } catch (error) {
      console.error("Error cerrando caja:", error);
      alert("Error al cerrar caja: " + (error.message || "Error desconocido"));
    }
    setLoading(false);
  };

  const handleClose = () => {
    setEditingDenom(null);
    setEditValue("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[95vh] bg-gradient-to-br from-[#2B2B2B] to-black border-[#FF0000]/30 overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="text-2xl font-bold text-white flex items-center gap-2">
            <Wallet className="w-6 h-6 text-[#FF0000]" />
            Cerrar Caja
          </DialogTitle>
          <p className="text-gray-400 text-sm mt-1">
            Tap = +1 | Mantén 2s = Editar cantidad
          </p>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-1 space-y-4">
          {/* Summary */}
          <div className="grid grid-cols-3 gap-3 p-4 bg-black/30 rounded-lg">
            <div className="text-center">
              <p className="text-xs text-gray-400">Esperado</p>
              <p className="text-lg font-bold text-white">${expectedCash.toFixed(2)}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400">Contado</p>
              <p className="text-lg font-bold text-blue-400">${countedCash.toFixed(2)}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400">Diferencia</p>
              <p className={`text-lg font-bold ${difference === 0 ? 'text-green-400' : difference > 0 ? 'text-blue-400' : 'text-red-400'}`}>
                ${difference.toFixed(2)}
              </p>
            </div>
          </div>

          {/* Denominations Grid */}
          <div className="grid grid-cols-5 gap-2">
            {denomConfig.map((denom) => (
              <div key={denom.key} className="flex flex-col gap-1">
                <button
                  onPointerDown={(e) => handlePointerDown(denom.key, e)}
                  onPointerUp={() => handlePointerUp(denom.key)}
                  onPointerLeave={handlePointerLeave}
                  onContextMenu={(e) => e.preventDefault()}
                  className={`
                    relative h-20 rounded-xl bg-gradient-to-br ${denom.color}
                    border-2 ${denominations[denom.key] > 0 ? 'border-[#FF0000]' : 'border-gray-700'} 
                    hover:border-[#FF0000] transition-all duration-200 
                    active:scale-95 flex flex-col items-center justify-center 
                    touch-manipulation
                    ${denominations[denom.key] > 0 ? 'ring-2 ring-[#FF0000] ring-opacity-50' : ''}
                  `}
                >
                  <span className="text-xl font-bold text-white">{denom.label}</span>
                  {denominations[denom.key] > 0 && (
                    <span className="text-xs text-white/70 mt-1">{denominations[denom.key]}</span>
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex-shrink-0 flex gap-3 pt-4 border-t border-gray-800">
          <Button
            onClick={handleClose}
            variant="outline"
            className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800"
            disabled={loading}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleCloseDrawer}
            disabled={loading}
            className="flex-1 bg-gradient-to-r from-[#FF0000] to-red-800 hover:from-red-700 hover:to-red-900"
          >
            {loading ? "Cerrando..." : "Cerrar Caja y Enviar Reporte"}
          </Button>
        </div>

        {/* Edit Dialog Overlay */}
        {editingDenom && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-[#2B2B2B] border-2 border-[#FF0000]/50 rounded-xl p-6 w-80 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white">
                  Editar {denomConfig.find(d => d.key === editingDenom)?.label}
                </h3>
                <button onClick={handleCancelEdit} className="text-gray-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-2">
                <Label className="text-gray-300">Cantidad</Label>
                <Input
                  type="number"
                  min="0"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  className="bg-black border-gray-700 text-white text-lg"
                  autoFocus
                  onKeyPress={(e) => e.key === 'Enter' && handleSaveEdit()}
                />
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleCancelEdit}
                  className="flex-1 border-gray-700"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleSaveEdit}
                  className="flex-1 bg-gradient-to-r from-[#FF0000] to-red-800"
                >
                  Guardar
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
