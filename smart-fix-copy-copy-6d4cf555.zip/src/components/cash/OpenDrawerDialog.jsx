import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Wallet, DollarSign, X } from "lucide-react";
import { format } from "date-fns";

export default function OpenDrawerDialog({ open, onClose, onSuccess }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [editingDenom, setEditingDenom] = useState(null);
  const [editValue, setEditValue] = useState("");
  
  const [denominations, setDenominations] = useState({
    coins_001: 0,
    coins_005: 0,
    coins_010: 0,
    coins_025: 0,
    bills_1: 0,
    bills_5: 0,
    bills_10: 0,
    bills_20: 0
  });

  const longPressTimer = useRef(null);
  const pressStartTime = useRef(null);

  const denomConfig = [
    { key: 'coins_001', label: '1¢', value: 0.01, color: 'from-amber-700 to-amber-900' },
    { key: 'coins_005', label: '5¢', value: 0.05, color: 'from-gray-500 to-gray-700' },
    { key: 'coins_010', label: '10¢', value: 0.10, color: 'from-gray-400 to-gray-600' },
    { key: 'coins_025', label: '25¢', value: 0.25, color: 'from-gray-300 to-gray-500' },
    { key: 'bills_1', label: '$1', value: 1, color: 'from-green-700 to-green-900' },
    { key: 'bills_5', label: '$5', value: 5, color: 'from-green-600 to-green-800' },
    { key: 'bills_10', label: '$10', value: 10, color: 'from-green-500 to-green-700' },
    { key: 'bills_20', label: '$20', value: 20, color: 'from-green-400 to-green-600' },
  ];

  useEffect(() => {
    if (open) {
      loadUser();
      setDenominations({
        coins_001: 0,
        coins_005: 0,
        coins_010: 0,
        coins_025: 0,
        bills_1: 0,
        bills_5: 0,
        bills_10: 0,
        bills_20: 0
      });
      setEditingDenom(null);
    }
    
    return () => {
      if (longPressTimer.current) {
        clearTimeout(longPressTimer.current);
      }
    };
  }, [open]);

  const loadUser = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
  };

  const calculateTotal = () => {
    return (
      denominations.bills_20 * 20 +
      denominations.bills_10 * 10 +
      denominations.bills_5 * 5 +
      denominations.bills_1 * 1 +
      denominations.coins_025 * 0.25 +
      denominations.coins_010 * 0.10 +
      denominations.coins_005 * 0.05 +
      denominations.coins_001 * 0.01
    );
  };

  const handleIncrement = (key) => {
    setDenominations(prev => ({
      ...prev,
      [key]: prev[key] + 1
    }));
  };

  const handlePointerDown = (key, event) => {
    event.preventDefault();
    pressStartTime.current = Date.now();
    
    longPressTimer.current = setTimeout(() => {
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }
      
      setEditingDenom(key);
      setEditValue(denominations[key].toString());
    }, 2000);
  };

  const handlePointerUp = (key) => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
    
    const pressDuration = Date.now() - (pressStartTime.current || 0);
    if (pressDuration < 2000 && !editingDenom) {
      handleIncrement(key);
    }
    
    pressStartTime.current = null;
  };

  const handlePointerLeave = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
    pressStartTime.current = null;
  };

  const handleSaveEdit = () => {
    const newValue = parseInt(editValue) || 0;
    setDenominations(prev => ({
      ...prev,
      [editingDenom]: Math.max(0, newValue)
    }));
    setEditingDenom(null);
    setEditValue("");
  };

  const handleCancelEdit = () => {
    setEditingDenom(null);
    setEditValue("");
  };

  const handleOpen = async () => {
    const openingAmount = calculateTotal();
    
    if (openingAmount <= 0) {
      alert("El fondo inicial debe ser mayor a $0");
      return;
    }

    setLoading(true);
    try {
      const today = format(new Date(), "yyyy-MM-dd");
      
      const existing = await base44.entities.CashRegister.filter({ date: today, status: "open" });
      if (existing.length > 0) {
        alert("Ya existe una caja abierta para hoy");
        setLoading(false);
        return;
      }

      const register = await base44.entities.CashRegister.create({
        date: today,
        opening_balance: openingAmount,
        total_revenue: 0,
        total_expenses: 0,
        net_profit: 0,
        estimated_tax: 0,
        status: "open",
        opened_by: user.full_name || user.email
      });

      await base44.entities.CashDrawerMovement.create({
        drawer_id: register.id,
        type: "opening",
        amount: openingAmount,
        description: "Apertura de caja",
        reference: register.id,
        employee: user.full_name || user.email,
        denominations: denominations
      });

      try {
        const emailBody = `
          <h2>Caja Abierta - ${format(new Date(), "dd/MM/yyyy HH:mm")}</h2>
          <p><strong>Aperturada por:</strong> ${user.full_name || user.email}</p>
          <p><strong>Monto inicial:</strong> $${openingAmount.toFixed(2)}</p>
          
          <h3>Desglose por denominaciones:</h3>
          <table style="border-collapse: collapse; width: 100%; max-width: 400px;">
            <tr><td>Billetes $20:</td><td>${denominations.bills_20}</td><td>$${(denominations.bills_20 * 20).toFixed(2)}</td></tr>
            <tr><td>Billetes $10:</td><td>${denominations.bills_10}</td><td>$${(denominations.bills_10 * 10).toFixed(2)}</td></tr>
            <tr><td>Billetes $5:</td><td>${denominations.bills_5}</td><td>$${(denominations.bills_5 * 5).toFixed(2)}</td></tr>
            <tr><td>Billetes $1:</td><td>${denominations.bills_1}</td><td>$${(denominations.bills_1 * 1).toFixed(2)}</td></tr>
            <tr><td>Monedas 25¢:</td><td>${denominations.coins_025}</td><td>$${(denominations.coins_025 * 0.25).toFixed(2)}</td></tr>
            <tr><td>Monedas 10¢:</td><td>${denominations.coins_010}</td><td>$${(denominations.coins_010 * 0.10).toFixed(2)}</td></tr>
            <tr><td>Monedas 5¢:</td><td>${denominations.coins_005}</td><td>$${(denominations.coins_005 * 0.05).toFixed(2)}</td></tr>
            <tr><td>Monedas 1¢:</td><td>${denominations.coins_001}</td><td>$${(denominations.coins_001 * 0.01).toFixed(2)}</td></tr>
          </table>
          
          <p style="margin-top: 20px;"><strong>Total:</strong> $${openingAmount.toFixed(2)}</p>
        `;

        const users = await base44.entities.User.filter({ role: "admin" });
        
        if (users.length > 0) {
          for (const admin of users) {
            if (admin.email) {
              try {
                await base44.integrations.Core.SendEmail({
                  to: admin.email,
                  subject: `Caja Abierta - ${format(new Date(), "dd/MM/yyyy")} - ${user.full_name || user.email}`,
                  body: emailBody
                });
              } catch (emailError) {
                console.log(`No se pudo enviar email a ${admin.email}`);
              }
            }
          }
        }
      } catch (emailError) {
        console.error("Error al enviar notificaciones por email:", emailError);
      }

      try {
        await base44.entities.AuditLog.create({
          action: "open_cash_drawer",
          entity_type: "cash_register",
          entity_id: register.id,
          user_id: user.id,
          user_name: user.full_name || user.email,
          user_role: user.role,
          changes: {
            opening_balance: openingAmount,
            denominations: denominations
          }
        });
      } catch (auditError) {
        console.error("Error creating audit log:", auditError);
      }

      onSuccess();
    } catch (error) {
      console.error("Error opening cash drawer:", error);
      alert("Error al abrir caja: " + error.message);
    }

    setLoading(false);
  };

  const handleClose = () => {
    setEditingDenom(null);
    setEditValue("");
    onClose();
  };

  const totalAmount = calculateTotal();

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[95vh] bg-gradient-to-br from-[#2B2B2B] to-black border-[#FF0000]/30 overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="text-2xl font-bold text-white flex items-center gap-2">
            <Wallet className="w-6 h-6 text-[#FF0000]" />
            Abrir Caja
          </DialogTitle>
          <p className="text-gray-400 text-sm mt-1">
            Tap = +1 | Mantén 2s = Editar cantidad
          </p>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-1 space-y-4">
          {/* Denominations Grid */}
          <div className="grid grid-cols-4 gap-3">
            {denomConfig.map((denom) => (
              <div key={denom.key} className="flex flex-col gap-2">
                <button
                  onPointerDown={(e) => handlePointerDown(denom.key, e)}
                  onPointerUp={() => handlePointerUp(denom.key)}
                  onPointerLeave={handlePointerLeave}
                  onContextMenu={(e) => e.preventDefault()}
                  className={`
                    relative h-24 rounded-xl bg-gradient-to-br ${denom.color}
                    border-2 ${denominations[denom.key] > 0 ? 'border-[#FF0000]' : 'border-gray-700'} 
                    hover:border-[#FF0000] transition-all duration-200 
                    active:scale-95 flex flex-col items-center justify-center 
                    touch-manipulation
                    ${denominations[denom.key] > 0 ? 'ring-2 ring-[#FF0000] ring-opacity-50' : ''}
                  `}
                >
                  <span className="text-2xl font-bold text-white">{denom.label}</span>
                  {denominations[denom.key] > 0 && (
                    <span className="text-sm text-white/70 mt-1">{denominations[denom.key]}</span>
                  )}
                </button>
              </div>
            ))}
          </div>

          {/* Total Bar */}
          <div className="sticky bottom-0 bg-gradient-to-r from-[#FF0000]/20 to-red-800/20 backdrop-blur-md p-4 rounded-xl border border-[#FF0000]/30">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-400">Total Contado</p>
                <p className="text-3xl font-bold text-white">${totalAmount.toFixed(2)}</p>
              </div>
              <DollarSign className="w-12 h-12 text-[#FF0000]/50" />
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex-shrink-0 flex gap-3 pt-4 border-t border-gray-800">
          <Button
            onClick={handleClose}
            variant="outline"
            className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800"
            disabled={loading}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleOpen}
            disabled={loading || totalAmount <= 0}
            className="flex-1 bg-gradient-to-r from-[#FF0000] to-red-800 hover:from-red-700 hover:to-red-900"
          >
            {loading ? "Abriendo..." : "Abrir Caja"}
          </Button>
        </div>

        {/* Edit Dialog Overlay */}
        {editingDenom && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-[#2B2B2B] border-2 border-[#FF0000]/50 rounded-xl p-6 w-80 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white">
                  Editar {denomConfig.find(d => d.key === editingDenom)?.label}
                </h3>
                <button onClick={handleCancelEdit} className="text-gray-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-2">
                <Label className="text-gray-300">Cantidad</Label>
                <Input
                  type="number"
                  min="0"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  className="bg-black border-gray-700 text-white text-lg"
                  autoFocus
                  onKeyPress={(e) => e.key === 'Enter' && handleSaveEdit()}
                />
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleCancelEdit}
                  className="flex-1 border-gray-700"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleSaveEdit}
                  className="flex-1 bg-gradient-to-r from-[#FF0000] to-red-800"
                >
                  Guardar
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}