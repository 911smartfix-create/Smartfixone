import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Plus,
  Trash2,
  Save,
  Send,
  Package,
  DollarSign,
  Calendar,
  Truck
} from "lucide-react";

export default function PurchaseOrderDialog({ open, onClose, onSuccess, purchaseOrder }) {
  const isEdit = !!purchaseOrder;

  const [formData, setFormData] = useState({
    supplier_id: "",
    supplier_name: "",
    order_date: new Date().toISOString().split("T")[0],
    expected_delivery: "",
    items: [],
    subtotal: 0,
    tax_amount: 0,
    shipping_cost: 0,
    total: 0,
    payment_terms: "NET-30",
    notes: ""
  });

  const [suppliers, setSuppliers] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      loadData();
      if (purchaseOrder) {
        setFormData(purchaseOrder);
      } else {
        setFormData({
          supplier_id: "",
          supplier_name: "",
          order_date: new Date().toISOString().split("T")[0],
          expected_delivery: "",
          items: [],
          subtotal: 0,
          tax_amount: 0,
          shipping_cost: 0,
          total: 0,
          payment_terms: "NET-30",
          notes: ""
        });
      }
    }
  }, [open, purchaseOrder]);

  const loadData = async () => {
    try {
      const [suppliersData, productsData] = await Promise.all([
        base44.entities.Supplier.filter({ active: true }),
        base44.entities.Product.filter({ active: true })
      ]);
      setSuppliers(suppliersData || []);
      setProducts(productsData || []);
    } catch (error) {
      console.error("Error loading data:", error);
    }
  };

  const handleSupplierChange = (supplierId) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    setFormData({
      ...formData,
      supplier_id: supplierId,
      supplier_name: supplier?.name || "",
      payment_terms: supplier?.payment_terms || "NET-30"
    });
  };

  const addProduct = () => {
    if (!selectedProduct) return;

    const product = products.find(p => p.id === selectedProduct);
    if (!product) return;

    const newItem = {
      product_id: product.id,
      product_name: product.name,
      sku: product.sku,
      quantity_ordered: 1,
      quantity_received: 0,
      unit_cost: product.cost || 0,
      total_cost: product.cost || 0
    };

    setFormData({
      ...formData,
      items: [...formData.items, newItem]
    });
    setSelectedProduct("");
    calculateTotals([...formData.items, newItem]);
  };

  const updateItem = (index, field, value) => {
    const newItems = [...formData.items];
    newItems[index][field] = value;

    if (field === "quantity_ordered" || field === "unit_cost") {
      newItems[index].total_cost = 
        Number(newItems[index].quantity_ordered || 0) * 
        Number(newItems[index].unit_cost || 0);
    }

    setFormData({ ...formData, items: newItems });
    calculateTotals(newItems);
  };

  const removeItem = (index) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    setFormData({ ...formData, items: newItems });
    calculateTotals(newItems);
  };

  const calculateTotals = (items) => {
    const subtotal = items.reduce((sum, item) => sum + (item.total_cost || 0), 0);
    const taxAmount = subtotal * 0.115; // 11.5% IVU
    const total = subtotal + taxAmount + Number(formData.shipping_cost || 0);

    setFormData(prev => ({
      ...prev,
      subtotal,
      tax_amount: taxAmount,
      total
    }));
  };

  const handleSave = async (status = "draft") => {
    if (!formData.supplier_id || formData.items.length === 0) {
      alert("Selecciona un proveedor y agrega al menos un producto");
      return;
    }

    setLoading(true);
    try {
      const user = await base44.auth.me().catch(() => ({}));
      const poNumber = isEdit 
        ? formData.po_number 
        : `PO-${Date.now().toString().slice(-8)}`;

      const poData = {
        ...formData,
        po_number: poNumber,
        status,
        created_by: user?.full_name || "Sistema",
        approved_by: status === "sent" ? user?.full_name : null
      };

      if (isEdit) {
        await base44.entities.PurchaseOrder.update(purchaseOrder.id, poData);
      } else {
        await base44.entities.PurchaseOrder.create(poData);
      }

      // Actualizar total de órdenes del proveedor
      const supplier = suppliers.find(s => s.id === formData.supplier_id);
      if (supplier) {
        await base44.entities.Supplier.update(supplier.id, {
          total_orders: (supplier.total_orders || 0) + (isEdit ? 0 : 1),
          total_spent: (supplier.total_spent || 0) + (isEdit ? 0 : formData.total)
        });
      }

      onSuccess();
      onClose();
    } catch (error) {
      console.error("Error saving purchase order:", error);
      alert("Error al guardar la orden: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-[#2B2B2B] to-black border-red-900/30">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center gap-2">
            <FileText className="w-6 h-6 text-red-600" />
            {isEdit ? "Editar Orden de Compra" : "Nueva Orden de Compra"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Header Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300 mb-2 block">Proveedor *</Label>
              <select
                value={formData.supplier_id}
                onChange={(e) => handleSupplierChange(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-black/40 border border-white/15 text-white"
              >
                <option value="">Selecciona un proveedor...</option>
                {suppliers.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <Label className="text-gray-300 mb-2 block">Términos de Pago</Label>
              <select
                value={formData.payment_terms}
                onChange={(e) => setFormData({ ...formData, payment_terms: e.target.value })}
                className="w-full px-4 py-2 rounded-lg bg-black/40 border border-white/15 text-white"
              >
                <option value="NET-15">NET-15</option>
                <option value="NET-30">NET-30</option>
                <option value="NET-45">NET-45</option>
                <option value="NET-60">NET-60</option>
                <option value="COD">COD (Pago contra entrega)</option>
                <option value="Prepaid">Prepagado</option>
              </select>
            </div>

            <div>
              <Label className="text-gray-300 mb-2 block">
                <Calendar className="w-4 h-4 inline mr-1" />
                Fecha de Orden
              </Label>
              <Input
                type="date"
                value={formData.order_date}
                onChange={(e) => setFormData({ ...formData, order_date: e.target.value })}
                className="bg-black/40 border-white/15 text-white"
              />
            </div>

            <div>
              <Label className="text-gray-300 mb-2 block">
                <Truck className="w-4 h-4 inline mr-1" />
                Entrega Esperada
              </Label>
              <Input
                type="date"
                value={formData.expected_delivery}
                onChange={(e) => setFormData({ ...formData, expected_delivery: e.target.value })}
                className="bg-black/40 border-white/15 text-white"
              />
            </div>
          </div>

          {/* Items */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-gray-300">Items de la Orden</Label>
              <div className="flex gap-2">
                <select
                  value={selectedProduct}
                  onChange={(e) => setSelectedProduct(e.target.value)}
                  className="px-4 py-2 rounded-lg bg-black/40 border border-white/15 text-white text-sm"
                >
                  <option value="">Selecciona producto...</option>
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.sku}) - ${p.cost || 0}
                    </option>
                  ))}
                </select>
                <Button
                  onClick={addProduct}
                  disabled={!selectedProduct}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Agregar
                </Button>
              </div>
            </div>

            {formData.items.length === 0 ? (
              <div className="p-8 text-center bg-black/20 rounded-lg border border-white/10">
                <Package className="w-12 h-12 mx-auto text-gray-600 mb-2" />
                <p className="text-gray-400">No hay items en la orden</p>
              </div>
            ) : (
              <div className="space-y-2">
                {formData.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-black/40 rounded-lg border border-white/10 flex items-center gap-4"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-white">{item.product_name}</p>
                      <p className="text-xs text-gray-400">SKU: {item.sku}</p>
                    </div>

                    <div className="w-24">
                      <Label className="text-xs text-gray-400">Cantidad</Label>
                      <Input
                        type="number"
                        min="1"
                        value={item.quantity_ordered}
                        onChange={(e) => updateItem(idx, "quantity_ordered", parseInt(e.target.value) || 1)}
                        className="bg-black/40 border-white/15 text-white text-center"
                      />
                    </div>

                    <div className="w-32">
                      <Label className="text-xs text-gray-400">Costo Unit.</Label>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        value={item.unit_cost}
                        onChange={(e) => updateItem(idx, "unit_cost", parseFloat(e.target.value) || 0)}
                        className="bg-black/40 border-white/15 text-white"
                      />
                    </div>

                    <div className="w-32">
                      <Label className="text-xs text-gray-400">Total</Label>
                      <p className="text-white font-bold text-lg">
                        ${(item.total_cost || 0).toFixed(2)}
                      </p>
                    </div>

                    <Button
                      onClick={() => removeItem(idx)}
                      variant="ghost"
                      size="icon"
                      className="text-red-400 hover:text-red-300 hover:bg-red-600/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Totals */}
          <div className="bg-black/40 rounded-lg border border-white/10 p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Subtotal:</span>
              <span className="text-white font-medium">${formData.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">IVU (11.5%):</span>
              <span className="text-white font-medium">${formData.tax_amount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm items-center">
              <span className="text-gray-400">Costo de Envío:</span>
              <Input
                type="number"
                step="0.01"
                min="0"
                value={formData.shipping_cost}
                onChange={(e) => {
                  const shipping = parseFloat(e.target.value) || 0;
                  setFormData({ ...formData, shipping_cost: shipping });
                  calculateTotals(formData.items);
                }}
                className="w-32 bg-black/40 border-white/15 text-white text-right"
              />
            </div>
            <div className="flex justify-between text-xl font-bold pt-2 border-t border-white/10">
              <span className="text-white">Total:</span>
              <span className="text-green-400">${formData.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Notes */}
          <div>
            <Label className="text-gray-300 mb-2 block">Notas</Label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              className="w-full px-4 py-2 rounded-lg bg-black/40 border border-white/15 text-white resize-none"
              placeholder="Notas adicionales sobre la orden..."
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
          <Button
            onClick={onClose}
            variant="outline"
            disabled={loading}
            className="border-white/15"
          >
            Cancelar
          </Button>
          <Button
            onClick={() => handleSave("draft")}
            disabled={loading}
            variant="outline"
            className="border-white/15"
          >
            <Save className="w-4 h-4 mr-2" />
            Guardar Borrador
          </Button>
          <Button
            onClick={() => handleSave("sent")}
            disabled={loading}
            className="bg-green-600 hover:bg-green-700"
          >
            <Send className="w-4 h-4 mr-2" />
            Enviar al Proveedor
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}