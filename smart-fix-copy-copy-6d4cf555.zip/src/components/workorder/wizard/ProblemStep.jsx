import React, { useRef } from "react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Image as ImageIcon, Trash2 } from "lucide-react";

export default function ProblemStep({ formData, updateFormData }) {
  const fileRef = useRef(null);

  const addFiles = (files) => {
    const list = Array.from(files || []);
    if (!list.length) return;
    const prev = Array.isArray(formData.media_files) ? formData.media_files : [];
    updateFormData("media_files", [...prev, ...list]);
  };

  const removeAt = (idx) => {
    const prev = Array.isArray(formData.media_files) ? formData.media_files : [];
    const next = prev.filter((_, i) => i !== idx);
    updateFormData("media_files", next);
  };

  return (
    <div className="space-y-6">
      {/* Diagnóstico */}
      <div className="space-y-2">
        <Label className="text-gray-300">Descripción del problema</Label>
        <Textarea
          value={formData.problem_description || ""}
          onChange={(e) => updateFormData("problem_description", e.target.value)}
          placeholder="Ej. No enciende / pantalla quebrada / batería dura poco…"
          className="bg-black/40 border-gray-700 text-white min-h-[110px]"
        />
      </div>

      {/* Evidencias */}
      <div className="space-y-3">
        <Label className="text-gray-300">Fotos / Evidencias</Label>
        <div className="flex items-center gap-3">
          <input
            ref={fileRef}
            type="file"
            accept="image/*,video/*"
            multiple
            className="hidden"
            onChange={(e) => addFiles(e.target.files)}
          />
          <Button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="bg-red-600 hover:bg-red-700"
          >
            <ImageIcon className="w-4 h-4 mr-2" />
            Añadir archivos
          </Button>
          <span className="text-xs text-gray-400">
            Puedes subir imágenes o videos (evidencia del estado del equipo).
          </span>
        </div>

        {/* Previews */}
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
          {(formData.media_files || []).map((f, idx) => {
            const isFile = f instanceof File || f instanceof Blob;
            const url = isFile ? URL.createObjectURL(f) : f.url || f.publicUrl;
            const isVideo =
              (isFile ? (f.type || "").startsWith("video") : (f.mime || "").startsWith("video"));

            return (
              <div
                key={idx}
                className="relative rounded-lg overflow-hidden border border-white/10 bg-black/30"
              >
                {isVideo ? (
                  <video src={url} className="w-full h-28 object-cover" controls />
                ) : (
                  <img src={url} alt={`evidence-${idx}`} className="w-full h-28 object-cover" />
                )}
                <button
                  type="button"
                  onClick={() => removeAt(idx)}
                  className="absolute top-1 right-1 bg-black/60 hover:bg-black/80 rounded-full p-1"
                  title="Quitar"
                >
                  <Trash2 className="w-4 h-4 text-white" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}