import CategoryIconGrid from "./CategoryIconGrid";

export default function DeviceStep(props) {
  return <CategoryIconGrid {...props} />;
}