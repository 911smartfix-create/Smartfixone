import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, User, X, Plus } from "lucide-react";

export default function CustomerStep({ formData, updateFormData }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [searching, setSearching] = useState(false);

  const [phoneRaw, setPhoneRaw] = useState(formData.customer?.phone || "");

  // ---- refs para controlar foco solo una vez
  const didAutofocus = useRef(false);
  const nameInputRef = useRef(null);

  useEffect(() => {
    setPhoneRaw(formData.customer?.phone || "");
  }, [formData.customer?.phone]);

  // Autofocus controlado SOLO una vez y SOLO si ambos campos están vacíos
  useEffect(() => {
    if (didAutofocus.current) return;
    const isEmpty =
      !(formData.customer?.name || "").trim() &&
      !(formData.customer?.last_name || "").trim();
    if (isEmpty && nameInputRef.current) {
      didAutofocus.current = true;
      // pequeño delay para evitar carreras con el modal
      setTimeout(() => nameInputRef.current?.focus(), 50);
    }
  }, [formData.customer?.name, formData.customer?.last_name]);

  useEffect(() => {
    if (searchQuery.trim().length > 2) {
      performSearch(searchQuery.trim());
    } else {
      setSearchResults([]);
      setShowResults(false);
    }
  }, [searchQuery]);

  const performSearch = async (q) => {
    setSearching(true);
    try {
      const customers = await base44.entities.Customer.list();
      const query = q.toLowerCase();
      const filtered = (customers || []).filter((c) =>
        (c.name || "").toLowerCase().includes(query) ||
        (c.phone || "").toLowerCase().includes(query) ||
        (c.email || "").toLowerCase().includes(query)
      );
      setSearchResults(filtered.slice(0, 8));
      setShowResults(true);
    } catch (e) {
      console.error("Error searching customers:", e);
    } finally {
      setSearching(false);
    }
  };

  const handleSelectCustomer = (customer) => {
    const [firstName, ...lastNameParts] = (customer.name || "").split(" ");
    updateFormData("customer", {
      name: firstName || "",
      last_name: lastNameParts.join(" "),
      phone: customer.phone || "",
      email: customer.email || "",
      additional_phones: customer.additional_phones || [],
    });
    updateFormData("existing_customer_id", customer.id);
    setPhoneRaw(customer.phone || "");
    setSearchQuery("");
    setShowResults(false);
  };

  const handleAddPhone = () => {
    const phones = formData.customer.additional_phones || [];
    updateFormData("customer", {
      ...formData.customer,
      additional_phones: [...phones, ""],
    });
  };

  const handleUpdateAdditionalPhone = (index, value) => {
    const onlyDigits = value.replace(/\D/g, "").slice(0, 10);
    const phones = [...(formData.customer.additional_phones || [])];
    phones[index] = onlyDigits;
    updateFormData("customer", { ...formData.customer, additional_phones: phones });
  };

  const handleRemovePhone = (index) => {
    const phones = (formData.customer.additional_phones || []).filter((_, i) => i !== index);
    updateFormData("customer", { ...formData.customer, additional_phones: phones });
  };

  const formatPhonePretty = (raw) => {
    const digits = (raw || "").replace(/\D/g, "").slice(0, 10);
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
    return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  };

  const stopEnterPropagation = (e) => {
    if (e.key === "Enter") e.stopPropagation();
  };

  const ensureVisible = (e) => {
    try {
      e.target.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch {}
  };

  return (
    <div className="space-y-4">
      {/* Buscar cliente */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-5 h-5" />
        <Input
          id="customer-search"
          name="customerSearch"
          autoComplete="off"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={stopEnterPropagation}
          onFocus={ensureVisible}
          placeholder="Buscar por teléfono, nombre o email..."
          className="pl-10 bg-black border-gray-700 text-white h-12 text-base"
        />

        {showResults && searchResults.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-[#2B2B2B] border border-red-900/30 rounded-lg shadow-xl z-50 max-h-64 overflow-y-auto custom-scrollbar">
            {searchResults.map((customer) => (
              <button
                key={customer.id}
                type="button"
                onClick={() => handleSelectCustomer(customer)}
                className="w-full text-left p-3 hover:bg-gray-800 cursor-pointer border-b border-gray-800 last:border-b-0 flex items-center gap-3"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full grid place-items-center flex-shrink-0">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{customer.name}</p>
                  {customer.phone && <p className="text-xs text-gray-400">{formatPhonePretty(customer.phone)}</p>}
                  {customer.email && (
                    <p className="text-xs text-gray-500 truncate">{customer.email}</p>
                  )}
                </div>
                <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">
                  {customer.total_orders || 0} órdenes
                </Badge>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Formulario */}
      <div className="space-y-4 pt-4 border-t border-gray-800">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* NOMBRE */}
          <div className="space-y-2">
            <Label htmlFor="first-name" className="text-gray-300">Nombre *</Label>
            <Input
              id="first-name"
              name="firstName"
              autoComplete="given-name"
              ref={nameInputRef}
              value={formData.customer.name}
              onChange={(e) =>
                updateFormData("customer", { ...formData.customer, name: e.target.value })
              }
              onKeyDown={stopEnterPropagation}
              onFocus={ensureVisible}
              placeholder="Juan"
              className="bg-black border-gray-700 text-white h-12 text-base"
            />
          </div>

          {/* APELLIDO */}
          <div className="space-y-2">
            <Label htmlFor="last-name" className="text-gray-300">Apellido *</Label>
            <Input
              id="last-name"
              name="lastName"
              autoComplete="family-name"
              value={formData.customer.last_name}
              onChange={(e) =>
                updateFormData("customer", { ...formData.customer, last_name: e.target.value })
              }
              onKeyDown={stopEnterPropagation}
              onFocus={ensureVisible}
              placeholder="Pérez"
              className="bg-black border-gray-700 text-white h-12 text-base"
            />
          </div>
        </div>

        {/* TELÉFONO */}
        <div className="space-y-2">
          <Label htmlFor="main-phone" className="text-gray-300">Teléfono Principal *</Label>
          <Input
            id="main-phone"
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            value={phoneRaw}
            onChange={(e) => {
              const digits = e.target.value.replace(/\D/g, "").slice(0, 10);
              setPhoneRaw(digits);
              updateFormData("customer", { ...formData.customer, phone: digits });
            }}
            onBlur={() => {
              const pretty = formatPhonePretty(phoneRaw);
              setPhoneRaw(pretty);
              updateFormData("customer", { ...formData.customer, phone: pretty });
            }}
            onKeyDown={stopEnterPropagation}
            onFocus={(e) => {
              const digits = (phoneRaw || "").replace(/\D/g, "");
              setPhoneRaw(digits);
              ensureVisible(e);
            }}
            placeholder="787-555-0123"
            className="bg-black border-gray-700 text-white h-12 text-base tracking-wide"
            maxLength={14}
          />
        </div>

        {/* TELÉFONOS ADICIONALES */}
        {(formData.customer.additional_phones || []).length > 0 && (
          <div className="space-y-2">
            <Label className="text-gray-300">Teléfonos Adicionales</Label>
            {formData.customer.additional_phones.map((phone, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  value={phone}
                  onChange={(e) => handleUpdateAdditionalPhone(index, e.target.value)}
                  onKeyDown={stopEnterPropagation}
                  onFocus={ensureVisible}
                  placeholder="7875550456"
                  className="bg-black border-gray-700 text-white h-12 text-base flex-1"
                  maxLength={10}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => handleRemovePhone(index)}
                  className="border-gray-700 text-gray-300 hover:border-red-500 hover:text-red-400"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}

        <Button
          type="button"
          variant="outline"
          onClick={handleAddPhone}
          className="bg-background px-4 h-11 w-full border-gray-700 hover:border-[#FF0000] hover:text-[#FF0000]"
        >
          <Plus className="w-4 h-4 mr-2" />
          Añadir Teléfono Adicional
        </Button>

        {/* EMAIL */}
        <div className="space-y-2">
          <Label htmlFor="email" className="text-gray-300">Email (opcional)</Label>
          <Input
            id="email"
            name="email"
            type="email"
            inputMode="email"
            autoComplete="email"
            value={formData.customer.email}
            onChange={(e) =>
              updateFormData("customer", { ...formData.customer, email: e.target.value })
            }
            onKeyDown={stopEnterPropagation}
            onFocus={ensureVisible}
            placeholder="cliente@example.com"
            className="bg-black border-gray-700 text-white h-12 text-base"
          />
        </div>

        <div className="text-xs text-gray-500 mt-4">* Campos obligatorios</div>
      </div>
    </div>
  );
}