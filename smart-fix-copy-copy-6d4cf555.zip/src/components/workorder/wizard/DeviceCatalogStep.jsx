
import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Smartphone, Laptop, Tablet, Watch, Gamepad2, Camera, Box, ChevronRight, Check, Plus, Edit3 } from "lucide-react";

const DEVICE_CATEGORIES = [
  { id: "phone", label: "Teléfono", icon: Smartphone },
  { id: "laptop", label: "Laptop", icon: Laptop },
  { id: "tablet", label: "Tablet", icon: Tablet },
  { id: "watch", label: "Reloj", icon: Watch },
  { id: "console", label: "Consola", icon: Gamepad2 },
  { id: "camera", label: "Cámara", icon: Camera },
  { id: "other", label: "Otro", icon: Box }
];

// ✅ Marcas populares por categoría
const DEFAULT_BRANDS = {
  phone: ["Apple", "Samsung", "Motorola", "Google", "OnePlus", "Xiaomi"],
  laptop: ["Apple", "Dell", "HP", "Lenovo", "Asus", "Acer"],
  tablet: ["Apple", "Samsung", "Microsoft", "Amazon", "Lenovo"],
  watch: ["Apple", "Samsung", "Garmin", "Fitbit", "Fossil"],
  console: ["Sony", "Microsoft", "Nintendo", "Steam Deck"],
  camera: ["Canon", "Nikon", "Sony", "GoPro", "DJI"],
  other: []
};

// ✅ Modelos ordenados del más nuevo al más viejo
const DEFAULT_MODELS = {
  // Phones
  "Apple": ["iPhone 15 Pro Max", "iPhone 15 Pro", "iPhone 15", "iPhone 14", "iPhone 13", "iPhone 12", "iPhone 11", "iPhone SE"],
  "Samsung": ["Galaxy S24 Ultra", "Galaxy S24", "Galaxy S23", "Galaxy Z Fold 5", "Galaxy Z Flip 5", "Galaxy A54"],
  "Motorola": ["Moto G Power", "Moto G Stylus", "Edge+", "Razr"],
  "Google": ["Pixel 8 Pro", "Pixel 8", "Pixel 7", "Pixel 6"],
  
  // Laptops
  "Dell": ["XPS 15", "XPS 13", "Inspiron 15", "Latitude 5420"],
  "HP": ["Spectre x360", "Envy", "Pavilion", "EliteBook"],
  "Lenovo": ["ThinkPad X1", "ThinkPad T14", "Yoga", "IdeaPad"],
  "Asus": ["ROG Strix", "ZenBook", "VivoBook", "TUF Gaming"],
  
  // Tablets
  "Microsoft": ["Surface Pro 9", "Surface Go 3"],
  "Amazon": ["Fire HD 10", "Fire 7"],
  
  // Watches
  "Garmin": ["Fenix 7", "Forerunner", "Venu"],
  "Fitbit": ["Sense 2", "Versa 4", "Charge 5"],
  
  // Consoles
  "Sony": ["PlayStation 5", "PlayStation 4"],
  "Microsoft": ["Xbox Series X", "Xbox Series S"],
  "Nintendo": ["Switch OLED", "Switch", "Switch Lite"],
  
  // Cameras
  "Canon": ["EOS R5", "EOS R6", "Rebel T7"],
  "Nikon": ["Z9", "Z6 II", "D850"],
  "GoPro": ["Hero 12", "Hero 11", "Hero 10"],
  "DJI": ["Mini 3 Pro", "Air 3", "Mavic 3"]
};

// ✅ Modelos específicos de Apple por tipo (del más nuevo al más viejo)
const APPLE_MODELS_BY_TYPE = {
  phone: ["iPhone 15 Pro Max", "iPhone 15 Pro", "iPhone 15", "iPhone 14", "iPhone 13", "iPhone 12", "iPhone 11", "iPhone SE"],
  laptop: ["MacBook Pro 16\"", "MacBook Pro 14\"", "MacBook Air M2", "MacBook Air M1"],
  tablet: ["iPad Pro 12.9\"", "iPad Pro 11\"", "iPad Air", "iPad", "iPad Mini"],
  watch: ["Apple Watch Ultra 2", "Apple Watch Series 9", "Apple Watch SE"]
};

// ✅ Cargar marcas y modelos personalizados desde localStorage
const loadCustomBrands = () => {
  try {
    const stored = localStorage.getItem("custom_brands");
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
};

const loadCustomModels = () => {
  try {
    const stored = localStorage.getItem("custom_models");
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
};

const saveCustomBrands = (brands) => {
  try {
    localStorage.setItem("custom_brands", JSON.stringify(brands));
  } catch (e) {
    console.warn("Could not save custom brands", e);
  }
};

const saveCustomModels = (models) => {
  try {
    localStorage.setItem("custom_models", JSON.stringify(models));
  } catch (e) {
    console.warn("Could not save custom models", e);
  }
};

export default function DeviceCatalogStep({ formData, updateFormData }) {
  const [selectedCategory, setSelectedCategory] = useState(formData.device_category?.id || "");
  const [brand, setBrand] = useState(formData.device_brand || "");
  const [model, setModel] = useState(formData.device_model || "");
  const [serial, setSerial] = useState(formData.device_serial || "");
  
  const [showCustomBrand, setShowCustomBrand] = useState(false);
  const [customBrand, setCustomBrand] = useState("");
  
  const [showCustomModel, setShowCustomModel] = useState(false);
  const [customModel, setCustomModel] = useState("");

  const [customBrands, setCustomBrands] = useState(loadCustomBrands());
  const [customModels, setCustomModels] = useState(loadCustomModels());

  useEffect(() => {
    if (selectedCategory) {
      const category = DEVICE_CATEGORIES.find(c => c.id === selectedCategory);
      updateFormData("device_category", category);
    }
  }, [selectedCategory]);

  useEffect(() => {
    updateFormData("device_brand", brand);
  }, [brand]);

  useEffect(() => {
    updateFormData("device_model", model);
  }, [model]);

  useEffect(() => {
    updateFormData("device_serial", serial);
  }, [serial]);

  const handleCategorySelect = (categoryId) => {
    setSelectedCategory(categoryId);
    setBrand("");
    setModel("");
    setShowCustomBrand(false);
    setShowCustomModel(false);
  };

  const handleBrandSelect = (brandName) => {
    setBrand(brandName);
    setModel("");
    setShowCustomBrand(false);
    setShowCustomModel(false);
  };

  const handleAddCustomBrand = () => {
    if (!customBrand.trim()) return;
    
    const newBrand = customBrand.trim();
    setBrand(newBrand);
    
    // ✅ Guardar marca personalizada
    const updated = { ...customBrands };
    if (!updated[selectedCategory]) updated[selectedCategory] = [];
    if (!updated[selectedCategory].includes(newBrand)) {
      updated[selectedCategory].push(newBrand);
      setCustomBrands(updated);
      saveCustomBrands(updated);
    }
    
    setCustomBrand("");
    setShowCustomBrand(false);
  };

  const handleModelSelect = (modelName) => {
    setModel(modelName);
    setShowCustomModel(false);
  };

  const handleAddCustomModel = () => {
    if (!customModel.trim()) return;
    
    const newModel = customModel.trim();
    setModel(newModel);
    
    // ✅ Guardar modelo personalizado
    const updated = { ...customModels };
    if (!updated[brand]) updated[brand] = [];
    if (!updated[brand].includes(newModel)) {
      updated[brand].unshift(newModel); // Añadir al inicio (más nuevo)
      setCustomModels(updated);
      saveCustomModels(updated);
    }
    
    setCustomModel("");
    setShowCustomModel(false);
  };

  // ✅ Obtener lista completa de marcas (default + custom)
  const getAvailableBrands = () => {
    const defaults = DEFAULT_BRANDS[selectedCategory] || [];
    const customs = customBrands[selectedCategory] || [];
    return [...defaults, ...customs];
  };

  // ✅ Obtener modelos disponibles (default + custom)
  const availableModels = () => {
    let defaults = [];
    
    if (brand === "Apple" && selectedCategory) {
      defaults = APPLE_MODELS_BY_TYPE[selectedCategory] || [];
    } else {
      defaults = DEFAULT_MODELS[brand] || [];
    }
    
    const customs = customModels[brand] || [];
    return [...customs, ...defaults]; // Customs primero (son los más nuevos añadidos)
  };

  const isStep1Done = !!selectedCategory;
  const isStep2Done = isStep1Done && !!brand;
  const isStep3Done = isStep2Done && !!model;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-white text-lg font-semibold mb-2">Información del Dispositivo</h3>
        <div className="flex items-center gap-2 text-sm flex-wrap">
          <div className={`flex items-center gap-1 ${isStep1Done ? 'text-emerald-400' : 'text-gray-400'}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${isStep1Done ? 'bg-emerald-600/20 border-2 border-emerald-500' : 'bg-black/40 border-2 border-gray-700'}`}>
              {isStep1Done ? <Check className="w-4 h-4" /> : '1'}
            </div>
            <span>Tipo</span>
          </div>
          <ChevronRight className="w-4 h-4 text-gray-600" />
          <div className={`flex items-center gap-1 ${isStep2Done ? 'text-emerald-400' : 'text-gray-400'}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${isStep2Done ? 'bg-emerald-600/20 border-2 border-emerald-500' : 'bg-black/40 border-2 border-gray-700'}`}>
              {isStep2Done ? <Check className="w-4 h-4" /> : '2'}
            </div>
            <span>Marca</span>
          </div>
          <ChevronRight className="w-4 h-4 text-gray-600" />
          <div className={`flex items-center gap-1 ${isStep3Done ? 'text-emerald-400' : 'text-gray-400'}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${isStep3Done ? 'bg-emerald-600/20 border-2 border-emerald-500' : 'bg-black/40 border-2 border-gray-700'}`}>
              {isStep3Done ? <Check className="w-4 h-4" /> : '3'}
            </div>
            <span>Modelo</span>
          </div>
        </div>
      </div>

      {/* PASO 1: Tipo de Dispositivo */}
      <Card className={`p-4 border-2 transition-all ${isStep1Done ? 'border-emerald-500/30 bg-emerald-600/5' : 'border-white/10 bg-black/40'}`}>
        <Label className="text-gray-300 mb-3 block font-semibold">
          1. Selecciona el Tipo de Dispositivo
        </Label>
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
          {DEVICE_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategorySelect(cat.id)}
                className={`
                  relative p-4 rounded-lg border-2 transition-all flex flex-col items-center gap-2
                  ${isSelected 
                    ? "border-red-500 bg-red-600/20 text-white shadow-lg shadow-red-600/20" 
                    : "border-white/10 bg-black/40 text-gray-400 hover:border-white/30 hover:bg-black/60"
                  }
                `}
              >
                <Icon className="w-6 h-6" />
                <span className="text-xs font-medium">{cat.label}</span>
                {isSelected && <Check className="w-4 h-4 text-red-400 absolute top-2 right-2" />}
              </button>
            );
          })}
        </div>
      </Card>

      {/* PASO 2: Marca */}
      {isStep1Done && (
        <Card className={`p-4 border-2 transition-all ${isStep2Done ? 'border-emerald-500/30 bg-emerald-600/5' : 'border-white/10 bg-black/40'}`}>
          <Label className="text-gray-300 mb-3 block font-semibold">
            2. Selecciona la Marca
          </Label>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-3">
            {getAvailableBrands().map((brandName) => {
              const isSelected = brand === brandName;
              // const isCustom = customBrands[selectedCategory]?.includes(brandName); // Removed custom indicator
              
              return (
                <button
                  key={brandName}
                  type="button"
                  onClick={() => handleBrandSelect(brandName)}
                  className={`
                    relative p-3 rounded-lg border-2 transition-all text-sm font-medium text-center
                    ${isSelected 
                      ? "border-red-500 bg-red-600/20 text-white shadow-lg" 
                      : "border-white/10 bg-black/40 text-gray-300 hover:border-white/30 hover:bg-black/60"
                    }
                  `}
                >
                  {brandName}
                  {/* {isCustom && <span className="ml-1 text-xs text-emerald-400">★</span>} */} {/* Removed custom indicator */}
                  {isSelected && <Check className="w-4 h-4 text-red-400 absolute top-2 right-2" />}
                </button>
              );
            })}
            
            {/* Botón Añadir Otra */}
            {!showCustomBrand && (
              <button
                type="button"
                onClick={() => setShowCustomBrand(true)}
                className="p-3 rounded-lg border-2 border-dashed border-white/20 bg-black/20 text-gray-400 hover:border-white/40 hover:text-white transition-all flex items-center justify-center gap-2 text-sm font-medium"
              >
                <Plus className="w-4 h-4" />
                Añadir Otra
              </button>
            )}
          </div>

          {/* Input para marca personalizada */}
          {showCustomBrand && (
            <div className="flex gap-2 mt-3">
              <Input
                type="text"
                placeholder="Escribe la marca..."
                value={customBrand}
                onChange={(e) => setCustomBrand(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddCustomBrand()}
                className="bg-black/40 border-white/15 text-white h-10"
                autoFocus
              />
              <Button 
                onClick={handleAddCustomBrand} 
                className="bg-red-600 hover:bg-red-700"
                disabled={!customBrand.trim()}
              >
                <Check className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {setShowCustomBrand(false); setCustomBrand("");}}
                className="border-white/15"
              >
                Cancelar
              </Button>
            </div>
          )}

          {brand && !showCustomBrand && (
            <div className="mt-3 flex items-center justify-between bg-emerald-600/10 border border-emerald-500/30 rounded-lg p-3">
              <div className="flex items-center gap-2 text-sm text-emerald-400">
                <Check className="w-4 h-4" />
                <span>Marca: <strong>{brand}</strong></span>
              </div>
              <button
                type="button"
                onClick={() => {setBrand(""); setModel("");}}
                className="text-xs text-gray-400 hover:text-white flex items-center gap-1"
              >
                <Edit3 className="w-3 h-3" />
                Cambiar
              </button>
            </div>
          )}
        </Card>
      )}

      {/* PASO 3: Modelo */}
      {isStep2Done && (
        <Card className={`p-4 border-2 transition-all ${isStep3Done ? 'border-emerald-500/30 bg-emerald-600/5' : 'border-white/10 bg-black/40'}`}>
          <Label className="text-gray-300 mb-3 block font-semibold">
            3. Selecciona el Modelo
          </Label>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
            {availableModels().map((modelName) => {
              const isSelected = model === modelName;
              // const isCustom = customModels[brand]?.includes(modelName); // Removed custom indicator
              
              return (
                <button
                  key={modelName}
                  type="button"
                  onClick={() => handleModelSelect(modelName)}
                  className={`
                    relative p-3 rounded-lg border-2 transition-all text-sm text-center
                    ${isSelected 
                      ? "border-red-500 bg-red-600/20 text-white shadow-lg" 
                      : "border-white/10 bg-black/40 text-gray-300 hover:border-white/30 hover:bg-black/60"
                    }
                  `}
                >
                  {modelName}
                  {/* {isCustom && <span className="ml-1 text-xs text-emerald-400">★</span>} */} {/* Removed custom indicator */}
                  {isSelected && <Check className="w-4 h-4 text-red-400 absolute top-2 right-2" />}
                </button>
              );
            })}
            
            {/* Botón Añadir Otro */}
            {!showCustomModel && (
              <button
                type="button"
                onClick={() => setShowCustomModel(true)}
                className="p-3 rounded-lg border-2 border-dashed border-white/20 bg-black/20 text-gray-400 hover:border-white/40 hover:text-white transition-all flex items-center justify-center gap-2 text-sm font-medium"
              >
                <Plus className="w-4 h-4" />
                Añadir Otro
              </button>
            )}
          </div>

          {/* Input para modelo personalizado */}
          {showCustomModel && (
            <div className="flex gap-2 mt-3">
              <Input
                type="text"
                placeholder="Escribe el modelo..."
                value={customModel}
                onChange={(e) => setCustomModel(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddCustomModel()}
                className="bg-black/40 border-white/15 text-white h-10"
                autoFocus
              />
              <Button 
                onClick={handleAddCustomModel} 
                className="bg-red-600 hover:bg-red-700"
                disabled={!customModel.trim()}
              >
                <Check className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {setShowCustomModel(false); setCustomModel("");}}
                className="border-white/15"
              >
                Cancelar
              </Button>
            </div>
          )}

          {model && !showCustomModel && (
            <div className="mt-3 flex items-center justify-between bg-emerald-600/10 border border-emerald-500/30 rounded-lg p-3">
              <div className="flex items-center gap-2 text-sm text-emerald-400">
                <Check className="w-4 h-4" />
                <span>Modelo: <strong>{model}</strong></span>
              </div>
              <button
                type="button"
                onClick={() => setModel("")}
                className="text-xs text-gray-400 hover:text-white flex items-center gap-1"
              >
                <Edit3 className="w-3 h-3" />
                Cambiar
              </button>
            </div>
          )}
        </Card>
      )}

      {/* PASO 4 (OPCIONAL): Serial/IMEI */}
      {isStep3Done && (
        <Card className="p-4 border-2 border-white/10 bg-black/40">
          <Label htmlFor="device-serial" className="text-gray-300 mb-3 block font-semibold">
            4. Serial / IMEI <span className="text-gray-500 font-normal">(opcional)</span>
          </Label>
          <Input
            id="device-serial"
            type="text"
            placeholder="Ej: 354123456789012"
            value={serial}
            onChange={(e) => setSerial(e.target.value)}
            className="bg-black/40 border-white/15 text-white placeholder:text-gray-500 h-12 text-base font-mono"
          />
        </Card>
      )}

      {/* Resumen Final */}
      {isStep3Done && (
        <Card className="bg-gradient-to-br from-emerald-600/10 to-emerald-800/10 border-emerald-500/30 p-5">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-xl bg-emerald-600/20 flex items-center justify-center flex-shrink-0">
              {React.createElement(
                DEVICE_CATEGORIES.find(c => c.id === selectedCategory)?.icon || Box,
                { className: "w-7 h-7 text-emerald-400" }
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-emerald-400 font-medium mb-1">✓ Dispositivo Registrado</p>
              <p className="text-white text-lg font-bold">{brand} {model}</p>
              <p className="text-xs text-gray-400 mt-1">
                {DEVICE_CATEGORIES.find(c => c.id === selectedCategory)?.label}
              </p>
              {serial && (
                <p className="text-xs text-gray-400 mt-2 font-mono bg-black/20 inline-block px-2 py-1 rounded">
                  S/N: {serial}
                </p>
              )}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
