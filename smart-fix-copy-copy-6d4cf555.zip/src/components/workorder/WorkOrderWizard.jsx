
import React, { useState, useEffect, useMemo, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Mail, Loader2 } from "lucide-react";

import CustomerStep from "./wizard/CustomerStep";
import DeviceCatalogStep from "./wizard/DeviceCatalogStep";
import ProblemStep from "./wizard/ProblemStep";
import SecurityStep from "./wizard/SecurityStep";
import ChecklistIconsStep from "./wizard/ChecklistIconsStep";
import NotificationService from "../notifications/NotificationService";

const INITIAL_FORM_DATA = {
  customer: { name: "", last_name: "", phone: "", additional_phones: [], email: "" },
  existing_customer_id: null,
  device_category: null,
  device_brand: null,
  device_subcategory: null,
  device_family: null,
  device_model: null,
  device_serial: "",
  problem_description: "",
  comments: "",
  security: { device_password: "", device_pin: "", pattern_mode: "none", pattern_image: null },
  media_files: [],
  checklist_items: [],
  checklist_notes: "",
  signature: null,
  terms_accepted: true, // ✅ Auto-aceptar términos
  assigned_to: "",
  assigned_to_name: "",
};

// ✅ Pasos sin firma (eliminado "signature")
const DEFAULT_STEPS = ["customer", "brand", "problem", "security", "checklist"];

function WizardStepper({ steps, currentStep, onStepClick, getStepStatus, getStepLabel, maxReachable }) {
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      const active = scrollRef.current.querySelector('[data-active="true"]');
      if (active) {
        active.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }
  }, [currentStep]);

  return (
    <div 
      ref={scrollRef}
      className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scroll-smooth"
      style={{ scrollSnapType: 'x mandatory', WebkitOverflowScrolling: 'touch' }}
    >
      {steps.map((step, idx) => {
        const status = getStepStatus(idx);
        const label = getStepLabel(step);
        const isClickable = idx <= maxReachable;

        return (
          <button
            key={step}
            data-active={idx === currentStep}
            onClick={() => isClickable && onStepClick(idx)}
            disabled={!isClickable}
            className={`
              flex flex-col items-center gap-1 min-w-[64px] px-2 py-2 rounded-lg transition-all
              ${status === "done" ? "opacity-80 hover:opacity-100" : ""}
              ${status === "active" ? "bg-red-600/10" : ""}
              ${!isClickable ? "opacity-40 cursor-not-allowed" : "cursor-pointer hover:bg-white/5"}
            `}
            style={{ scrollSnapAlign: 'start' }}
          >
            <div className={`
              w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all
              ${status === "done" 
                ? "bg-emerald-600/20 border-2 border-emerald-500 text-emerald-300" 
                : status === "active"
                ? "bg-red-600 border-2 border-red-500 text-white shadow-lg shadow-red-600/30"
                : "bg-black/40 border-2 border-gray-700 text-gray-400"
              }
            `}>
              {status === "done" ? <Check className="w-5 h-5" /> : idx + 1}
            </div>
            <span className={`text-[10px] font-medium text-center leading-tight ${status === "active" ? "text-white" : "text-gray-400"}`}>
              {label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

export default function WorkOrderWizard({ open, onClose, onSuccess, preloadedCustomer }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);
  const [taxRate, setTaxRate] = useState(0.115);
  const [autoAssign, setAutoAssign] = useState(true);

  const [enabledSteps, setEnabledSteps] = useState(DEFAULT_STEPS);
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState(INITIAL_FORM_DATA);

  useEffect(() => {
    if (!open) return;
    loadUser();
    loadTaxRate();

    if (preloadedCustomer) {
      const [firstName, ...lastNameParts] = (preloadedCustomer.name || "").split(" ");
      setFormData((prev) => ({
        ...INITIAL_FORM_DATA,
        customer: {
          name: firstName || "",
          last_name: lastNameParts.join(" "),
          phone: preloadedCustomer.phone || "",
          email: preloadedCustomer.email || "",
          additional_phones: preloadedCustomer.additional_phones || []
        },
        existing_customer_id: preloadedCustomer.id || null
      }));
    } else {
      setFormData(INITIAL_FORM_DATA);
    }

    setCurrentStep(0);
  }, [open, preloadedCustomer]);

  useEffect(() => {
    if (open) return;
    const t = setTimeout(() => {
      setFormData(INITIAL_FORM_DATA);
      setCurrentStep(0);
    }, 300);
    return () => clearTimeout(t);
  }, [open]);

  const loadUser = async () => {
    try {
      const u = await base44.auth.me();
      setUser(u || null);
    } catch { 
      setUser(null); 
    }
  };

  const loadTaxRate = async () => {
    try {
      const rows = await base44.entities.SystemConfig.filter({ key: "global_settings" });
      const raw = rows?.[0]?.value;
      if (!raw) return;
      let parsed = null;
      try { 
        parsed = typeof raw === "string" ? JSON.parse(raw) : raw; 
      } catch {}
      const t = parseFloat(parsed?.tax_rate);
      if (!Number.isNaN(t)) setTaxRate(t);
    } catch {}
  };

  const updateFormData = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const stepName = enabledSteps[currentStep] || "";

  const getStepTitle = (name) => {
    const titles = {
      customer: "Cliente",
      brand: "Dispositivo",
      problem: "Problema & Fotos",
      security: "Seguridad del equipo",
      checklist: "Inspección del equipo"
    };
    return titles[name] || name;
  };

  const getStepLabel = (name) => {
    const labels = {
      customer: "Cliente",
      brand: "Dispositivo",
      problem: "Problema",
      security: "Seguridad",
      checklist: "Checklist"
    };
    return labels[name] || name;
  };

  const canProceedFromStep = (stepName) => {
    switch (stepName) {
      case "customer":
        return !!formData.customer.name && !!formData.customer.phone;
      case "brand":
        return !!formData.device_model;
      default:
        return true;
    }
  };

  const getMaxReachableStep = () => {
    for (let i = 0; i < enabledSteps.length; i++) {
      if (!canProceedFromStep(enabledSteps[i])) {
        return Math.max(0, i);
      }
    }
    return enabledSteps.length - 1;
  };

  const maxReachable = getMaxReachableStep();
  const canProceed = () => canProceedFromStep(stepName);

  const handleStepClick = (idx) => {
    if (idx > maxReachable) {
      alert("Complete los pasos anteriores primero");
      return;
    }
    setCurrentStep(idx);
  };

  const getStepStatus = (idx) => {
    if (idx < currentStep) return "done";
    if (idx === currentStep) return "active";
    return "todo";
  };

  const getStepComponent = (name) => {
    const props = { formData, updateFormData, taxRate, currentUser: user };

    switch (name) {
      case "customer": 
        return <CustomerStep {...props} />;
      case "brand":
        return <DeviceCatalogStep {...props} />;
      case "problem": 
        return <ProblemStep {...props} />;
      case "security": 
        return <SecurityStep {...props} />;
      case "checklist": 
        return <ChecklistIconsStep {...props} />;
      default: 
        return null;
    }
  };

  const handleNext = () => {
    if (currentStep < enabledSteps.length - 1) {
      setCurrentStep((s) => s + 1);
    } else {
      handleSubmit();
    }
  };

  const handleClose = () => {
    setFormData(INITIAL_FORM_DATA);
    setCurrentStep(0);
    if (onClose) onClose();
  };

  const encryptData = (data) => {
    try { return btoa(String(data)); } catch { return String(data); }
  };

  const toFileFromDataURL = async (dataURL, filename) => {
    const res = await fetch(dataURL);
    const blob = await res.blob();
    return new File([blob], filename, { type: blob.type || "image/png" });
  };

  // ✅ Función para enviar email automático al cliente
  const sendCustomerEmail = async (order, customerEmail, photoUrls = []) => {
    if (!customerEmail) {
      console.warn("No customer email provided, skipping email");
      return;
    }

    setSendingEmail(true);
    try {
      const deviceInfo = `${order.device_brand || ""} ${order.device_model || ""}`.trim() || "Dispositivo";
      const problemDesc = order.initial_problem || "No especificado";
      
      // ✅ Generar HTML con fotos embebidas
      let photosHTML = "";
      if (photoUrls.length > 0) {
        photosHTML = `
          <div style="margin-top: 20px;">
            <h3 style="color: #333; font-size: 16px; margin-bottom: 10px;">📸 Fotos del equipo:</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px;">
              ${photoUrls.map(url => `
                <img src="${url}" alt="Foto del equipo" style="width: 100%; height: auto; border-radius: 8px; border: 1px solid #ddd;" />
              `).join('')}
            </div>
          </div>
        `;
      }

      const emailBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
  <div style="max-width: 600px; margin: 20px auto; background-color: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
    
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #FF0000 0%, #CC0000 100%); padding: 30px 20px; text-align: center;">
      <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: bold;">911 SmartFix</h1>
      <p style="margin: 10px 0 0 0; color: #ffffff; font-size: 14px;">Confirmación de Orden de Servicio</p>
    </div>

    <!-- Body -->
    <div style="padding: 30px 20px;">
      <p style="color: #333; font-size: 16px; line-height: 1.6;">
        Hola <strong>${formData.customer.name} ${formData.customer.last_name}</strong>,
      </p>
      
      <p style="color: #666; font-size: 14px; line-height: 1.6;">
        Hemos recibido tu equipo y creado una orden de servicio. A continuación los detalles:
      </p>

      <!-- Order Details Card -->
      <div style="background-color: #f8f9fa; border-left: 4px solid #FF0000; padding: 20px; margin: 20px 0; border-radius: 5px;">
        <h2 style="margin: 0 0 15px 0; color: #FF0000; font-size: 18px;">📋 Detalles de la Orden</h2>
        
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 8px 0; color: #666; font-size: 14px; font-weight: bold;">Número de Orden:</td>
            <td style="padding: 8px 0; color: #333; font-size: 14px;">${order.order_number}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #666; font-size: 14px; font-weight: bold;">Dispositivo:</td>
            <td style="padding: 8px 0; color: #333; font-size: 14px;">${deviceInfo}</td>
          </tr>
          ${order.device_serial ? `
          <tr>
            <td style="padding: 8px 0; color: #666; font-size: 14px; font-weight: bold;">Serial/IMEI:</td>
            <td style="padding: 8px 0; color: #333; font-size: 14px;">${order.device_serial}</td>
          </tr>
          ` : ''}
          <tr>
            <td style="padding: 8px 0; color: #666; font-size: 14px; font-weight: bold;">Problema Reportado:</td>
            <td style="padding: 8px 0; color: #333; font-size: 14px;">${problemDesc}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #666; font-size: 14px; font-weight: bold;">Estado:</td>
            <td style="padding: 8px 0; color: #333; font-size: 14px;"><span style="background-color: #4CAF50; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px;">En Recepción</span></td>
          </tr>
          ${order.assigned_to_name ? `
          <tr>
            <td style="padding: 8px 0; color: #666; font-size: 14px; font-weight: bold;">Técnico Asignado:</td>
            <td style="padding: 8px 0; color: #333; font-size: 14px;">${order.assigned_to_name}</td>
          </tr>
          ` : ''}
        </table>
      </div>

      ${photosHTML}

      <!-- Next Steps -->
      <div style="background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 5px; padding: 15px; margin: 20px 0;">
        <h3 style="margin: 0 0 10px 0; color: #856404; font-size: 16px;">⏭️ Próximos Pasos</h3>
        <ul style="margin: 0; padding-left: 20px; color: #856404; font-size: 14px; line-height: 1.8;">
          <li>Realizaremos el diagnóstico de tu equipo</li>
          <li>Te contactaremos con el presupuesto estimado</li>
          <li>Una vez aprobado, comenzaremos la reparación</li>
          <li>Te notificaremos cuando esté listo para recoger</li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div style="text-align: center; padding: 20px 0; border-top: 1px solid #eee; margin-top: 30px;">
        <p style="color: #666; font-size: 14px; margin: 5px 0;">
          ¿Preguntas? Contáctanos:
        </p>
        <p style="color: #FF0000; font-size: 16px; font-weight: bold; margin: 5px 0;">
          ${formData.customer.phone}
        </p>
      </div>
    </div>

    <!-- Footer -->
    <div style="background-color: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee;">
      <p style="margin: 0; color: #999; font-size: 12px;">
        © ${new Date().getFullYear()} 911 SmartFix. Todos los derechos reservados.
      </p>
      <p style="margin: 10px 0 0 0; color: #999; font-size: 12px;">
        Este es un correo automático, por favor no responder.
      </p>
    </div>

  </div>
</body>
</html>
      `;

      // ✅ Intentar enviar email pero NO bloquear si falla
      try {
        await base44.integrations.Core.SendEmail({
          from_name: "911 SmartFix",
          to: customerEmail,
          subject: `✅ Orden Recibida - ${order.order_number}`,
          body: emailBody
        });

        console.log("✅ Email sent successfully to:", customerEmail);
      } catch (emailError) {
        // ✅ Si el error es porque el usuario no está en la app, crear un log pero NO fallar
        console.warn("⚠️ Could not send email to customer:", emailError.message || emailError);
        
        // Guardar el intento de email en un log para referencia futura
        try {
          await base44.entities.EmailLog?.create?.({
            order_id: order.id,
            customer_id: order.customer_id, // Use the customer ID from the created order
            to_email: customerEmail,
            subject: `✅ Orden Recibida - ${order.order_number}`,
            body: emailBody,
            event_type: "order_created",
            status: "failed",
            error_message: emailError.message || String(emailError),
            sent_by: user?.email || "System"
          });
        } catch (logError) {
          console.warn("Could not log email attempt:", logError);
        }
        
        // NO lanzar error - continuar con el proceso
      }
    } catch (error) {
      console.error("❌ Error in sendCustomerEmail:", error);
      // NO bloquear el flujo si falla el email
    } finally {
      setSendingEmail(false);
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      // ✅ 1. CREAR/ACTUALIZAR CLIENTE
      let customerId = formData.existing_customer_id || null;
      
      if (!customerId) {
        const existing = await base44.entities.Customer.filter({ phone: formData.customer.phone });
        if (existing?.length) {
          customerId = existing[0].id;
          await base44.entities.Customer.update(customerId, {
            name: `${formData.customer.name} ${formData.customer.last_name}`.trim(),
            email: formData.customer.email || "",
            additional_phones: formData.customer.additional_phones || []
          });
        } else {
          const created = await base44.entities.Customer.create({
            name: `${formData.customer.name} ${formData.customer.last_name}`.trim(),
            phone: formData.customer.phone,
            email: formData.customer.email || "",
            additional_phones: formData.customer.additional_phones || [],
            total_orders: 1
          });
          customerId = created.id;
        }
      } else {
        await base44.entities.Customer.update(customerId, {
          name: `${formData.customer.name} ${formData.customer.last_name}`.trim(),
          email: formData.customer.email || "",
          additional_phones: formData.customer.additional_phones || []
        });
        
        const c = await base44.entities.Customer.get(customerId);
        const next = (c?.total_orders || 0) + 1;
        await base44.entities.Customer.update(customerId, { total_orders: next });
      }

      // ✅ 2. SUBIR FOTOS/EVIDENCIAS
      const photos_metadata = [];
      const photoUrls = [];
      
      for (const mf of formData.media_files || []) {
        try {
          if (mf?.url) {
            photos_metadata.push({
              id: mf.id || `${Date.now()}-${Math.random().toString(36).slice(2)}`,
              type: mf.type?.startsWith?.("image") ? "image" : "video",
              mime: mf.type || "image/jpeg",
              filename: mf.name || "media",
              publicUrl: mf.url,
              thumbUrl: mf.thumbUrl || mf.url
            });
            photoUrls.push(mf.url);
            continue;
          }
          
          if (!(mf instanceof File) && !(mf instanceof Blob)) continue;

          const name = (mf instanceof File && mf.name) ? mf.name : `photo-${Date.now()}.jpg`;
          const file = (mf instanceof File) ? mf : new File([mf], name, { type: mf.type || "image/jpeg" });

          const uploadResult = await base44.integrations.Core.UploadFile({ file });
          const url = `${uploadResult.file_url}?v=${Date.now()}`;
          
          photos_metadata.push({
            id: `${Date.now()}-${name}`,
            type: (file.type || "").startsWith("image") ? "image" : "video",
            mime: file.type || "image/jpeg",
            filename: name,
            publicUrl: url,
            thumbUrl: url
          });
          photoUrls.push(url);
        } catch (fileError) {
          console.warn("Error uploading file:", fileError);
        }
      }

      // ✅ 3. ENCRIPTAR SEGURIDAD
      const encryptedSecurity = {
        device_password: formData.security.device_password ? encryptData(formData.security.device_password) : null,
        device_pin: formData.security.device_pin ? encryptData(formData.security.device_pin) : null,
        pattern_image: formData.security.pattern_image || null,
      };

      const deviceType = formData.device_category?.name || formData.device_subcategory || "phone";
      const orderNumber = `WO-${Date.now().toString().slice(-8)}`;
      
      // ✅ 4. AUTO-ASIGNAR SI ESTÁ HABILITADO
      let assignedTo = formData.assigned_to || "";
      let assignedToName = formData.assigned_to_name || "";
      
      if (autoAssign && user?.id) {
        assignedTo = user.id;
        assignedToName = user.full_name || user.email || "";
      }

      // ✅ 5. CREAR ORDEN (sin firma, con términos auto-aceptados)
      const orderData = {
        order_number: orderNumber,
        customer_id: customerId,
        customer_name: `${formData.customer.name} ${formData.customer.last_name}`.trim(),
        customer_phone: formData.customer.phone,
        customer_email: formData.customer.email || "",
        customer_additional_phones: formData.customer.additional_phones || [],
        
        device_type: deviceType,
        device_brand: formData.device_brand || "",
        device_subcategory: formData.device_subcategory || "",
        device_family: formData.device_family || "",
        device_model: formData.device_model || "",
        device_serial: formData.device_serial || "",
        
        initial_problem: formData.problem_description || "",
        photos_metadata,
        device_security: encryptedSecurity,
        
        checklist_items: formData.checklist_items || [],
        checklist_notes: formData.checklist_notes || "",
        
        status: "intake",
        created_by: user?.full_name || user?.email || "System",
        assigned_to: assignedTo,
        assigned_to_name: assignedToName,
        terms_accepted: true, // ✅ Auto-aceptado
        
        order_items: [],
        comments: []
      };

      const createdOrder = await base44.entities.Order.create(orderData);

      // ✅ NUEVO: Notificar al técnico asignado
      if (createdOrder.assigned_to && user) {
        try {
          const assignedUser = await base44.entities.User.get(createdOrder.assigned_to);
          if (assignedUser && assignedUser.id !== user.id) { // Only notify if assigned to a different user
            await NotificationService.notifyOrderAssigned(createdOrder, assignedUser);
          }
        } catch (notifyError) {
          console.warn("Could not notify assigned user:", notifyError);
        }
      }

      // ✅ 6. CREAR EVENTO DE AUDITORÍA
      try {
        await base44.entities.WorkOrderEvent.create({
          order_id: createdOrder.id,
          order_number: orderNumber,
          event_type: "create",
          description: `Order created by ${user?.full_name || user?.email || "System"}.`,
          user_name: user?.full_name || user?.email || "System",
          user_id: user?.id,
          user_role: user?.role
        });
      } catch (eventError) {
        console.warn("Error creating event:", eventError);
      }

      // ✅ 7. ENVIAR EMAIL AUTOMÁTICO AL CLIENTE
      if (formData.customer.email) {
        await sendCustomerEmail(createdOrder, formData.customer.email, photoUrls);
      }

      setFormData(INITIAL_FORM_DATA);
      setCurrentStep(0);
      if (onSuccess) onSuccess(createdOrder);
      if (onClose) onClose();
      
    } catch (err) {
      console.error("Error creating work order:", err);
      const errorMsg = err?.message || "Error desconocido";
      alert("Error al crear la orden:\n\n" + errorMsg + "\n\nPor favor intenta nuevamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) handleClose(); }}>
      <DialogContent className="z-[70] max-w-4xl h-[90vh] max-h-[90dvh] bg-gradient-to-br from-[#2B2B2B] to-black border-red-900/30 p-0 flex flex-col overflow-hidden">
        <div className="sticky top-0 z-50 px-4 sm:px-6 pt-4 sm:pt-6 pb-4 border-b border-gray-800 bg-gradient-to-br from-[#2B2B2B] to-black flex-shrink-0">
          <DialogHeader>
            <div className="flex items-center justify-between gap-4 mb-3">
              <div>
                <DialogTitle className="text-xl sm:text-2xl font-bold text-white">
                  {getStepTitle(stepName)}
                </DialogTitle>
                <p className="text-xs sm:text-sm text-gray-400 mt-1">
                  Paso {currentStep + 1} de {enabledSteps.length}
                </p>
              </div>
            </div>
          </DialogHeader>

          <WizardStepper
            steps={enabledSteps}
            currentStep={currentStep}
            onStepClick={handleStepClick}
            getStepStatus={getStepStatus}
            getStepLabel={getStepLabel}
            maxReachable={maxReachable}
          />
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar app-scroll touch-pan-y" tabIndex={0}>
          <div className="p-4 sm:p-6">
            {enabledSteps[currentStep] ? getStepComponent(enabledSteps[currentStep]) : null}
          </div>
        </div>

        <div className="sticky bottom-0 z-50 px-4 sm:px-6 py-4 bg-gradient-to-br from-[#2B2B2B] to-black border-t border-gray-800 flex-shrink-0">
          <div className="flex justify-between items-center gap-3">
            <Button
              onClick={handleClose}
              variant="outline"
              disabled={loading || sendingEmail}
              className="px-4 min-h-[48px] border-gray-700 hover:bg-gray-800"
            >
              Cancelar
            </Button>

            <div className="flex items-center gap-3">
              {sendingEmail && (
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  <Mail className="w-4 h-4" />
                  <span>Enviando email...</span>
                </div>
              )}
              
              <Button
                onClick={handleNext}
                disabled={!canProceed() || loading || sendingEmail}
                className="bg-gradient-to-r from-[#FF0000] to-red-800 hover:from-red-700 hover:to-red-900 min-h-[48px] min-w-[140px]"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Procesando...
                  </>
                ) : currentStep === enabledSteps.length - 1 ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Crear Orden
                    {formData.customer.email && <Mail className="w-4 h-4 ml-2" />}
                  </>
                ) : (
                  "Continuar"
                )}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
