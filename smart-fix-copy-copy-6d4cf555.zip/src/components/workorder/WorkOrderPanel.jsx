
import React, { useEffect, useMemo, useState, useRef, useCallback } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  X, PhoneCall, MessageCircle, Eye, EyeOff, Trash2,
  Smartphone, Laptop, Tablet, Watch, Gamepad2, Camera as CameraIcon, Box, Image as ImageIcon, List,
  CheckCircle2, PackageOpen, Pin, ActivitySquare, Plus, Minus, Search, Factory, RefreshCw, Check, ShoppingCart, DollarSign, AlertCircle } from
"lucide-react";
import OrderPhotosGallery from "../orders/OrderPhotosGallery";
import { ORDER_STATUSES, getStatusConfig, normalizeStatusId } from "@/components/utils/statusRegistry";
import NotificationService from "../notifications/NotificationService";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/components/utils/helpers";
import { base44 } from "@/api/base44Client";
import { LinkifiedText } from "@/components/utils/linkify";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"; // Added Dialog imports

// ✅ Función helper para validar y normalizar URLs
function normalizeAndValidateUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== 'string') {
    return null;
  }

  let url = rawUrl.trim();

  if (!url) {
    return null;
  }

  if (/^https?:\/\//i.test(url)) {
    return url;
  }

  if (/^www\./i.test(url)) {
    return `https://${url}`;
  }

  if (url.includes('.') && !url.startsWith('/')) {
    return `https://${url}`;
  }

  return null;
}

// ✅ Función helper para detectar y normalizar URLs de un texto
function detectAndNormalizeUrls(text) {
  if (!text || typeof text !== 'string') return [];

  // Regex to detect URLs (http/https optional, www. optional, domain, path)
  const urlRegex = /(?:https?:\/\/)?(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)/gi;
  const matches = text.match(urlRegex) || [];

  return matches.map((url) => {
    let normalized = url.trim();
    if (!normalized.match(/^https?:\/\//i)) {
      normalized = `https://${normalized}`;
    }
    return {
      original: url,
      normalized: normalized,
      domain: normalized.replace(/^https?:\/\/(www\.)?/, '').split('/')[0] // Extract domain for label
    };
  });
}

function Lightbox({ open, items, index, onClose, onMove }) {
  useEffect(() => {
    if (!open) return;
    const handleKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft" && index > 0) onMove(index - 1);
      if (e.key === "ArrowRight" && index < items.length - 1) onMove(index + 1);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [open, index, items.length, onClose, onMove]);

  if (!open || !items.length) return null;

  const current = items[index];
  const isVideo = current?.type === "video" || current?.mime?.startsWith("video");

  return (
    <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center" onClick={onClose}>
      <button
        onClick={onClose}
        className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center">
        <X className="w-6 h-6" />
      </button>

      {index > 0 &&
      <button
        onClick={(e) => {e.stopPropagation();onMove(index - 1);}}
        className="absolute left-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center">
          ←
        </button>
      }

      {index < items.length - 1 &&
      <button
        onClick={(e) => {e.stopPropagation();onMove(index + 1);}}
        className="absolute right-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center">
          →
        </button>
      }

      <div className="max-w-6xl max-h-[90vh] p-4" onClick={(e) => e.stopPropagation()}>
        {isVideo ?
        <video
          src={current.publicUrl || current.thumbUrl}
          controls
          autoPlay
          className="max-w-full max-h-[80vh] rounded-lg" /> :


        <img
          src={current.publicUrl || current.thumbUrl}
          alt={current.filename || "Foto"}
          className="max-w-full max-h-[80vh] rounded-lg object-contain" />

        }
        <p className="text-white text-center mt-3 text-sm">
          {index + 1} / {items.length}
          {current.filename && ` - ${current.filename}`}
        </p>
      </div>
    </div>);

}

const EVENT_CACHE_DURATION = 30 * 1000;

function getCachedEvents(orderId) {
  try {
    const key = `wo_events_${orderId}`;
    const tsKey = `wo_events_ts_${orderId}`;
    const timestamp = localStorage.getItem(tsKey);

    if (!timestamp) return null;

    const age = Date.now() - parseInt(timestamp);
    if (age > EVENT_CACHE_DURATION) {
      localStorage.removeItem(key);
      localStorage.removeItem(tsKey);
      return null;
    }

    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

function setCachedEvents(orderId, events) {
  try {
    const key = `wo_events_${orderId}`;
    const tsKey = `wo_events_ts_${orderId}`;
    localStorage.setItem(key, JSON.stringify(events));
    localStorage.setItem(tsKey, String(Date.now()));
  } catch (e) {
    console.warn('Event cache storage failed:', e);
  }
}

function clearEventCache(orderId) {
  try {
    const key = `wo_events_${orderId}`;
    const tsKey = `wo_events_ts_${orderId}`;
    localStorage.removeItem(key);
    localStorage.removeItem(tsKey);
  } catch {}
}

const onlyDigits = (v) => (v || "").replace(/\D+/g, "");
function safeAtob(v) {try {return atob(v || "");} catch {return "";}}
function resolveTypeId(o) {
  const src = [
  o?.device_type, o?.device_subcategory, o?.device_family, o?.device_model, o?.device_brand].
  filter(Boolean).join(" ").toLowerCase();
  const has = (k) => src.includes(k);
  if (has("iphone") || has("phone") || has("smartphone") || has("cell") || has("galaxy") || has("pixel")) return "phone";
  if (has("tablet") || has("ipad") || has("surface") || has("galaxy tab")) return "tablet";
  if (has("computer") || has("laptop") || has("notebook") || has("macbook") || has("chromebook") || has("desktop") || has("pc") || has("imac")) return "computer";
  if (has("console") || has("playstation") || has("ps4") || has("ps5") || has("xbox") || has("nintendo") || has("switch") || has("wii")) return "console";
  if (has("watch") || has("reloj")) return "watch";
  if (has("camera") || has("gopro") || has("canon") || has("nikon") || has("dji") || has("drone")) return "camera";
  return "other";
}

function DeviceTypeBadge({ order }) {
  const t = resolveTypeId(order);
  const map = {
    phone: { Icon: Smartphone, label: "Smartphone / iPhone" },
    tablet: { Icon: Tablet, label: "Tablet / iPad" },
    computer: { Icon: Laptop, label: "Laptop / Desktop" },
    watch: { Icon: Watch, label: "Watch" },
    console: { Icon: Gamepad2, label: "Consola" },
    camera: { Icon: CameraIcon, label: "Cámara / Drone" },
    other: { Icon: Box, label: order?.device_type || "Otro" }
  };
  const { Icon, label } = map[t] || map.other;
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-white/15 bg-white/5 px-2 py-[3px] text-[12px] text-gray-200">
      <Icon className="w-3.5 h-3.5" />
      {label}
    </span>);

}

function Field({ label, value, mono, children }) {
  return (
    <div className="min-w-0">
      <div className="text-[11px] text-gray-400">{label}</div>
      <div className={`text-[13px] ${mono ? "font-mono" : "font-medium"} text-white truncate`}>
        {children ?? (value || "—")}
      </div>
    </div>);

}

function PhoneField({ phoneRaw }) {
  const [open, setOpen] = useState(false);
  const digits = onlyDigits(phoneRaw);
  const intl = digits.startsWith("1") ? digits : digits.length === 10 ? `1${digits}` : digits;
  const telHref = digits ? `tel:+${intl}` : null;
  const waHref = digits ? `https://wa.me/${intl}` : null;

  if (!digits) return <Field label="Teléfono" value="—" />;

  return (
    <div className="relative">
      <Field label="Teléfono">
        <button
          className="text-red-300 hover:text-red-200 underline underline-offset-2"
          onClick={() => setOpen((v) => !v)}
          title="Opciones">
          {phoneRaw}
        </button>
      </Field>
      {open &&
      <div
        className="absolute z-[99] mt-1 rounded-md border border-white/15 bg-[#101012] shadow-lg p-2 grid gap-1 w-40"
        onMouseLeave={() => setOpen(false)}>
          <a
          href={telHref || "#"}
          className={`inline-flex items-center gap-2 rounded px-2 py-1 text-[13px] ${telHref ? "hover:bg-white/10 text-white" : "text-gray-500 pointer-events-none"}`}
          onClick={() => setOpen(false)}>
            <PhoneCall className="w-4 h-4" /> Llamar
          </a>
          <a
          href={waHref || "#"}
          target="_blank"
          rel="noreferrer"
          className={`inline-flex items-center gap-2 rounded px-2 py-1 text-[13px] ${waHref ? "hover:bg-white/10 text-white" : "text-gray-500 pointer-events-none"}`}
          onClick={() => setOpen(false)}>
            <MessageCircle className="w-4 h-4" /> WhatsApp
          </a>
        </div>
      }
    </div>);

}

function EmailField({ email }) {
  if (!email) return <Field label="Email" value="—" />;
  return (
    <Field label="Email">
      <a
        href={`mailto:${email}`}
        className="text-red-300 hover:text-red-200 underline underline-offset-2"
        title="Enviar correo">
        {email}
      </a>
    </Field>);

}

function PinPadModal({ open, onClose, onSubmit, title = "PIN administrativo" }) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {if (open) {setPin("");setError("");}}, [open]);

  if (!open) return null;

  const push = (d) => {if (pin.length < 6) setPin(pin + d);};
  const back = () => setPin((p) => p.slice(0, -1));
  const ok = async () => {
    setError("");
    try {
      await onSubmit?.(pin);
    } catch (e) {
      setError(e?.message || "PIN incorrecto");
    }
  };

  return (
    <div className="fixed inset-0 z-[100]">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="absolute inset-0 grid place-items-center p-4">
        <Card className="w-full max-w-xs bg-[#111114] border-white/10 p-4">
          <h3 className="text-white font-semibold mb-1">{title}</h3>
          <p className="text-[12px] text-gray-400 mb-3">Ingresa el PIN administrativo para continuar</p>

          <div className="h-10 grid place-items-center mb-3">
            <div className="font-mono tracking-[6px] text-lg text-white">{pin.replace(/./g, "•") || "••••"}</div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, "←", 0, "OK"].map((k) =>
            <button
              key={k}
              className={`h-10 rounded-md border border-white/15 ${k === "OK" ? "bg-red-600 text-white" : "bg-black/40 text-gray-200 hover:bg-white/10"}`}
              onClick={() => {
                if (k === "←") back();else
                if (k === "OK") ok();else
                push(String(k));
              }}>
                {k}
              </button>
            )}
          </div>

          {error && <div className="mt-3 text-[12px] text-red-300">{error}</div>}

          <div className="mt-3 flex justify-end gap-2">
            <Button variant="outline" className="h-8 px-3 border-white/15" onClick={onClose}>Cancelar</Button>
            <Button className="h-8 px-3 bg-red-600 hover:bg-red-700" onClick={ok}>Confirmar</Button>
          </div>
        </Card>
      </div>
    </div>);

}

function WaitingPartsModal({ open, onClose, onSave }) {
  const [supplier, setSupplier] = useState("");
  const [tracking, setTracking] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {if (open) {setSupplier("");setTracking("");setErr("");}}, [open]);

  if (!open) return null;

  const save = async () => {
    if (!supplier.trim() && !tracking.trim()) {
      setErr("Indica suplidor o tracking (al menos uno).");
      return;
    }
    await onSave?.({ supplier: supplier.trim(), tracking: tracking.trim() });
  };

  return (
    <div className="fixed inset-0 z-[100]">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="absolute inset-0 grid place-items-center p-4">
        <Card className="w-full max-w-md bg-[#111114] border-white/10 p-4">
          <div className="flex items-center gap-2 mb-2">
            <PackageOpen className="w-5 h-5 text-red-400" />
            <h3 className="text-white font-semibold">Esperando piezas</h3>
          </div>
          <p className="text-[12px] text-gray-400 mb-3">Registra suplidor y/o tracking para esta orden.</p>

          <div className="space-y-2">
            <div>
              <div className="text-[12px] text-gray-300 mb-1">Suplidor</div>
              <Input value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="Ej. Parts4u" className="bg-black/40 border-white/15 text-white" />
            </div>
            <div>
              <div className="text-[12px] text-gray-300 mb-1">Tracking</div>
              <Input value={tracking} onChange={(e) => setTracking(e.target.value)} placeholder="Ej. 1Z999AA..." className="bg-black/40 border-white/15 text-white" />
            </div>
          </div>

          {err && <div className="mt-3 text-[12px] text-amber-300">{err}</div>}

          <div className="mt-3 flex justify-end gap-2">
            <Button variant="outline" className="h-8 px-3 border-white/15" onClick={onClose}>Cancelar</Button>
            <Button className="h-8 px-3 bg-red-600 hover:bg-red-700" onClick={save}>Guardar</Button>
          </div>
        </Card>
      </div>
    </div>);

}

function ExternalShopModal({ open, onClose, onSave }) {
  const [shop, setShop] = useState("");
  const [work, setWork] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {if (open) {setShop("");setWork("");setErr("");}}, [open]);

  if (!open) return null;

  const save = async () => {
    if (!shop.trim() && !work.trim()) {
      setErr("Indica el taller y/o el trabajo realizado (al menos uno).");
      return;
    }
    await onSave?.({ shop: shop.trim(), work: work.trim() });
  };

  return (
    <div className="fixed inset-0 z-[100]">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="absolute inset-0 grid place-items-center p-4">
        <Card className="w-full max-w-md bg-[#111114] border-white/10 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Factory className="w-5 h-5 text-red-400" />
            <h3 className="text-white font-semibold">Taller externo</h3>
          </div>
          <p className="text-[12px] text-gray-400 mb-3">Registra a qué taller se envía y qué se le realizará.</p>

          <div className="space-y-2">
            <div>
              <div className="text-[12px] text-gray-300 mb-1">Taller</div>
              <Input value={shop} onChange={(e) => setShop(e.target.value)} placeholder="Ej. MicroSolderPro" className="bg-black/40 border-white/15 text-white" />
            </div>
            <div>
              <div className="text-[12px] text-gray-300 mb-1">Trabajo a realizar</div>
              <Input value={work} onChange={(e) => setWork(e.target.value)} placeholder="Ej. Reballing PMIC, Data recovery…" className="bg-black/40 border-white/15 text-white" />
            </div>
          </div>

          {err && <div className="mt-3 text-[12px] text-amber-300">{err}</div>}

          <div className="mt-3 flex justify-end gap-2">
            <Button variant="outline" className="h-8 px-3 border-white/15" onClick={onClose}>Cancelar</Button>
            <Button className="h-8 px-3 bg-red-600 hover:bg-red-700" onClick={save}>Guardar</Button>
          </div>
        </Card>
      </div>
    </div>);

}

function CancelOrderModal({ open, onClose, onSave }) {
  const [reason, setReason] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {if (open) {setReason("");setErr("");}}, [open]);

  if (!open) return null;

  const save = async () => {
    if (!reason.trim()) {
      setErr("Debes indicar la razón de cancelación.");
      return;
    }
    await onSave?.(reason.trim());
  };

  return (
    <div className="fixed inset-0 z-[100]">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="absolute inset-0 grid place-items-center p-4">
        <Card className="w-full max-w-md bg-[#111114] border-white/10 p-4">
          <div className="flex items-center gap-2 mb-2">
            <X className="w-5 h-5 text-red-400" />
            <h3 className="text-white font-semibold">Cancelar orden</h3>
          </div>
          <p className="text-[12px] text-gray-400 mb-3">Indica el motivo de cancelación de esta orden.</p>

          <div className="space-y-2">
            <div>
              <div className="text-[12px] text-gray-300 mb-1">Motivo de cancelación</div>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Ej. Cliente decidió no reparar, costo muy alto, etc."
                className="bg-black/40 border-white/15 text-white min-h-[80px]" />

            </div>
          </div>

          {err && <div className="mt-3 text-[12px] text-red-300">{err}</div>}

          <div className="mt-3 flex justify-end gap-2">
            <Button variant="outline" className="h-8 px-3 border-white/15" onClick={onClose}>Cancelar</Button>
            <Button className="h-8 px-3 bg-red-600 hover:bg-red-700" onClick={save}>Confirmar cancelación</Button>
          </div>
        </Card>
      </div>
    </div>);

}

function AddItemModal({ open, onClose, onSave, order }) {
  const [tab, setTab] = useState("products");
  const [search, setSearch] = useState("");
  const [products, setProducts] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null); // Not used in this version but kept from outline
  const [showCustomForm, setShowCustomForm] = useState(false);
  const [customItem, setCustomItem] = useState({
    name: "",
    price: "",
    cost: "",
    stock: "",
    min_stock: "5",
    qty: 1,
    taxable: true,
    sku: ""
  });

  useEffect(() => {
    if (open) {
      loadInventory();
      setSearch("");
      setSelectedProduct(null);
      setShowCustomForm(false);
      setCustomItem({
        name: "",
        price: "",
        cost: "",
        stock: "",
        min_stock: "5",
        qty: 1,
        taxable: true,
        sku: ""
      });
    }
  }, [open]);

  const loadInventory = async () => {
    setLoading(true);
    try {
      const [prods, servs] = await Promise.all([
      base44.entities.Product.filter({ active: true }, undefined, 200),
      base44.entities.Service.filter({ active: true }, undefined, 100)]
      );
      setProducts(prods || []);
      setServices(servs || []);
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = useMemo(() => {
    const items = tab === "products" ? products : services;
    if (!search) return items;
    const q = search.toLowerCase();
    return items.filter(
      (item) =>
      (item.name || "").toLowerCase().includes(q) ||
      (item.sku || "").toLowerCase().includes(q) ||
      (item.code || "").toLowerCase().includes(q) ||
      (item.description || "").toLowerCase().includes(q)
    );
  }, [tab, search, products, services]);

  const handleSelectItem = (item) => {
    if (tab === "products") {
      onSave({
        __kind: "product",
        __source_id: item.id,
        type: "product",
        name: item.name,
        price: item.price,
        cost: item.cost,
        qty: 1,
        sku: item.sku,
        stock: item.stock,
        min_stock: item.min_stock,
        taxable: item.taxable !== false,
        from_inventory: true
      });
    } else {
      onSave({
        __kind: "service",
        __source_id: item.id,
        type: "service",
        name: item.name,
        price: item.price,
        qty: 1,
        code: item.code,
        from_inventory: true
      });
    }
    onClose();
  };

  const handleSaveCustom = () => {
    if (!customItem.name.trim() || !customItem.price) {
      alert("Completa los campos: Nombre y Precio de Venta");
      return;
    }

    const itemType = tab === "products" ? "product" : "service";
    const item = {
      __kind: itemType,
      __source_id: `custom-${Date.now()}`,
      type: itemType,
      name: customItem.name.trim(),
      price: parseFloat(customItem.price) || 0,
      cost: parseFloat(customItem.cost) || 0,
      qty: parseInt(customItem.qty) || 1,
      sku: customItem.sku.trim(),
      taxable: customItem.taxable,
      custom: true
    };

    if (itemType === "product") {
      item.stock = parseInt(customItem.stock) || 0;
      item.min_stock = parseInt(customItem.min_stock) || 5;
    }

    onSave(item);
    onClose();
  };

  const profit = customItem.price && customItem.cost ?
  parseFloat(customItem.price) - parseFloat(customItem.cost) :
  0;
  const profitPercent = customItem.price && customItem.cost && parseFloat(customItem.cost) > 0 ?
  (parseFloat(customItem.price) - parseFloat(customItem.cost)) / parseFloat(customItem.cost) * 100 :
  0;

  const currentStock = parseInt(customItem.stock) || 0;
  const minStock = parseInt(customItem.min_stock) || 5;
  const isLowStock = currentStock <= minStock && currentStock > 0;
  const isOutOfStock = currentStock <= 0;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-[#111114] border-white/10">
        <DialogHeader className="border-b border-white/10 pb-4">
          <DialogTitle className="text-white text-xl">
            {showCustomForm ? "Crear Ítem Personalizado" : "Añadir Pieza / Servicio"}
          </DialogTitle>
        </DialogHeader>

        {!showCustomForm ?
        <div className="space-y-4 py-4">
            {/* Tabs */}
            <div className="flex gap-2">
              <Button
              variant={tab === "products" ? "default" : "outline"}
              onClick={() => setTab("products")}
              className={tab === "products" ? "bg-red-600" : "border-white/15"}>
                Productos
              </Button>
              <Button
              variant={tab === "services" ? "default" : "outline"}
              onClick={() => setTab("services")}
              className={tab === "services" ? "bg-red-600" : "border-white/15"}>
                Servicios
              </Button>
              <Button
              variant="outline"
              onClick={() => {
                setShowCustomForm(true);
                setTab("products"); // Default custom form to product
              }}
              className="ml-auto border-white/15">
                + Crear Personalizado
              </Button>
            </div>

            {/* Búsqueda */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
              placeholder="Buscar por nombre, SKU, categoría, modelo..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-black/40 border-white/15 text-white" />

            </div>

            {/* Lista */}
            <div className="max-h-[50vh] overflow-y-auto space-y-2">
              {loading ?
            <div className="text-center py-8 text-gray-400">Cargando...</div> :
            filteredItems.length === 0 ?
            <div className="text-center py-8 text-gray-500">Sin resultados</div> :

            filteredItems.map((item) =>
            <button
              key={item.id}
              onClick={() => handleSelectItem(item)}
              className="w-full flex items-center justify-between p-3 bg-white/5 border border-white/10 rounded-lg hover:border-red-600 hover:bg-white/10 transition-colors text-left">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-white truncate">{item.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className={tab === "services" ? "bg-blue-600/20 text-blue-300 border-blue-600/30" : "bg-emerald-600/20 text-emerald-300 border-emerald-600/30"}>
                          {tab === "services" ? "Servicio" : "Producto"}
                        </Badge>
                        {item.sku && <span className="text-xs text-gray-400">{item.sku}</span>}
                        {item.code && <span className="text-xs text-gray-400">{item.code}</span>}
                      </div>
                    </div>
                    <span className="text-lg font-semibold text-emerald-400 ml-4">
                      ${(item.price || 0).toFixed(2)}
                    </span>
                  </button>
            )
            }
            </div>
          </div> :

        <div className="space-y-6 py-4">
            {/* Tipo de ítem */}
            <div className="flex gap-2">
              <Button
              variant={tab === "products" ? "default" : "outline"}
              onClick={() => setTab("products")}
              className={tab === "products" ? "bg-red-600" : "border-white/15"}>
                Producto
              </Button>
              <Button
              variant={tab === "services" ? "default" : "outline"}
              onClick={() => setTab("services")}
              className={tab === "services" ? "bg-red-600" : "border-white/15"}>
                Servicio
              </Button>
              <Button
              variant="ghost"
              onClick={() => setShowCustomForm(false)}
              className="ml-auto text-gray-400">
                ← Volver al inventario
              </Button>
            </div>

            {/* Formulario */}
            <div className="space-y-4">
              {/* Nombre y SKU */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300 font-medium mb-2 block">Nombre *</Label>
                  <Input
                  value={customItem.name}
                  onChange={(e) => setCustomItem({ ...customItem, name: e.target.value })}
                  placeholder="Ej: Pantalla iPhone 14"
                  className="bg-black/40 border-white/15 text-white" />

                </div>
                <div>
                  <Label className="text-gray-300 font-medium mb-2 block">SKU (opcional)</Label>
                  <Input
                  value={customItem.sku}
                  onChange={(e) => setCustomItem({ ...customItem, sku: e.target.value })}
                  placeholder="18419"
                  className="bg-black/40 border-white/15 text-white" />

                </div>
              </div>

              {/* Precios */}
              <div className="p-4 bg-black/40 rounded-lg border border-white/10 space-y-4">
                <h4 className="text-sm font-semibold text-gray-400 uppercase">Precios</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300 font-medium mb-2 block">
                      Precio de Compra (Costo)
                    </Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                      <Input
                      type="number"
                      step="0.01"
                      value={customItem.cost}
                      onChange={(e) => setCustomItem({ ...customItem, cost: e.target.value })}
                      placeholder="100.00"
                      className="bg-black/40 border-white/15 text-white pl-7" />

                    </div>
                    <p className="text-xs text-gray-500 mt-1">Lo que te cuesta</p>
                  </div>
                  <div>
                    <Label className="text-gray-300 font-medium mb-2 block">
                      Precio de Venta *
                    </Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                      <Input
                      type="number"
                      step="0.01"
                      value={customItem.price}
                      onChange={(e) => setCustomItem({ ...customItem, price: e.target.value })}
                      placeholder="175.00"
                      className="bg-black/40 border-white/15 text-white pl-7" />

                    </div>
                    <p className="text-xs text-gray-500 mt-1">Lo que cobras</p>
                  </div>
                </div>

                {/* Margen */}
                {customItem.price && customItem.cost && parseFloat(customItem.price) >= 0 && parseFloat(customItem.cost) >= 0 &&
              <div className={`p-3 rounded-lg border ${
              profit > 0 ?
              "bg-emerald-600/10 border-emerald-600/30" :
              "bg-red-600/10 border-red-600/30"}`
              }>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-300">Margen de Ganancia:</span>
                      <div className="text-right">
                        <span className={`text-lg font-bold ${
                    profit > 0 ? "text-emerald-400" : "text-red-400"}`
                    }>
                          ${profit.toFixed(2)}
                        </span>
                        <span className={`text-sm ml-2 ${
                    profit > 0 ? "text-emerald-300" : "text-red-300"}`
                    }>
                          ({profitPercent.toFixed(1)}%)
                        </span>
                      </div>
                    </div>
                  </div>
              }
              </div>

              {/* Stock (solo productos) */}
              {tab === "products" &&
            <div className="p-4 bg-black/40 rounded-lg border border-white/10 space-y-4">
                  <h4 className="text-sm font-semibold text-gray-400 uppercase">Inventario</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300 font-medium mb-2 block">
                        Stock Actual
                      </Label>
                      <Input
                    type="number"
                    value={customItem.stock}
                    onChange={(e) => setCustomItem({ ...customItem, stock: e.target.value })}
                    placeholder="0"
                    className="bg-black/40 border-white/15 text-white" />

                      <p className="text-xs text-gray-500 mt-1">Cuánto tienes</p>
                    </div>
                    <div>
                      <Label className="text-gray-300 font-medium mb-2 block">
                        Stock Mínimo
                      </Label>
                      <Input
                    type="number"
                    value={customItem.min_stock}
                    onChange={(e) => setCustomItem({ ...customItem, min_stock: e.target.value })}
                    placeholder="5"
                    className="bg-black/40 border-white/15 text-white" />

                      <p className="text-xs text-gray-500 mt-1">Alerta cuando baje a</p>
                    </div>
                  </div>

                  {/* Alertas de stock */}
                  {isOutOfStock &&
              <div className="p-3 bg-red-600/10 border border-red-600/30 rounded-lg flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-red-400" />
                      <div>
                        <p className="text-red-300 font-semibold text-sm">⚠️ Agotado</p>
                        <p className="text-red-200/70 text-xs">Sin stock disponible</p>
                      </div>
                    </div>
              }

                  {isLowStock && !isOutOfStock &&
              <div className="p-3 bg-amber-600/10 border border-amber-600/30 rounded-lg flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-amber-400" />
                      <div>
                        <p className="text-amber-300 font-semibold text-sm">⚠️ Stock Bajo</p>
                        <p className="text-amber-200/70 text-xs">
                          Actual: {currentStock} | Mínimo: {minStock}
                        </p>
                      </div>
                    </div>
              }

                  {!isLowStock && !isOutOfStock && currentStock > 0 &&
              <div className="p-3 bg-emerald-600/10 border border-emerald-600/30 rounded-lg flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-emerald-400" />
                      <div>
                        <p className="text-emerald-300 font-semibold text-sm">✅ Stock OK</p>
                        <p className="text-emerald-200/70 text-xs">{currentStock} unidades</p>
                      </div>
                    </div>
              }
                </div>
            }

              {/* IVU */}
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
                <div>
                  <Label className="text-gray-300 font-medium">
                    Lleva impuesto (+ITBIS/IVU)
                  </Label>
                  <p className="text-xs text-gray-500 mt-1">Se aplicará 11.5%</p>
                </div>
                <button
                onClick={() => setCustomItem({ ...customItem, taxable: !customItem.taxable })}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                customItem.taxable ? "bg-red-600" : "bg-gray-600"}`
                }>
                  <span
                  className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                  customItem.taxable ? "translate-x-7" : ""}`
                  } />

                </button>
              </div>

              {/* Modelos compatibles */}
              <div>
                <Label className="text-gray-300 font-medium mb-2 block">
                  Modelos compatibles (uno por línea, opcional)
                </Label>
                <Textarea
                placeholder="iPhone 14&#10;iPhone 14 Plus&#10;iPhone 15"
                className="bg-black/40 border-white/15 text-white min-h-[80px]" />

              </div>
            </div>

            {/* Botones */}
            <div className="flex gap-3 pt-4 border-t border-white/10">
              <Button
              variant="outline"
              onClick={() => setShowCustomForm(false)}
              className="flex-1 border-white/15">
                Cancelar
              </Button>
              <Button
              onClick={handleSaveCustom}
              className="flex-1 bg-red-600 hover:bg-red-700"
              disabled={!customItem.name.trim() || !customItem.price || parseFloat(customItem.price) < 0}>
                Guardar
              </Button>
            </div>
          </div>
        }
      </DialogContent>
    </Dialog>);

}

function CommentSection({ order, onUpdated }) {
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(false);
  const textareaRef = useRef(null);

  const [linkUrl, setLinkUrl] = useState("");
  const [linkLabel, setLinkLabel] = useState("");
  const [savingLink, setSavingLink] = useState(false);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [links, setLinks] = useState([]);
  // const [editingLinkId, setEditingLinkId] = useState(null); // Removed as per new requirements

  useEffect(() => {
    if (order?.id) loadLinks();
  }, [order?.id]);

  const loadLinks = async () => {
    if (!order?.id) return;
    try {
      const events = await base44.entities.WorkOrderEvent.filter({ order_id: order.id, event_type: "link" }, "-created_at", 50);
      setLinks(events || []);
    } catch (e) {
      console.error("Error loading links:", e);
    }
  };

  const handleSubmit = async () => {
    if (!comment.trim()) return;
    setLoading(true);
    try {
      let me = null;
      try {me = await base44.auth.me();} catch {}

      // Detectar links en el comentario
      const detectedUrls = detectAndNormalizeUrls(comment);

      // Crear el comentario normal
      await base44.entities.WorkOrderEvent.create({
        order_id: order.id,
        order_number: order.order_number,
        event_type: "note_added",
        description: comment,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: {
          for_customer: true,
          has_links: detectedUrls.length > 0
        }
      });

      // Si hay links, crear eventos de tipo "link" para cada uno
      for (const urlInfo of detectedUrls) {
        await base44.entities.WorkOrderEvent.create({
          order_id: order.id,
          order_number: order.order_number,
          event_type: "link",
          description: `Link detectado: ${urlInfo.domain}`,
          user_name: me?.full_name || me?.email || "Sistema",
          user_id: me?.id || null,
          metadata: {
            url: urlInfo.normalized,
            label: urlInfo.domain,
            source: "auto_detected"
          }
        });
      }

      setComment("");
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }

      clearEventCache(order.id);
      await loadLinks();
      onUpdated?.(true);
    } catch (e) {
      console.error("Error adding comment:", e);
      alert("Error al agregar comentario");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveLink = async () => {
    if (!linkUrl.trim()) {
      alert("Ingresa una URL");
      return;
    }
    setSavingLink(true);
    try {
      let me = null;
      try {me = await base44.auth.me();} catch {}

      let normalizedUrl = linkUrl.trim();
      if (!normalizedUrl.match(/^https?:\/\//i)) {
        normalizedUrl = `https://${normalizedUrl}`;
      }

      const domain = normalizedUrl.replace(/^https?:\/\/(www\.)?/, '').split('/')[0];
      const displayLabel = linkLabel.trim() || domain;

      // Create the actual link event
      await base44.entities.WorkOrderEvent.create({
        order_id: order.id,
        order_number: order.order_number,
        event_type: "link",
        description: `Link añadido: ${displayLabel}`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: {
          url: normalizedUrl,
          label: displayLabel,
          source: "manual"
        }
      });

      // Also create a note_added event for the timeline (visible to customer)
      await base44.entities.WorkOrderEvent.create({
        order_id: order.id,
        order_number: order.order_number,
        event_type: "note_added",
        description: `Link añadido: ${displayLabel} - ${normalizedUrl}`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: { for_customer: true }
      });

      setLinkUrl("");
      setLinkLabel("");
      setShowLinkModal(false);
      await loadLinks();
      clearEventCache(order.id);
      onUpdated?.(true);
    } catch (e) {
      console.error("Error saving link:", e);
      alert("Error al guardar link. Intenta nuevamente.");
    } finally {
      setSavingLink(false);
    }
  };

  const handleDeleteLink = async (linkId) => {
    if (!linkId) return;
    if (!confirm("¿Eliminar este link?")) return;

    try {
      await base44.entities.WorkOrderEvent.delete(linkId);
      await loadLinks();
      clearEventCache(order.id);
      onUpdated?.(true);
    } catch (e) {
      console.error("Error deleting link:", e);
      if (e.message?.includes("not found")) {
        await loadLinks();
      } else {
        alert("Error al eliminar link");
      }
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleTextareaChange = (e) => {
    setComment(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  };

  return (
    <div className="space-y-4">
      <Card className="p-4 bg-[#111114] border-white/10">
        <h3 className="text-white font-semibold mb-3">Añadir Comentario</h3>
        <div className="space-y-3">
          <Textarea
            ref={textareaRef}
            placeholder="Escribe un comentario... (Enter para enviar, Shift+Enter para nueva línea)"
            value={comment}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            className="bg-black/40 border-white/15 text-white min-h-[80px] resize-none" />

          <div className="flex gap-2">
            <Button
              onClick={handleSubmit}
              disabled={loading || !comment.trim()}
              className="flex-1 bg-red-600 hover:bg-red-700">
              {loading ? "Guardando..." : "Agregar comentario"}
            </Button>
            <Button
              onClick={() => setShowLinkModal(true)}
              variant="outline"
              className="border-white/15">
              Link
            </Button>
          </div>
        </div>
      </Card>

      {/* Links guardados como chips */}
      {links.length > 0 &&
      <Card className="p-4 bg-[#111114] border-white/10">
          <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
            Links de Proveedor / Piezas
          </h3>
          <div className="flex flex-wrap gap-2">
            {links.map((link) => {
            const rawUrl = link.metadata?.url || "";
            const label = link.metadata?.label || "";
            const safeUrl = normalizeAndValidateUrl(rawUrl);

            return (
              <div key={link.id} className="group relative">
                  <button
                  onClick={() => {
                    if (!safeUrl) {
                      alert("URL inválida");
                      return;
                    }
                    try {
                      const urlObj = new URL(safeUrl);
                      if (['http:', 'https:'].includes(urlObj.protocol)) {
                        window.open(safeUrl, "_blank", "noopener,noreferrer");
                      } else {
                        alert("Solo se permiten URLs con protocolo HTTP o HTTPS");
                      }
                    } catch (e) {
                      console.error("Error opening link:", e);
                      alert("No se pudo abrir el link");
                    }
                  }}
                  disabled={!safeUrl}
                  className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-600/20 border border-blue-600/30 rounded-full text-blue-300 hover:bg-blue-600/30 transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                    </svg>
                    <span className="max-w-[200px] truncate">{label || rawUrl || "Link"}</span>
                  </button>
                  <button
                  onClick={() => handleDeleteLink(link.id)}
                  className="absolute -top-2 -right-2 w-5 h-5 bg-red-600 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>);

          })}
          </div>
        </Card>
      }

      {/* Modal de añadir link */}
      {showLinkModal &&
      <div className="fixed inset-0 z-[100]">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowLinkModal(false)} />
          <div className="absolute inset-0 grid place-items-center p-4">
            <Card className="w-full max-w-md bg-[#111114] border-white/10 p-4">
              <div className="flex items-center gap-2 mb-2">
                <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
                <h3 className="text-white font-semibold">Añadir Link</h3>
              </div>
              <p className="text-[12px] text-gray-400 mb-3">Guarda un link útil para esta orden</p>

              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-gray-400 mb-1">URL *</Label>
                  <Input
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder="https://... o amazon.com/..."
                  className="bg-black/40 border-white/15 text-white" />

                </div>
                <div>
                  <Label className="text-xs text-gray-400 mb-1">Descripción (opcional)</Label>
                  <Input
                  value={linkLabel}
                  onChange={(e) => setLinkLabel(e.target.value)}
                  placeholder="Ej: Pantalla iPhone 13 OLED"
                  className="bg-black/40 border-white/15 text-white" />

                </div>
              </div>

              <div className="mt-4 flex justify-end gap-2">
                <Button
                variant="outline"
                className="border-white/15"
                onClick={() => setShowLinkModal(false)}
                disabled={savingLink}>
                  Cancelar
                </Button>
                <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={handleSaveLink}
                disabled={savingLink || !linkUrl.trim()}>
                  {savingLink ? "Guardando..." : "Guardar"}
                </Button>
              </div>
            </Card>
          </div>
        </div>
      }
    </div>);

}

function DepositModal({ open, onClose, onSave, currentBalance }) {
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("cash");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setAmount("");
      setMethod("cash");
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = async () => {
    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert("El monto debe ser un número mayor a 0");
      return;
    }

    setLoading(true);
    try {
      await onSave(amountNum, method);
      onClose();
    } catch (e) {
      console.error("Error saving deposit:", e);
      alert("Error al registrar el depósito");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100]">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="absolute inset-0 grid place-items-center p-4">
        <Card className="w-full max-w-md bg-[#111114] border-white/10 p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <h3 className="text-white font-semibold">Registrar Depósito</h3>
          </div>
          <p className="text-[12px] text-gray-400 mb-3">
            Balance pendiente: <span className="text-amber-400 font-semibold">${currentBalance.toFixed(2)}</span>
          </p>

          <div className="space-y-3">
            <div>
              <Label className="text-gray-300 text-sm mb-1">Monto del depósito *</Label>
              <Input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="bg-black/40 border-white/15 text-white"
                autoFocus />

            </div>
            <div>
              <Label className="text-gray-300 text-sm mb-1">Método de pago</Label>
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value)}
                className="w-full h-10 px-3 rounded-md bg-black/40 border border-white/15 text-white">
                <option value="cash">Efectivo</option>
                <option value="card">Tarjeta</option>
                <option value="ath_movil">ATH Móvil</option>
                <option value="zelle">Zelle</option>
              </select>
            </div>
          </div>

          <div className="mt-4 flex justify-end gap-2">
            <Button variant="outline" className="border-white/15" onClick={onClose} disabled={loading}>
              Cancelar
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSubmit} disabled={loading}>
              {loading ? "Procesando..." : "Registrar depósito"}
            </Button>
          </div>
        </Card>
      </div>
    </div>);

}

function OrderItemsSection({ order, onUpdated, clearEventCache, loadEventsCallback }) {
  const navigate = useNavigate();
  const o = order || {};
  const [items, setItems] = useState(() => Array.isArray(o.order_items) ? o.order_items : []);
  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [suggestedProducts, setSuggestedProducts] = useState([]);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {setItems(Array.isArray(o.order_items) ? o.order_items : []);}, [o.order_items]);

  useEffect(() => {
    if (!o.id || !o.device_model) return;
    loadSuggestedProducts();
  }, [o.id, o.device_model]);

  async function loadSuggestedProducts() {
    if (!o.device_model) {
      setSuggestedProducts([]);
      return;
    }

    try {
      const allProducts = await base44.entities.Product.filter({ active: true }, undefined, 200);

      const modelLower = (o.device_model || "").toLowerCase();
      const filtered = allProducts.filter((p) => {
        const nameLower = (p.name || "").toLowerCase();
        const descLower = (p.description || "").toLowerCase();
        const compatModels = Array.isArray(p.compatibility_models) ? p.compatibility_models : [];
        const hasCompatMatch = compatModels.some((m) => (m || "").toLowerCase().includes(modelLower));

        return nameLower.includes(modelLower) || descLower.includes(modelLower) || hasCompatMatch;
      });

      setSuggestedProducts(filtered.slice(0, 5));
    } catch (err) {
      console.error("Error loading suggested products:", err);
      setSuggestedProducts([]);
    }
  }

  async function addLine(r, qty = 1) {
    const existsIdx = items.findIndex((x) => x.__kind === r.__kind && x.__source_id === r.__source_id);
    let next = [];
    if (existsIdx >= 0) {
      next = items.map((x, i) => i === existsIdx ? { ...x, qty: Number(x.qty || 1) + qty } : x);
    } else {
      next = [...items, { ...r, qty: qty }];
    }
    setItems(next);
    await persist(next);

    try {
      let me = null;
      try {me = await base44.auth.me();} catch {}

      await base44.entities.WorkOrderEvent.create({
        order_id: o.id,
        order_number: o.order_number,
        event_type: "item_added",
        description: `Item agregado: ${r.name} (x${qty})`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: { item_kind: r.__kind, item_id: r.__source_id, item_name: r.name, quantity: qty, custom: r.custom || false }
      });
      clearEventCache(o.id);
      await loadEventsCallback(true);
      onUpdated?.();
    } catch (e) {
      console.error("Error creating item_added event:", e);
    }
  }

  function setQty(i, qty) {
    const qn = Math.max(1, Number(qty || 1));
    const next = items.map((x, idx) => idx === i ? { ...x, qty: qn } : x);
    setItems(next);
  }

  async function removeLine(i) {
    const itemToRemove = items[i];
    const next = items.filter((_, idx) => idx !== i);
    setItems(next);

    try {
      let me = null;
      try {me = await base44.auth.me();} catch {}

      await base44.entities.WorkOrderEvent.create({
        order_id: o.id,
        order_number: o.order_number,
        event_type: "item_removed",
        description: `Item removido: ${itemToRemove.name} (x${itemToRemove.qty})`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: { item_kind: itemToRemove.__kind, item_id: itemToRemove.__source_id, item_name: itemToRemove.name, quantity: itemToRemove.qty, custom: itemToRemove.custom || false }
      });
      clearEventCache(o.id);
      await loadEventsCallback(true);
      onUpdated?.();
    } catch (e) {
      console.error("Error creating item_removed event:", e);
    }
  }

  async function persist(itemsToSave = items) {
    try {
      const itemsWithTotal = itemsToSave.map((it) => ({
        ...it,
        total: Number(it.price || 0) * Number(it.qty || 1)
      }));

      const subtotal = itemsWithTotal.reduce((s, it) => s + (it.total || 0), 0);
      const taxRate = 0.115;
      const tax = subtotal * taxRate;
      const total = subtotal + tax;

      await base44.entities.Order.update(o.id, {
        order_items: itemsToSave,
        total: total
      });

      clearEventCache(o.id);
      await loadEventsCallback(true);
      onUpdated?.();
      setIsEditing(false);
    } catch (e) {
      console.error(e);
      alert("Error guardando items");
    }
  }

  const subtotal = items.reduce((s, it) => s + Number(it.price || 0) * Number(it.qty || 1), 0);
  const taxRate = 0.115;
  const tax = subtotal * taxRate;
  const total = subtotal + tax;

  const getStockBadge = (item) => {
    if (item.__kind === "service" || item.type === "service") {
      return <Badge className="text-[10px] bg-blue-600/20 text-blue-300 border-blue-600/30">Servicio</Badge>;
    }

    if (item.custom) {
      return <Badge className="text-[10px] bg-purple-600/20 text-purple-300 border-purple-600/30">Personalizado</Badge>;
    }

    const stock = Number(item.stock || 0);
    const minStock = Number(item.min_stock || 0);

    if (stock <= 0) {
      return <Badge className="text-[10px] bg-red-600/20 text-red-300 border-red-600/30">Agotado</Badge>;
    }
    if (stock <= minStock) {
      return <Badge className="text-[10px] bg-amber-600/20 text-amber-300 border-amber-600/30">Bajo ({stock})</Badge>;
    }
    return <Badge className="text-[10px] bg-emerald-600/20 text-emerald-300 border-emerald-600/30">{stock} unid.</Badge>;
  };

  // ✅ Calcular valores en tiempo real
  const totalPaid = Number(o.total_paid || o.amount_paid || 0);
  const balance = Math.max(0, total - totalPaid);
  const isPaid = balance <= 0.01;

  const handleCobrarClick = () => {
    navigate(createPageUrl(`POS?workOrderId=${o.id}&balance=${balance}&mode=full`), {
      state: { fromDashboard: true, paymentMode: "full" }
    });
  };

  const handleDepositoClick = () => {
    navigate(createPageUrl(`POS?workOrderId=${o.id}&balance=${balance}&mode=deposit`), {
      state: { fromDashboard: true, paymentMode: "deposit" }
    });
  };

  return (
    <>
      <Card className="p-4 bg-[#111114] border-white/10">
        <CardHeader className="border-b border-white/10 pb-4">
          <CardTitle className="text-white flex items-center justify-between">
            <span className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-red-600" />
              Piezas y Servicios
            </span>
            <div className="flex items-center gap-2">
              {items.length > 0 &&
              <Button
                onClick={() => {
                  if (isEditing) {
                    persist();
                  } else {
                    setIsEditing(true);
                  }
                }}
                variant={isEditing ? "default" : "outline"} className="bg-background text-slate-900 px-4 py-2 text-sm font-medium rounded-md inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:bg-accent hover:text-accent-foreground h-10 border-white/15">

                  {isEditing ?
                <>
                      <Check className="w-4 h-4 mr-2" />
                      Guardar cambios
                    </> :

                "Editar"
                }
                </Button>
              }
              <Button
                onClick={() => setShowAddItemModal(true)}
                className="bg-red-600 hover:bg-red-700">
                <Plus className="w-4 h-4 mr-2" />
                Añadir pieza / servicio
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          {o.device_model && suggestedProducts.length > 0 &&
          <div className="space-y-3 pb-4 border-b border-white/10">
              <p className="text-sm font-semibold text-gray-400 uppercase tracking-wide">
                💡 Piezas sugeridas para {o.device_model}
              </p>
              <div className="grid gap-2">
                {suggestedProducts.map((product) => {
                const isAdded = items.some((i) => i.__kind === "product" && i.__source_id === product.id);
                const isOutOfStock = product.stock <= 0;

                return (
                  <div
                    key={`suggested-${product.id}`}
                    className={`
                        bg-black/40 border rounded-lg p-3 transition-colors
                        ${isAdded ? "border-emerald-500/50" : "border-white/10 hover:bg-black/60"}
                      `}>
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="text-white font-medium text-sm truncate">{product.name}</p>
                          <div className="flex items-center gap-2 mt-1">
                            {product.sku &&
                          <span className="text-xs text-gray-400">{product.sku}</span>
                          }
                            {getStockBadge(product)}
                          </div>
                        </div>
                        <div className="text-right flex items-center gap-3">
                          <span className="text-emerald-400 font-semibold">
                            ${product.price.toFixed(2)}
                          </span>
                          <Button
                          size="sm"
                          onClick={() => addLine({ ...product, __kind: "product", __source_id: product.id, type: "product", from_inventory: true })}
                          disabled={isOutOfStock || isAdded}
                          className={`
                              disabled:opacity-50 disabled:cursor-not-allowed h-8 px-3
                              ${isAdded ? "bg-emerald-600/50 text-white" : "bg-red-600 hover:bg-red-700"}
                            `}>
                            {isAdded ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                          </Button>
                        </div>
                      </div>
                    </div>);

              })}
              </div>
            </div>
          }

          {items.length > 0 &&
          <div className="space-y-3">
              <p className="text-sm font-semibold text-gray-400 uppercase tracking-wide">
                ITEMS EN LA ORDEN
              </p>
              <div className="space-y-2">
                {items.map((item, idx) => {
                const isProduct = item.__kind === 'product' || item.type === 'product';
                const itemTotal = Number(item.price || 0) * Number(item.qty || 1);

                return (
                  <div
                    key={`${item.__kind}-${item.__source_id}-${idx}`}
                    className="bg-black/40 border border-white/10 rounded-lg p-3 flex items-center justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-medium text-sm truncate">{item.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {isProduct ? '📦 Producto' : '🔧 Servicio'}
                          </Badge>
                          {item.sku &&
                        <span className="text-xs text-gray-500">{item.sku}</span>
                        }
                          {getStockBadge(item)}
                        </div>
                      </div>
                      <div className="flex-shrink-0 flex items-center gap-2">
                        {isEditing ?
                      <>
                            <div className="flex items-center gap-1 flex-shrink-0">
                              <Button
                            size="icon"
                            variant="outline"
                            className="h-7 w-7 border-white/15"
                            onClick={() => setQty(idx, Number(item.qty || 1) - 1)}
                            disabled={Number(item.qty || 1) <= 1}>
                                <Minus className="w-3 h-3" />
                              </Button>
                              <Input
                            value={Number(item.qty || 1)}
                            onChange={(e) => setQty(idx, e.target.value)}
                            className="w-12 h-7 text-center bg-black/40 border-white/15 text-white text-sm"
                            type="number"
                            min="1" />

                              <Button
                            size="icon"
                            variant="outline"
                            className="h-7 w-7 border-white/15"
                            onClick={() => setQty(idx, Number(item.qty || 1) + 1)}>
                                <Plus className="w-3 h-3" />
                              </Button>
                            </div>
                            <span className="text-emerald-400 font-semibold text-sm flex-shrink-0">
                              ${itemTotal.toFixed(2)}
                            </span>
                            <Button
                          size="icon"
                          variant="outline"
                          className="h-7 w-7 border-white/15 hover:border-red-500 hover:text-red-300 flex-shrink-0"
                          onClick={() => removeLine(idx)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </> :

                      <>
                            <span className="text-white text-sm flex-shrink-0">
                              x{Number(item.qty || 1)}
                            </span>
                            <span className="text-emerald-400 font-semibold text-sm flex-shrink-0">
                              ${itemTotal.toFixed(2)}
                            </span>
                          </>
                      }
                      </div>
                    </div>);

              })}
              </div>
            </div>
          }

          {items.length > 0 &&
          <div className="border-t border-white/10 pt-3 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Subtotal ({items.length} {items.length === 1 ? "item" : "items"})</span>
                <span className="text-white font-medium">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">IVU (11.5%)</span>
                <span className="text-white font-medium">${tax.toFixed(2)}</span>
              </div>

              {/* ✅ Total pagado - siempre visible */}
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Total pagado</span>
                <span className={`font-medium ${totalPaid > 0 ? "text-emerald-400" : "text-gray-500"}`}>
                  ${totalPaid.toFixed(2)}
                </span>
              </div>

              <div className="flex justify-between text-base pt-2 border-t border-white/10">
                <span className="text-white font-semibold">Total</span>
                <span className="text-white font-bold text-lg">${total.toFixed(2)}</span>
              </div>

              {/* ✅ Balance pendiente - destacado */}
              <div className={`flex justify-between text-base p-3 rounded-lg ${
            isPaid ?
            "bg-emerald-600/20 border border-emerald-600/30" :
            "bg-amber-600/20 border border-amber-600/30"}`
            }>
                <span className={`font-semibold ${isPaid ? "text-emerald-300" : "text-amber-300"}`}>
                  Balance pendiente
                </span>
                <span className={`font-bold text-lg ${isPaid ? "text-emerald-400" : "text-amber-400"}`}>
                  ${balance.toFixed(2)}
                  {isPaid && <CheckCircle2 className="w-5 h-5 inline ml-2" />}
                </span>
              </div>
            </div>
          }
        </CardContent>
      </Card>

      {/* ✅ Botones de pago - siempre visibles si hay items */}
      {Array.isArray(o.order_items) && o.order_items.length > 0 &&
      <div className="flex gap-3">
          <Button
          onClick={handleDepositoClick}
          className="flex-1 bg-emerald-600 hover:bg-emerald-700 flex items-center justify-center gap-2">
            <DollarSign className="w-4 h-4" />
            Depósito
            {!isPaid && <span className="text-xs opacity-80">(No cambia estado)</span>}
          </Button>
          <Button
          onClick={handleCobrarClick}
          disabled={isPaid}
          className="flex-1 bg-red-600 hover:bg-red-700 flex items-center justify-center gap-2 disabled:opacity-50">
            <DollarSign className="w-4 h-4" />
            Cobrar
            {isPaid && <span className="text-xs opacity-80">(Saldado)</span>}
          </Button>
        </div>
      }

      <AddItemModal
        open={showAddItemModal}
        onClose={() => setShowAddItemModal(false)}
        onSave={(item) => {
          addLine(item, 1);
          setShowAddItemModal(false);
        }}
        order={o} />

    </>);

}

export default function WorkOrderPanel({ orderId, onClose, onUpdate, onDelete, panelVersion = "v9" }) {
  console.log("[WorkOrderPanel] Props received:", { orderId, hasOnClose: !!onClose, hasOnUpdate: !!onUpdate });

  const navigate = useNavigate();

  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);

  const o = order || {};

  const [status, setStatus] = useState("intake");

  const photos = useMemo(() => o.photos_metadata || o.device_photos || [], [o]);

  const sec = o.device_security || {};
  const hasPassword = !!sec.device_password;
  const hasPin = !!sec.device_pin;
  const hasPattern = !!sec.pattern_image;
  const [showPass, setShowPass] = useState(false);
  const [showPin, setShowPin] = useState(false);

  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState("");

  const [events, setEvents] = useState([]);
  const [loadingEvents, setLoadingEvents] = useState(false);

  const [pinModal, setPinModal] = useState({ open: false, targetNoteId: null, forOrder: false });
  const [partsModalOpen, setPartsModalOpen] = useState(false);
  const [externalModalOpen, setExternalModalOpen] = useState(false);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  // Removed: [showDepositModal, setShowDepositModal] = useState(false);


  const [lbOpen, setLbOpen] = useState(false);
  const [lbIndex, setLbIndex] = useState(0);

  const [changingStatus, setChangingStatus] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);

  const activeStatuses = useMemo(() => {
    return ORDER_STATUSES.filter((s) => s.isActive);
  }, []);

  const closedStatuses = useMemo(() => {
    return ORDER_STATUSES.filter((s) => !s.isActive);
  }, []);

  // Updated handleCobrarClick for header button to potentially handle full payment
  const handleCobrarClick = useCallback(() => {
    if (!order) return;
    const total = Number(order.total || 0);
    const totalPaid = Number(order.total_paid || order.paid || 0);
    const balance = Math.max(0, total - totalPaid);

    // Default behavior for header button: go to POS for full payment
    navigate(createPageUrl(`POS?workOrderId=${order.id}&balance=${balance}&mode=full`), { state: { fromDashboard: true, paymentMode: "full" } });
  }, [order, navigate]);

  const loadEventsCallback = useCallback(async (forceRefresh = false) => {
    if (!order?.id) return;

    if (!forceRefresh) {
      const cached = getCachedEvents(order.id);
      if (cached) {
        console.log(`[WorkOrderPanel] Using cached events for order ${order.id}`);
        setEvents(cached);
        return;
      }
    }

    setLoadingEvents(true);
    try {
      let user = null;
      try {
        user = await base44.auth.me();
      } catch (e) {
        console.log("[WorkOrderPanel] No authenticated user, cannot load events");
        setEvents([]);
        setLoadingEvents(false);
        return;
      }

      if (!user) {
        console.log("[WorkOrderPanel] User not authenticated, cannot load events");
        setEvents([]);
        setLoadingEvents(false);
        return;
      }

      const rows = await base44.entities.WorkOrderEvent.filter({ order_id: order.id }, "-created_at", 200).catch((e) => {
        console.error("[WorkOrderPanel] Error loading events:", e.message || e);
        return [];
      });

      const list = (rows || []).sort((a, b) => new Date(b.created_at || b.created_date || 0) - new Date(a.created_at || a.created_date || 0));

      setEvents(list);
      setCachedEvents(order.id, list);
    } catch (err) {
      console.error("[WorkOrderPanel] Error loading events:", err.message || err);
      setEvents([]);
    } finally {
      setLoadingEvents(false);
    }
  }, [order?.id]);

  const handleRefresh = useCallback(async (force = false) => {
    if (!orderId) return;
    setLoading(true);
    setLoadError(null);
    try {
      const data = await base44.entities.Order.get(orderId);
      setOrder(data);
      setStatus(normalizeStatusId(data.status || "intake"));
      clearEventCache(orderId);
      await loadEventsCallback(true);
      onUpdate?.();
    } catch (e) {
      console.error("[WorkOrderPanel] Error refreshing order:", e);
      setLoadError(`Error al recargar la orden: ${e.message || "Error de conexión"}`);
    } finally {
      setLoading(false);
    }
  }, [orderId, loadEventsCallback, onUpdate]);

  // ✅ Listener para refrescar cuando se procese un pago desde POS
  useEffect(() => {
    const handlePaymentProcessed = async (event) => {
      const { orderId: eventOrderId } = event.detail || {};

      if (eventOrderId === order?.id) {
        console.log(`[WorkOrderPanel] Payment processed for order ${eventOrderId}. Refreshing data...`);

        // Recargar la orden desde la DB
        try {
          const freshOrder = await base44.entities.Order.get(eventOrderId);
          setOrder(freshOrder);
          clearEventCache(eventOrderId);
          await loadEventsCallback(true);
          onUpdate?.();
        } catch (e) {
          console.error("[WorkOrderPanel] Error refreshing after payment:", e);
        }
      }
    };

    window.addEventListener('order-payment-processed', handlePaymentProcessed);

    return () => {
      window.removeEventListener('order-payment-processed', handlePaymentProcessed);
    };
  }, [order?.id, loadEventsCallback, onUpdate]);

  // Removed: handleNavigateToPOS as it's replaced by handleCobrarClick logic

  const handleClose = useCallback(() => {
    document.body.classList.remove("wo-fullscreen");
    if (onClose) onClose();
  }, [onClose]);

  const handlePhotoClick = useCallback((index) => {
    setLbIndex(index);
    setLbOpen(true);
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "n" || e.key === "N") {e.preventDefault();e.stopPropagation();}
    };
    window.addEventListener("keydown", onKey, { capture: true });
    return () => window.removeEventListener("keydown", onKey, { capture: true });
  }, []);

  useEffect(() => {
    let mounted = true;
    const loadOrderData = async () => {
      if (!orderId) {
        console.error("[WorkOrderPanel] No orderId provided");
        if (mounted) {
          setLoading(false);
          setLoadError("No se proporcionó un ID de orden.");
        }
        return;
      }

      document.body.classList.add("wo-fullscreen");

      setLoading(true);
      setLoadError(null);
      setOrder(null);

      try {
        let user = null;
        try {
          user = await base44.auth.me();
        } catch (e) {
          console.error("[WorkOrderPanel] Authentication error:", e.message || e);
          if (mounted) {
            setLoading(false);
            setLoadError("Sesión expirada. Por favor, recargue la página.");
          }
          return;
        }

        if (!user) {
          if (mounted) {
            setLoading(false);
            setLoadError("Usuario no autenticado. No se puede cargar la orden.");
          }
          return;
        }

        console.log("[WorkOrderPanel] Loading order with ID:", orderId);

        const data = await base44.entities.Order.get(orderId).catch((e) => {
          console.error("[WorkOrderPanel] Error fetching order:", e.message || e);
          throw new Error(`No se pudo cargar la orden: ${e.message || "Error de red"}`);
        });

        if (!mounted) return;

        if (!data) {
          console.error("[WorkOrderPanel] Order not found:", orderId);
          setOrder(null);
          setLoading(false);
          setLoadError(`Orden con ID ${orderId} no encontrada.`);
          return;
        }

        console.log("[WorkOrderPanel] Order loaded:", data.order_number);
        setOrder(data);
        setStatus(normalizeStatusId(data.status || "intake"));
        setLoading(false);

      } catch (e) {
        console.error("[WorkOrderPanel] Error loading order:", e.message || e);
        if (mounted) {
          setLoading(false);
          setLoadError(`Error al cargar la orden: ${e.message || "Error de conexión. Verifique su internet."}`);
        }
      }
    };
    loadOrderData();

    return () => {
      mounted = false;
      document.body.classList.remove("wo-fullscreen");
    };
  }, [orderId]);

  useEffect(() => {
    if (order?.id) {
      loadEventsCallback(false);
    }
  }, [order?.id, loadEventsCallback]);

  useEffect(() => {
    if (!orderId) return;
    if (loading) return;

    const iv = setInterval(async () => {
      try {
        const fresh = await base44.entities.Order.get(orderId);
        if (fresh && fresh.updated_date !== order?.updated_date) {
          console.log("[WO] Auto-refresh detectó cambios");
          setOrder(fresh);
          setStatus(normalizeStatusId(fresh.status || "intake"));
          clearEventCache(orderId);
          loadEventsCallback(true);
        }
      } catch (e) {
        console.warn("[WO] Auto-refresh falló (no crítico):", e.message);
      }
    }, 30000);

    return () => clearInterval(iv);
  }, [orderId, loading, order?.updated_date, loadEventsCallback]);

  async function askDeleteNote(noteId) {
    setPinModal({ open: true, targetNoteId: noteId, forOrder: false });
  }

  async function verifyAdminPin(pin) {
    const rows = await base44.entities.SystemConfig.filter({ key: "admin_pin" });
    const stored = rows?.[0]?.value || rows?.[0]?.value_json || "";
    const saved = typeof stored === "string" ? stored : stored?.pin || "";
    if (!saved || String(saved) !== String(pin)) {
      const err = new Error("PIN incorrecto");
      err.code = "BAD_PIN";
      throw err;
    }
    return true;
  }

  async function deleteNote(noteId, pin) {
    if (!order?.id) return;
    await verifyAdminPin(pin);
    await base44.entities.WorkOrderEvent.delete(noteId);
    clearEventCache(order.id);
    await loadEventsCallback(true);
    onUpdate?.();
    setPinModal({ open: false, targetNoteId: null, forOrder: false });
  }

  async function handleUploadMore(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length || !order?.id) return;
    setUploadErr("");
    setUploading(true);
    try {
      const newItems = [];
      for (const file of files) {
        try {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          newItems.push({
            id: `${Date.now()}-${file.name}`,
            type: file.type?.startsWith("video") ? "video" : "image",
            mime: file.type || "image/jpeg",
            filename: file.name,
            publicUrl: `${file_url}?v=${Date.now()}`,
            thumbUrl: `${file_url}?v=${Date.now()}`
          });
        } catch (err) {
          console.error("Upload error:", err);
          setUploadErr("Algunas imágenes no se pudieron subir.");
        }
      }
      const next = [...photos, ...newItems];
      await base44.entities.Order.update(order.id, { photos_metadata: next });
      onUpdate?.();

      let me = null;
      try {me = await base44.auth.me();} catch {}

      await base44.entities.WorkOrderEvent.create({
        order_id: order.id,
        order_number: order.order_number,
        event_type: "photo_upload",
        description: `Se subieron ${newItems.length} archivo(s).`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: { count: newItems.length }
      });
      clearEventCache(order.id);
      await loadEventsCallback(true);
    } catch (err) {
      console.error(err);
      setUploadErr("Error subiendo imágenes.");
    } finally {
      e.target.value = "";
      setUploading(false);
    }
  }

  async function changeStatus(newStatusRaw, statusNote = "", metadata = {}) {
    if (!order?.id) return;
    const nextId = normalizeStatusId(newStatusRaw);

    if (nextId === "cancelled") {
      setCancelModalOpen(true);
      return;
    }

    // ✅ Si cambia a completed o picked_up, verificar balance ANTES de proceder
    if (nextId === "completed" || nextId === "picked_up" || nextId === "ready_for_pickup") {
      const total = Number(order.total || 0);
      const totalPaid = Number(order.total_paid || order.paid || 0);
      const balance = Math.max(0, total - totalPaid);

      if (balance > 0.01) {
        // Hay balance pendiente, abrir POS para pago total
        const shouldProceed = confirm(
          `Esta orden tiene un balance pendiente de $${balance.toFixed(2)}.\n\n` +
          `¿Deseas abrir el POS para cobrar ahora?`
        );

        if (shouldProceed) {
          navigate(createPageUrl(`POS?workOrderId=${order.id}&balance=${balance}&mode=full`), {
            state: { fromDashboard: true, paymentMode: "full" }
          });
          return; // No cambiar estado hasta que se cobre
        }
      }
    }

    setChangingStatus(true);
    try {
      const updateWithRetry = async (retries = 3) => {
        try {
          let me = null;
          try {
            me = await base44.auth.me();
          } catch (authError) {
            console.error("[WorkOrderPanel] Auth error during status update:", authError);
            throw new Error("Sesión expirada. Por favor, recargue la página.");
          }
          if (!me) {
            throw new Error("Usuario no autenticado.");
          }

          const prevStatusId = normalizeStatusId(order.status || status || "intake");

          const updateData = {
            status: nextId,
            updated_date: new Date().toISOString(),
            status_note: statusNote || null,
            status_note_visible_to_customer: false
          };

          if (metadata && Object.keys(metadata).length > 0) {
            updateData.status_metadata = {
              kind: nextId,
              ...metadata
            };
          }

          const history = order.status_history || [];
          history.push({
            status: nextId,
            timestamp: new Date().toISOString(),
            changed_by: me.full_name || me.email,
            note: statusNote || null,
            visible_to_customer: false
          });
          updateData.status_history = history;

          await base44.entities.Order.update(order.id, updateData);

          setStatus(nextId);
          setOrder((prevOrder) => ({
            ...prevOrder,
            status: nextId,
            updated_date: updateData.updated_date,
            status_note: updateData.status_note,
            status_note_visible_to_customer: updateData.status_note_visible_to_customer,
            status_history: updateData.status_history,
            ...(updateData.status_metadata && { status_metadata: updateData.status_metadata })
          }));

          await base44.entities.WorkOrderEvent.create({
            order_id: order.id,
            order_number: order.order_number,
            event_type: "status_change",
            description: `Estado: ${getStatusConfig(prevStatusId).label} → ${getStatusConfig(nextId).label}${statusNote ? ` - ${statusNote}` : ""}`,
            user_name: me?.full_name || me?.email || "Sistema",
            user_id: me?.id || null,
            metadata: { from: prevStatusId, to: nextId, ...(metadata || {}) }
          });

          if (nextId === "pending_order") {
            await base44.entities.WorkOrderEvent.create({
              order_id: order.id,
              order_number: order.order_number,
              event_type: "pending_order",
              description: "Trabajo pendiente de ordenar pieza(s)..",
              user_name: me?.full_name || me?.email || "Sistema",
              user_id: me?.id || null
            });
            try {
              window.localStorage.setItem(`pending_order_${order.id}`, String(Date.now()));
              window.dispatchEvent(new Event("force-refresh"));
            } catch {}
          }

          clearEventCache(order.id);
          await loadEventsCallback(true);
          await handleRefresh();
          onUpdate?.();

          if (nextId === "waiting_parts") setPartsModalOpen(true);
          if (nextId === "reparacion_externa") setExternalModalOpen(true);

          try {
            const eventType = nextId === "ready_for_pickup" ? "ready_for_pickup" :
            nextId === "completed" ? "completed" :
            "order_status_changed";

            await NotificationService.sendAutomatedNotification(
              { ...order, status: nextId },
              eventType,
              {
                new_status: nextId,
                old_status: prevStatusId
              }
            );
          } catch (notifError) {
            console.warn("Could not send automated notification:", notifError);
          }

          setShowStatusModal(false);
          setPartsModalOpen(false);
          setExternalModalOpen(false);

        } catch (error) {
          if (retries > 0 && (
          String(error.message).includes("Rate limit") ||
          String(error.message).includes("Network Error") ||
          String(error.message).includes("Failed to fetch")))
          {
            console.warn(`[WorkOrderPanel] Retrying status update (${retries} left)...`);
            await new Promise((resolve) => setTimeout(resolve, 2000));
            return updateWithRetry(retries - 1);
          }
          throw error;
        }
      };

      await updateWithRetry();

    } catch (err) {
      console.error("Error actualizando estado:", err);
      alert(`Error al cambiar estado:\n${err.message || "Verifique su conexión a internet"}`);
    } finally {
      setChangingStatus(false);
    }
  }

  async function saveCancelReason(reason) {
    if (!order?.id) return;
    try {
      await base44.entities.Order.update(order.id, {
        status: "cancelled",
        updated_date: new Date().toISOString(),
        status_metadata: {
          kind: "cancelled",
          cancellation_reason: reason
        }
      });

      setStatus("cancelled");
      setOrder((prevOrder) => ({
        ...prevOrder,
        status: "cancelled",
        updated_date: new Date().toISOString(),
        status_metadata: { kind: "cancelled", cancellation_reason: reason }
      }));

      let me = null;
      try {me = await base44.auth.me();} catch {}

      await base44.entities.WorkOrderEvent.create({
        order_id: order.id,
        order_number: order.order_number,
        event_type: "status_change",
        description: `Orden cancelada. Motivo: ${reason}`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: { to: "cancelled", reason }
      });

      setCancelModalOpen(false);
      onUpdate?.();
      clearEventCache(order.id);
      await loadEventsCallback(true);

      await NotificationService.notifyOrderStatusChange(
        { ...order, status: "cancelled", status_metadata: { kind: "cancelled", cancellation_reason: reason } },
        "cancelled",
        me
      );

    } catch (err) {
      console.error("Error cancelando orden:", err);
      alert(`Error: ${err.message || "No se pudo cancelar la orden"}`);
    }
  }

  async function saveWaitingParts({ supplier, tracking }) {
    if (!order?.id) return;
    try {
      await base44.entities.Order.update(order.id, {
        parts_supplier: supplier || "",
        parts_tracking: tracking || ""
      });

      setOrder((prevOrder) => ({ ...prevOrder, parts_supplier: supplier || "", parts_tracking: tracking || "" }));

      let me = null;
      try {me = await base44.auth.me();} catch {}

      await base44.entities.WorkOrderEvent.create({
        order_id: order.id,
        order_number: order.order_number,
        event_type: "parts_info",
        description: `Proveedor: ${supplier || "—"} · Tracking: ${tracking || "—"}`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: { supplier, tracking }
      });

      setPartsModalOpen(false);
      onUpdate?.();
      clearEventCache(order.id);
      await loadEventsCallback(true);
    } catch (err) {
      console.error("Error guardando datos de piezas:", err);
      alert(`Error: ${err.message || "No se pudieron guardar los datos"}`);
    }
  }

  async function saveExternalShop({ shop, work }) {
    if (!order?.id) return;
    try {
      await base44.entities.Order.update(order.id, {
        external_shop: shop || "",
        external_work: work || ""
      });

      setOrder((prevOrder) => ({ ...prevOrder, external_shop: shop || "", external_work: work || "" }));

      let me = null;
      try {me = await base44.auth.me();} catch {}

      await base44.entities.WorkOrderEvent.create({
        order_id: order.id,
        order_number: order.order_number,
        event_type: "external_shop",
        description: `Taller: ${shop || "—"} · Trabajo: ${work || "—"}`,
        user_name: me?.full_name || me?.email || "Sistema",
        user_id: me?.id || null,
        metadata: { shop, work }
      });

      setExternalModalOpen(false);
      onUpdate?.();
      clearEventCache(order.id);
      await loadEventsCallback(true);
    } catch (err) {
      console.error("Error guardando taller externo:", err);
      alert(`Error: ${err.message || "No se pudieron guardar los datos"}`);
    }
  }

  // Removed: handleDepositSave function as it's now handled by the POS component.
  // Removed: setShowDepositModal state and the DepositModal component.

  const SecurityItem = ({ label, masked, onToggle, visibleValue }) =>
  <div className="min-w-0">
      <div className="text-[11px] text-gray-400">{label}</div>
      <div className="flex items-center gap-2">
        <span className="text-[13px] text-white font-mono tracking-widest">
          {masked ? "••••••" : visibleValue || "—"}
        </span>
        <button className="text-gray-300 hover:text-white" onClick={onToggle} title="Mostrar/Ocultar">
          {masked ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
        </button>
      </div>
    </div>;


  const eventStyle = (type) => {
    const t = String(type || "").toLowerCase();
    if (t === "note" || t === "note_added") return { pill: "bg-slate-500/20 text-slate-200 border-slate-500/30", box: "border-slate-500/30 bg-slate-500/10" };
    if (t === "status_change") return { pill: "bg-blue-500/20 text-blue-200 border-blue-500/30", box: "border-blue-500/30 bg-blue-500/10" };
    if (t === "parts_info") return { pill: "bg-amber-500/20 text-amber-200 border-amber-500/30", box: "border-amber-500/30 bg-amber-500/10" };
    if (t === "external_shop") return { pill: "bg-fuchsia-500/20 text-fuchsia-200 border-fuchsia-500/30", box: "border-fuchsia-500/30 bg-fuchsia-500/10" };
    if (t === "photo_upload") return { pill: "bg-purple-500/20 text-purple-200 border-purple-500/30", box: "border-purple-500/30 bg-purple-500/10" };
    if (t === "stock_adjust") return { pill: "bg-teal-500/20 text-teal-200 border-teal-500/30", box: "border-teal-500/30 bg-teal-500/10" };
    if (t === "stock_warning") return { pill: "bg-orange-500/20 text-orange-200 border-orange-500/30", box: "border-orange-500/30 bg-orange-500/10" };
    if (t === "create") return { pill: "bg-emerald-600/20 text-emerald-200 border-emerald-600/30", box: "border-emerald-600/30 bg-emerald-600/10" };
    if (t === "initial_problem") return { pill: "bg-rose-500/20 text-rose-200 border-rose-500/30", box: "border-rose-500/30 bg-rose-500/10" };
    if (t === "pending_order") return { pill: "bg-yellow-500/20 text-yellow-200 border-yellow-500/30", box: "border-yellow-500/30 bg-yellow-500/10" };
    if (t === "cancelled") return { pill: "bg-red-500/20 text-red-200 border-red-500/30", box: "border-red-500/30 bg-red-500/10" };
    if (t === "payment") return { pill: "bg-green-500/20 text-green-200 border-green-500/30", box: "border-green-500/30 bg-green-500/10" };
    if (t === "item_added" || t === "item_removed") return { pill: "bg-cyan-500/20 text-cyan-200 border-cyan-500/30", box: "border-cyan-500/30 bg-cyan-500/10" };
    if (t === "link") return { pill: "bg-indigo-500/20 text-indigo-200 border-indigo-500/30", box: "border-indigo-500/30 bg-indigo-500/10" };
    return { pill: "bg-gray-500/20 text-gray-200 border-gray-500/30", box: "border-gray-500/30 bg-gray-500/10" };
  };

  if (loading && !order && !loadError) {
    return (
      <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm">
        <style>{`
          body.wo-fullscreen nav[aria-orientation="vertical"],
          body.wo-fullscreen .sidebar,
          body.wo-fullscreen .left-nav,
          body.wo-fullscreen [data-sidebar],
          body.wo-fullscreen [aria-label="Sidebar"],
          body.wo-fullscreen [data-global-dock] {
            display: none !important;
          }
          body.wo-fullscreen .with-sidebar,
          body.wo-fullscreen .content,
          body.wo-fullscreen main,
          body.wo-fullscreen #root {
            margin-left: 0 !important;
            padding-left: 0 !important;
          }
        `}</style>
        <div className="absolute inset-0 grid place-items-center">
          <div className="bg-[#0F0F12] rounded-lg p-8 border border-white/10">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-500 mx-auto mb-4"></div>
              <p className="text-white text-lg">Cargando orden...</p>
            </div>
          </div>
        </div>
      </div>);

  }

  if (loadError) {
    return (
      <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm">
        <style>{`
          body.wo-fullscreen nav[aria-orientation="vertical"],
          body.wo-fullscreen .sidebar,
          body.wo-fullscreen .left-nav,
          body.wo-fullscreen [data-sidebar],
          body.wo-fullscreen [aria-label="Sidebar"],
          body.wo-fullscreen [data-global-dock] {
            display: none !important;
          }
          body.wo-fullscreen .with-sidebar,
          body.wo-fullscreen .content,
          body.wo-fullscreen main,
          body.wo-fullscreen #root {
            margin-left: 0 !important;
            padding-left: 0 !important;
          }
        `}</style>
        <div className="absolute inset-0 grid place-items-center p-4">
          <div className="bg-[#0F0F12] rounded-lg p-8 border border-white/10 max-w-md w-full">
            <div className="text-center">
              <p className="text-red-400 text-lg mb-4">{loadError}</p>
              <Button onClick={handleClose} className="bg-red-600 hover:bg-red-700">
                Cerrar
              </Button>
            </div>
          </div>
        </div>
      </div>);

  }

  if (!order) {
    return (
      <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm">
        <style>{`
          body.wo-fullscreen nav[aria-orientation="vertical"],
          body.wo-fullscreen .sidebar,
          body.wo-fullscreen .left-nav,
          body.wo-fullscreen [data-sidebar],
          body.wo-fullscreen [aria-label="Sidebar"],
          body.wo-fullscreen [data-global-dock] {
            display: none !important;
          }
          body.wo-fullscreen .with-sidebar,
          body.wo-fullscreen .content,
          body.wo-fullscreen main,
          body.wo-fullscreen #root {
            margin-left: 0 !important;
            padding-left: 0 !important;
          }
        `}</style>
        <div className="absolute inset-0 grid place-items-center p-4">
          <div className="bg-[#0F0F12] rounded-lg p-8 border border-white/10 max-w-md w-full">
            <div className="text-center">
              <p className="text-red-400 text-lg mb-4">Orden no disponible o no encontrada.</p>
              <Button onClick={handleClose} className="bg-red-600 hover:bg-red-700">
                Cerrar
              </Button>
            </div>
          </div>
        </div>
      </div>);

  }

  return (
    <div className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-sm overflow-hidden">
      <style>{`
        body.wo-fullscreen nav[aria-orientation="vertical"],
        body.wo-fullscreen .sidebar,
        body.wo-fullscreen .left-nav,
        body.wo-fullscreen [data-sidebar],
        body.wo-fullscreen [aria-label="Sidebar"],
        body.wo-fullscreen [data-global-dock] {
          display: none !important;
        }
        body.wo-fullscreen .with-sidebar,
        body.wo-fullscreen .content,
        body.wo-fullscreen main,
        body.wo-fullscreen #root {
          margin-left: 0 !important;
          padding-left: 0 !important;
        }
      `}</style>

      <div className="h-full flex flex-col bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A]">
        <div className="flex-shrink-0 border-b border-gray-800 bg-black/60 backdrop-blur">
          <div className="max-w-[1800px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClose}
                className="text-gray-400 hover:text-white">
                <X className="w-5 h-5 mr-2" />
                Cerrar
              </Button>

              {order &&
              <div className="flex items-center gap-3">
                  <h1 className="text-xl font-bold text-white">
                    {order.order_number}
                  </h1>
                  <Badge className={getStatusConfig(order.status).colorClasses}>
                    {getStatusConfig(order.status).label}
                  </Badge>
                </div>
              }
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleRefresh(true)}
                disabled={loading}
                className="border-gray-700 text-gray-300">
                <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Actualizar
              </Button>
            </div>
          </div>
        </div>

        {loading && !order ?
        <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-gray-400">Cargando orden...</p>
            </div>
          </div> :
        order ?
        <div className="flex-1 overflow-y-auto">
            <div className="max-w-[1800px] mx-auto px-4 sm:px-6 py-6 space-y-6">

              <Card className="bg-[#0F0F12] border-white/10">
                <CardHeader className="border-b border-white/10 pb-4">
                  <CardTitle className="text-white flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
                    Estado de la Orden
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="mb-6 p-4 rounded-lg bg-gradient-to-r from-red-600/20 to-red-800/20 border-2 border-red-500/50">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-gray-400 mb-1">Estado Actual</p>
                        <p className="text-2xl font-bold text-white">
                          {getStatusConfig(status).label}
                        </p>
                      </div>
                      <div className={`px-4 py-2 rounded-full border ${getStatusConfig(status).colorClasses}`}>
                        <span className="text-sm font-semibold">
                          {getStatusConfig(status).label}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <p className="text-sm font-semibold text-gray-400 uppercase tracking-wide">
                      Cambiar Estado
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                      {activeStatuses.map((s) => {
                      const config = getStatusConfig(s.id);
                      const isCurrent = normalizeStatusId(status) === s.id;

                      return (
                        <button
                          key={s.id}
                          onClick={() => !isCurrent && changeStatus(s.id, "", {})}
                          disabled={isCurrent || changingStatus}
                          className={`
                              p-3 rounded-lg border-2 transition-all text-left
                              ${isCurrent ?
                          `${config.colorClasses} opacity-50 cursor-not-allowed` :
                          `border-white/10 bg-black/40 hover:${config.colorClasses.replace('text-', 'border-').split(' ')[0]} hover:bg-white/5`}
                            `
                          }>
                            <div className="flex items-center justify-between mb-1">
                              <span className={`text-xs font-semibold ${isCurrent ? '' : 'text-gray-400'}`}>
                                {config.label}
                              </span>
                              {isCurrent && <Check className="w-4 h-4" />}
                            </div>
                            {isCurrent &&
                          <div className="text-[10px] text-gray-300 mt-1">
                                Estado actual
                              </div>
                          }
                          </button>);

                    })}
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t border-white/10">
                    <p className="text-sm font-semibold text-gray-400 uppercase tracking-wide mb-3">
                      Estados Finales
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {closedStatuses.map((s) => {
                      const config = getStatusConfig(s.id);
                      const isCurrent = normalizeStatusId(status) === s.id;

                      return (
                        <button
                          key={s.id}
                          onClick={() => !isCurrent && changeStatus(s.id, "", {})}
                          disabled={isCurrent || changingStatus}
                          className={`
                              p-3 rounded-lg border-2 transition-all text-left
                              ${isCurrent ?
                          `${config.colorClasses} opacity-50 cursor-not-allowed` :
                          `border-white/10 bg-black/40 hover:${config.colorClasses.replace('text-', 'border-').split(' ')[0]} hover:bg-white/5`}
                            `
                          }>
                            <div className="flex items-center justify-between mb-1">
                              <span className={`text-xs font-semibold ${isCurrent ? '' : 'text-gray-400'}`}>
                                {config.label}
                              </span>
                              {isCurrent && <Check className="w-4 h-4" />}
                            </div>
                            {isCurrent &&
                          <div className="text-[10px] text-gray-300 mt-1">
                                Estado actual
                              </div>
                          }
                          </button>);

                    })}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {Array.isArray(order.checklist_items) && order.checklist_items.length > 0 &&
            <Card className="bg-[#0F0F12] border-white/10 p-4">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-red-600" />
                    Checklist del Wizard
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                    {order.checklist_items.map((item, idx) =>
                <div
                  key={idx}
                  className="flex items-center gap-2 p-2 rounded bg-black/40 border border-white/10">
                        <input
                    type="checkbox"
                    checked={item.status === "ok" || item.completed}
                    readOnly
                    className="w-4 h-4 rounded border-gray-600 text-red-600 cursor-default" />

                        <span className="text-sm text-gray-300 truncate">
                          {item.label || item.name || "Item"}
                        </span>
                      </div>
                )}
                  </div>
                </Card>
            }

              <Card className="p-3 sm:p-4 bg-[#111114] border-white/10">
                <h3 className="text-white font-semibold mb-3 text-sm sm:text-base">Resumen</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <Field label="Cliente" value={o.customer_name} />
                  <PhoneField phoneRaw={o.customer_phone} />
                  <EmailField email={o.customer_email} />
                  {o.company_name && <Field label="Empresa" value={o.company_name} />}

                  <Field label="Equipo" value={`${o.device_brand || "—"} ${o.device_model || ""}`} />
                  <Field label="Tipo" value={o.device_type || o.device_subcategory || "—"} />
                  <Field label="Serie / IMEI" value={o.device_serial} mono />
                  <Field label="Términos aceptados" value={o.terms_accepted ? "Sí" : "No"} />

                  {(o.parts_supplier || o.parts_tracking) &&
                <>
                      <Field label="Suplidor (piezas)" value={o.parts_supplier} />
                      <Field label="Tracking (piezas)" value={o.parts_tracking} />
                    </>
                }

                  {(o.external_shop || o.external_work) &&
                <>
                      <Field label="Taller externo" value={o.external_shop} />
                      <Field label="Trabajo externo" value={o.external_work} />
                    </>
                }

                  {o.status === "cancelled" && o.status_metadata?.cancellation_reason &&
                <div className="sm:col-span-2">
                      <Field label="Motivo de cancelación" value={o.status_metadata.cancellation_reason} />
                    </div>
                }
                </div>
              </Card>

              <OrderItemsSection
              order={o}
              onUpdated={onUpdate}
              clearEventCache={clearEventCache}
              loadEventsCallback={loadEventsCallback} />


              {/* Removed: Deposit button as it's now handled within OrderItemsSection */}

              <Card className="p-3 sm:p-4 bg-[#111114] border-white/10">
                <h3 className="text-white font-semibold mb-3 text-sm sm:text-base">Seguridad</h3>
                {!hasPassword && !hasPin && !hasPattern ?
              <div className="text-[13px] text-gray-400">—</div> :

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    {hasPassword &&
                <SecurityItem
                  label="Password"
                  masked={!showPass}
                  onToggle={() => setShowPass((v) => !v)}
                  visibleValue={safeAtob(sec.device_password)} />

                }
                    {hasPin &&
                <SecurityItem
                  label="PIN"
                  masked={!showPin}
                  onToggle={() => setShowPin((v) => !v)}
                  visibleValue={safeAtob(sec.device_pin)} />

                }
                    {hasPattern &&
                <div className="sm:col-span-2">
                        <div className="text-[11px] text-gray-400">Patrón (Android)</div>
                        <div className="mt-1">
                          <img
                      src={sec.pattern_image}
                      alt="Patrón"
                      className="w-32 h-32 sm:w-44 sm:h-44 object-contain rounded-md border border-white/10 bg-black/40" />

                        </div>
                      </div>
                }
                  </div>
              }
              </Card>

              <Card className="p-3 sm:p-4 bg-[#111114] border-white/10">
                <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
                  <h3 className="text-white font-semibold flex items-center gap-2 text-sm sm:text-base">
                    Fotos / Evidencias <ImageIcon className="w-4 h-4" />
                  </h3>
                  <div className="flex items-center gap-2">
                    <label className={`inline-flex items-center gap-2 px-3 h-9 rounded-md cursor-pointer text-xs sm:text-sm ${uploading ? "bg-gray-700 text-gray-300" : "bg-red-600 hover:bg-red-700 text-white"}`}>
                      {uploading ? "Subiendo..." : "Subir fotos"}
                      <input type="file" accept="image/*,video/*" multiple onChange={handleUploadMore} className="hidden" disabled={uploading} />
                    </label>
                  </div>
                </div>

                {uploadErr && <div className="text-[12px] text-amber-300 mb-2">{uploadErr}</div>}

                <OrderPhotosGallery photos={photos} onPhotoClick={handlePhotoClick} />
              </Card>

              <div data-section="comments">
                <CommentSection order={o} onUpdated={loadEventsCallback} />
              </div>

              <Card className="p-3 sm:p-4 bg-[#111114] border-white/10">
                <h4 className="text-white font-semibold mb-3 flex items-center gap-2 text-sm sm:text-base">
                  Timeline de actividad <ActivitySquare className="w-4 h-4" />
                </h4>

                {loadingEvents &&
              <div className="text-center py-4 text-gray-400 text-xs sm:text-sm">Cargando eventos...</div>
              }

                {(o.initial_problem || "").trim() &&
              <div className={`mb-3 p-3 rounded-md border ${eventStyle("initial_problem").box}`}>
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <Pin className="w-4 h-4 text-rose-300" />
                        <span className="text-white font-medium text-xs sm:text-sm">Problema inicial</span>
                      </div>
                      <div className="text-[10px] sm:text-[11px] text-gray-300">
                        {o.created_date || o.created_at ? new Date(o.created_date || o.created_at).toLocaleString() : "—"}
                      </div>
                    </div>
                    <div className="mt-1 text-[12px] sm:text-[13px] text-gray-100 whitespace-pre-wrap break-words">
                      <LinkifiedText text={o.initial_problem} />
                    </div>
                  </div>
              }

                {!loadingEvents && events.length === 0 ?
              <div className="text-[12px] sm:text-[13px] text-gray-400">Sin actividad aún.</div> :

              <ul className="space-y-3">
                    {events.map((ev) => {
                  const ts = new Date(ev.created_at || ev.created_date || ev.createdOn || Date.now());
                  const name = ev.user_name || "Sistema";
                  const initials = (name || "?").split(" ").slice(0, 2).map((s) => s[0]?.toUpperCase() || "").join("");
                  const styles = eventStyle(ev.event_type);

                  const isComment = ev.event_type === "note" || ev.event_type === "note_added";
                  const isLink = ev.event_type === "link";
                  const commentMeta = isComment ? ev.metadata || {} : {};
                  const linkMeta = isLink ? ev.metadata || {} : {};
                  let commentTarget = "";
                  if (isComment) {
                    if (commentMeta.for_customer) {
                      commentTarget = "(Cliente)";
                    } else if (commentMeta.internal_only) {
                      commentTarget = "(Interno)";
                    } else if (commentMeta.target_user_id) {
                      commentTarget = `(Usuario: ${commentMeta.target_user_name || commentMeta.target_user_id})`;
                    }
                  }

                  return (
                    <li key={ev.id} className={`p-2 sm:p-3 rounded-md border ${styles.box}`}>
                          <div className="flex items-start gap-2 sm:gap-3">
                            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/10 text-white grid place-items-center text-[11px] sm:text-[12px] flex-shrink-0">
                              {initials || "?"}
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between gap-2 flex-wrap">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="text-[12px] sm:text-[13px] text-white font-medium truncate">{name}</span>
                                  <span className={`text-[9px] sm:text-[10px] border rounded-full px-1.5 py-[1px] ${styles.pill}`}>
                                    {ev.event_type || "evento"} {commentTarget && <span className="ml-1">{commentTarget}</span>}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <div className="text-[10px] sm:text-[11px] text-gray-300 whitespace-nowrap">
                                    {ts.toLocaleString()}
                                  </div>
                                  {isComment &&
                              <button
                                className="text-gray-300 hover:text-red-300"
                                title="Eliminar comentario"
                                onClick={() => setPinModal({ open: true, targetNoteId: ev.id, forOrder: false })}>
                                      <Trash2 className="w-3 h-3 sm:w-4 sm:h-4" />
                                    </button>
                              }
                                  {isLink &&
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  const url = linkMeta?.url;
                                  const validatedUrl = normalizeAndValidateUrl(url);
                                  if (validatedUrl) {
                                    try {
                                      const urlObj = new URL(validatedUrl);
                                      if (['http:', 'https:'].includes(urlObj.protocol)) {
                                        window.open(validatedUrl, "_blank", "noopener,noreferrer");
                                      } else {
                                        alert("Solo se permiten URLs con protocolo HTTP o HTTPS");
                                      }
                                    } catch (e) {
                                      console.error("Error opening link from event:", e);
                                      alert(`No se pudo abrir el link. URL: ${validatedUrl || 'vacía'}\n\nError: ${e.message || 'URL inválida'}`);
                                    }
                                  } else {
                                    alert("URL inválida o vacía en el evento.");
                                  }
                                }}
                                className="h-6 px-2 text-xs border-white/15">
                                      Abrir
                                    </Button>
                              }
                                </div>
                              </div>
                              <div className="text-[12px] sm:text-[13px] text-gray-100 mt-1 whitespace-pre-wrap break-words">
                                <LinkifiedText text={ev.description || ""} />
                              </div>
                            </div>
                          </div>
                        </li>);

                })}
                  </ul>
              }
              </Card>

            </div>
          </div> :

        <div className="flex-1 flex items-center justify-center">
            <p className="text-gray-500">No se encontró la orden</p>
          </div>
        }
      </div>

      <PinPadModal
        open={pinModal.open}
        onClose={() => setPinModal({ open: false, targetNoteId: null, forOrder: false })}
        title="PIN administrativo"
        onSubmit={async (pin) => {
          if (pinModal.forOrder) {
            console.warn("Order deletion attempted via PIN modal, but UI button is removed.");
            throw new Error("Acción no permitida desde esta interfaz");
          } else if (pinModal.targetNoteId) {
            await deleteNote(pinModal.targetNoteId, pin);
          }
        }} />


      <WaitingPartsModal
        open={partsModalOpen}
        onClose={() => setPartsModalOpen(false)}
        onSave={saveWaitingParts} />


      <ExternalShopModal
        open={externalModalOpen}
        onClose={() => setExternalModalOpen(false)}
        onSave={saveExternalShop} />


      <CancelOrderModal
        open={cancelModalOpen}
        onClose={() => setCancelModalOpen(false)}
        onSave={saveCancelReason} />


      {/* Removed: DepositModal component as its functionality is now handled via POS */}

      <Lightbox
        open={lbOpen}
        items={photos}
        index={lbIndex}
        onClose={() => setLbOpen(false)}
        onMove={(next) => setLbIndex(next)} />

    </div>);

}