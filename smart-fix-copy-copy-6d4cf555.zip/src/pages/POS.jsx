import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ShoppingCart, Search, Plus, Minus, Trash2, User, AlertCircle, X
} from "lucide-react";
import CustomerSelector from "../components/pos/CustomerSelector";
import PaymentModal from "../components/pos/PaymentModal";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

function AddItemModal({ open, onClose, onSelect }) {
  const [search, setSearch] = useState("");
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      loadInventory();
      setSearch("");
    }
  }, [open]);

  const loadInventory = async () => {
    setLoading(true);
    try {
      const [products, services] = await Promise.all([
        base44.entities.Product.filter({ active: true }, undefined, 200),
        base44.entities.Service.filter({ active: true }, undefined, 100)
      ]);

      const allItems = [
        ...(products || []).map(p => ({ ...p, _type: "product" })),
        ...(services || []).map(s => ({ ...s, _type: "service" }))
      ];

      setInventory(allItems);
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = useMemo(() => {
    const q = search.toLowerCase();
    if (!q) return inventory;

    return inventory.filter(item =>
      (item.name || "").toLowerCase().includes(q) ||
      (item.sku || "").toLowerCase().includes(q) ||
      (item.code || "").toLowerCase().includes(q) ||
      (item.description || "").toLowerCase().includes(q)
    );
  }, [inventory, search]);

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden bg-[#111114] border-white/10">
        <DialogHeader className="border-b border-white/10 pb-4">
          <DialogTitle className="text-white text-xl">Añadir Producto / Servicio</DialogTitle>
        </DialogHeader>

        <div className="py-4 space-y-4">
          {/* Búsqueda */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Buscar por nombre, SKU, código..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-black/40 border-white/15 text-white"
              autoFocus
            />
          </div>

          {/* Lista de resultados */}
          <div className="max-h-[50vh] overflow-y-auto">
            {loading ? (
              <div className="text-center py-8 text-gray-400">Cargando...</div>
            ) : filteredItems.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {search ? "Sin resultados" : "No hay inventario disponible"}
              </div>
            ) : (
              <div className="space-y-2">
                {filteredItems.map(item => (
                  <button
                    key={`${item._type}-${item.id}`}
                    onClick={() => {
                      onSelect(item, item._type);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-3 bg-white/5 border border-white/10 rounded-lg hover:border-red-600 hover:bg-white/10 transition-colors text-left">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-white truncate">{item.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className={item._type === "service" 
                          ? "bg-blue-600/20 text-blue-300 border-blue-600/30" 
                          : "bg-emerald-600/20 text-emerald-300 border-emerald-600/30"}>
                          {item._type === "service" ? "Servicio" : "Producto"}
                        </Badge>
                        {item.sku && (
                          <span className="text-xs text-gray-400">{item.sku}</span>
                        )}
                        {item.code && (
                          <span className="text-xs text-gray-400">{item.code}</span>
                        )}
                      </div>
                      {item.description && (
                        <p className="text-xs text-gray-500 mt-1 truncate">{item.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-3 ml-4">
                      <span className="text-lg font-semibold text-emerald-400">
                        ${(item.price || 0).toFixed(2)}
                      </span>
                      <Button size="sm" className="bg-red-600 hover:bg-red-700">
                        Seleccionar
                      </Button>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function POSPage() {
  const [items, setItems] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showCustomerSelector, setShowCustomerSelector] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showAddItemModal, setShowAddItemModal] = useState(false);

  const urlParams = new URLSearchParams(window.location.search);
  const workOrderId = urlParams.get("workOrderId");

  useEffect(() => {
    if (workOrderId) {
      loadWorkOrder();
    }
  }, [workOrderId]);

  const loadWorkOrder = async () => {
    try {
      const order = await base44.entities.Order.get(workOrderId);
      if (order) {
        const orderItems = order.order_items || [];
        setItems(orderItems.map(item => ({
          id: item.__source_id || item.id || `temp-${Date.now()}`,
          name: item.name,
          price: item.price,
          quantity: item.qty || item.quantity || 1,
          type: item.__kind || item.type || "product",
          stock: item.stock
        })));

        if (order.customer_id) {
          try {
            const customer = await base44.entities.Customer.get(order.customer_id);
            setSelectedCustomer(customer);
          } catch {}
        }
      }
    } catch (error) {
      console.error("Error loading work order:", error);
    }
  };

  const addItem = (item, type) => {
    const existingIndex = items.findIndex(i => i.id === item.id);
    if (existingIndex >= 0) {
      const updated = [...items];
      updated[existingIndex].quantity += 1;
      setItems(updated);
    } else {
      setItems([...items, {
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: 1,
        type,
        stock: item.stock
      }]);
    }
  };

  const updateQuantity = (index, delta) => {
    const updated = [...items];
    updated[index].quantity = Math.max(1, updated[index].quantity + delta);
    setItems(updated);
  };

  const removeItem = (index) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.115;
  const total = subtotal + tax;

  const handlePaymentSuccess = () => {
    setItems([]);
    setSelectedCustomer(null);
    if (workOrderId) {
      window.history.back();
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-[#0B0B0F] to-[#0A0A0D]">
      {/* Header */}
      <div className="bg-black/80 backdrop-blur border-b border-red-900/30 px-4 sm:px-6 py-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShoppingCart className="w-6 h-6 sm:w-7 sm:h-7 text-red-600" />
            <h1 className="text-xl sm:text-2xl font-bold text-white">Punto de Venta</h1>
          </div>
          {workOrderId && (
            <Badge className="bg-blue-600/20 text-blue-300 border-blue-600/30">
              Cobrando Orden
            </Badge>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex flex-col">
        {/* Panel de carrito */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 min-h-0">
          <div className="max-w-4xl mx-auto space-y-4">
            {/* Cliente */}
            <Card className="p-4 bg-[#111114] border-white/10">
              {!selectedCustomer ? (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-red-400" />
                    <span className="text-red-300 text-sm">No hay cliente vinculado</span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => setShowCustomerSelector(true)}
                    className="bg-red-600 hover:bg-red-700">
                    Enlazar Cliente
                  </Button>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-red-600/20 flex items-center justify-center">
                      <User className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                      <p className="text-white font-semibold">{selectedCustomer.name}</p>
                      <p className="text-gray-400 text-sm">{selectedCustomer.phone}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowCustomerSelector(true)}
                    className="border-white/15">
                    Cambiar
                  </Button>
                </div>
              )}
            </Card>

            {/* Botón añadir producto/servicio */}
            <Button
              onClick={() => setShowAddItemModal(true)}
              className="w-full bg-red-600 hover:bg-red-700 h-12 text-base">
              <Plus className="w-5 h-5 mr-2" />
              Añadir Producto / Servicio
            </Button>

            {/* Lista de items */}
            {items.length === 0 ? (
              <Card className="p-8 bg-[#111114] border-white/10">
                <p className="text-center text-gray-500">No hay artículos en el carrito</p>
              </Card>
            ) : (
              <Card className="p-4 bg-[#111114] border-white/10">
                <div className="space-y-3">
                  {items.map((item, index) => (
                    <div
                      key={`${item.id}-${index}`}
                      className="flex items-center gap-3 p-3 bg-white/5 border border-white/10 rounded-lg">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-white truncate">{item.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className={item.type === "service" 
                            ? "bg-blue-600/20 text-blue-300 border-blue-600/30" 
                            : "bg-emerald-600/20 text-emerald-300 border-emerald-600/30"}>
                            {item.type === "service" ? "Servicio" : "Producto"}
                          </Badge>
                          <span className="text-sm text-gray-400">
                            ${(item.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="icon"
                          variant="outline"
                          className="h-8 w-8 border-white/15"
                          onClick={() => updateQuantity(index, -1)}
                          disabled={item.quantity <= 1}>
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-8 text-center font-medium text-white">
                          {item.quantity}
                        </span>
                        <Button
                          size="icon"
                          variant="outline"
                          className="h-8 w-8 border-white/15"
                          onClick={() => updateQuantity(index, 1)}>
                          <Plus className="w-3 h-3" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-600/20"
                          onClick={() => removeItem(index)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Totales */}
            <Card className="p-4 bg-[#111114] border-white/10">
              <div className="space-y-2">
                <div className="flex justify-between text-gray-400">
                  <span>Subtotal</span>
                  <span className="text-white font-semibold">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Impuesto (11.5%)</span>
                  <span className="text-white font-semibold">${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t border-white/10">
                  <span className="text-white">Total</span>
                  <span className="text-emerald-400">${total.toFixed(2)}</span>
                </div>
              </div>

              <Button
                onClick={() => setShowPaymentModal(true)}
                disabled={items.length === 0}
                className="w-full mt-4 bg-red-600 hover:bg-red-700 h-12 text-base">
                Procesar Pago
              </Button>
            </Card>
          </div>
        </div>
      </div>

      {/* Modales */}
      <CustomerSelector
        open={showCustomerSelector}
        onClose={() => setShowCustomerSelector(false)}
        onSelect={(customer) => {
          setSelectedCustomer(customer);
          setShowCustomerSelector(false);
        }}
      />

      <AddItemModal
        open={showAddItemModal}
        onClose={() => setShowAddItemModal(false)}
        onSelect={addItem}
      />

      <PaymentModal
        open={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        subtotal={subtotal}
        items={items}
        workOrderId={workOrderId}
        onSuccess={handlePaymentSuccess}
      />
    </div>
  );
}