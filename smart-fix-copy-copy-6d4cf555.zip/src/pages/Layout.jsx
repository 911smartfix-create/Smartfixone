

import React, { useEffect, useMemo, useState, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/components/utils/helpers";
import { Home, ClipboardList, ShoppingCart, Users, Boxes, BarChart3, Shield, Clock, Settings as SettingsIcon } from "lucide-react";
import NotificationCenter from "@/components/notifications/NotificationCenter";

export default function Layout({ children }) {
  const nav = useNavigate();
  const loc = useLocation();
  const [session, setSession] = useState(null);
  const [woFullscreen, setWoFullscreen] = useState(false);
  const [canManageUsers, setCanManageUsers] = useState(false);
  
  const [hoveredItem, setHoveredItem] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const navRef = useRef(null);
  const buttonRefs = useRef({});

  // ✅ Scroll to top cuando cambia la ruta
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [loc.pathname]);

  useEffect(() => {
    const s = sessionStorage.getItem("911-session");
    setSession(s ? JSON.parse(s) : null);
  }, [loc.pathname, loc.search]);

  useEffect(() => {
    const checkUserManagement = async () => {
      if (!session) {
        setCanManageUsers(false);
        return;
      }
      try {
        const { can } = await import("@/components/utils/permissions");
        const hasPermission = await can("users.manage");
        setCanManageUsers(hasPermission);
      } catch (error) {
        console.error("Failed to check user management permissions:", error);
        setCanManageUsers(session?.userRole === "admin");
      }
    };
    
    checkUserManagement();
  }, [session]);

  useEffect(() => {
    const read = () => document.body.classList.contains("wo-fullscreen");
    setWoFullscreen(read());

    const obs = new MutationObserver(() => setWoFullscreen(read()));
    obs.observe(document.body, { attributes: true, attributeFilter: ["class"] });
    return () => obs.disconnect();
  }, []);

  const hasOrderParam = useMemo(() => {
    try {
      const usp = new URLSearchParams(loc.search);
      return usp.has("order");
    } catch {
      return false;
    }
  }, [loc.search]);

  const hideNavbar = woFullscreen || hasOrderParam;

  const go = (to) => {
    nav(createPageUrl(to));
  };

  const isActive = (path) => {
    const currentPath = loc.pathname === "/" ? "/Dashboard" : loc.pathname;
    return currentPath === createPageUrl(path);
  };

  const navItems = [
    { path: "Dashboard", label: "Dashboard", icon: Home },
    { path: "Orders", label: "Órdenes", icon: ClipboardList },
    { path: "POS", label: "POS", icon: ShoppingCart },
    { path: "Customers", label: "Clientes", icon: Users },
    { path: "Inventory", label: "Inventario", icon: Boxes },
    { path: "Reports", label: "Reportes", icon: BarChart3 },
    { path: "Employees", label: "Empleados", icon: Clock },
  ];

  if (session?.userRole === "admin" || session?.userRole === "manager") {
    navItems.push({ path: "Settings", label: "Ajustes", icon: SettingsIcon });
  }

  if (canManageUsers) {
    navItems.push({ path: "UsersManagement", label: "Usuarios", icon: Shield });
  }

  const getItemUnderPointer = (clientX, clientY) => {
    for (const [path, ref] of Object.entries(buttonRefs.current)) {
      if (!ref) continue;
      const rect = ref.getBoundingClientRect();
      if (
        clientX >= rect.left &&
        clientX <= rect.right &&
        clientY >= rect.top &&
        clientY <= rect.bottom
      ) {
        return path;
      }
    }
    return null;
  };

  const handlePointerDown = (e) => {
    setIsDragging(true);
    const item = getItemUnderPointer(e.clientX, e.clientY);
    if (item) setHoveredItem(item);
  };

  const handlePointerMove = (e) => {
    if (!isDragging) return;
    const item = getItemUnderPointer(e.clientX, e.clientY);
    if (item && item !== hoveredItem) {
      setHoveredItem(item);
      if (navigator.vibrate) {
        navigator.vibrate(10);
      }
    }
  };

  const handlePointerUp = (e) => {
    if (isDragging && hoveredItem) {
      go(hoveredItem);
    }
    setIsDragging(false);
    setHoveredItem(null);
  };

  const handlePointerLeave = () => {
    setIsDragging(false);
    setHoveredItem(null);
  };

  return (
    <div data-theme="smartfix-v2" data-density="cozy" className="min-h-screen bg-gradient-to-b from-[#0B0B0F] to-[#0A0A0D] text-slate-100">
      <style>{`
        body.wo-fullscreen nav[data-main-navbar] { 
          display: none !important; 
        }
        
        /* Ocultar completamente el scrollbar */
        .nav-scroll {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        .nav-scroll::-webkit-scrollbar {
          display: none;
        }

        /* Prevenir selección durante drag */
        .nav-scroll.dragging {
          user-select: none;
          -webkit-user-select: none;
        }

        /* Smooth transitions */
        .nav-btn {
          transition: all 0.15s ease-out;
        }

        /* Gradient fade en los bordes del scroll */
        .nav-container {
          position: relative;
        }
        .nav-container::before,
        .nav-container::after {
          content: '';
          position: absolute;
          top: 0;
          bottom: 0;
          width: 12px;
          pointer-events: none;
          z-index: 10;
        }
        .nav-container::before {
          left: 0;
          background: linear-gradient(to right, rgba(0,0,0,0.8), transparent);
        }
        .nav-container::after {
          right: 0;
          background: linear-gradient(to left, rgba(0,0,0,0.8), transparent);
        }

        /* ✅ Responsive improvements */
        @media (max-width: 640px) {
          .nav-btn {
            padding: 0.375rem 0.5rem;
            font-size: 10px;
          }
        }
      `}</style>

      <nav 
        data-main-navbar
        className={`sticky top-0 z-50 bg-black/80 backdrop-blur-xl border-b border-red-900/30 transition-all duration-300 ${
          hideNavbar ? "opacity-0 pointer-events-none -translate-y-full" : "opacity-100 translate-y-0"
        }`}
      >
        <div className="max-w-[1920px] mx-auto">
          <div className="flex items-center h-12 sm:h-14 md:h-16 px-2 sm:px-3 md:px-6 gap-1.5 sm:gap-2 md:gap-4">
            {/* Logo - Más compacto en móvil */}
            <button 
              onClick={() => go("Dashboard")}
              className="flex items-center gap-1 sm:gap-1.5 md:gap-2 hover:opacity-80 transition-opacity flex-shrink-0"
            >
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e824240b8444c78a101a65/daf775990_1000035043.jpg"
                alt="911 SmartFix"
                className="w-6 h-6 sm:w-7 sm:h-7 md:w-9 md:h-9 rounded-full"
              />
              <span className="font-bold text-xs sm:text-sm md:text-lg hidden xs:block">911 SmartFix</span>
            </button>

            {/* Horizontal Scrollable Navigation - MÁS COMPACTO */}
            <div className="flex-1 overflow-hidden nav-container">
              <div 
                ref={navRef}
                className={`nav-scroll flex items-center gap-0.5 sm:gap-1 md:gap-2 overflow-x-auto ${isDragging ? 'dragging' : ''}`}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerLeave={handlePointerLeave}
                onPointerCancel={handlePointerLeave}
                style={{ touchAction: 'pan-y', paddingBottom: '2px' }}
              >
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item.path);
                  const isHovered = isDragging && hoveredItem === item.path;
                  
                  return (
                    <button
                      key={item.path}
                      ref={(el) => buttonRefs.current[item.path] = el}
                      onClick={() => !isDragging && go(item.path)}
                      className={`nav-btn flex items-center gap-1 sm:gap-1.5 px-1.5 sm:px-2 md:px-3 py-1 sm:py-1.5 md:py-2 rounded-lg font-medium text-[9px] sm:text-[10px] md:text-sm whitespace-nowrap flex-shrink-0 ${
                        active
                          ? "bg-red-600 text-white shadow-lg shadow-red-600/30"
                          : isHovered
                          ? "bg-red-500 text-white shadow-md shadow-red-500/40 scale-105"
                          : "text-gray-300 hover:bg-white/5 hover:text-white"
                      }`}
                      style={{
                        pointerEvents: isDragging ? 'none' : 'auto'
                      }}
                    >
                      <Icon className="w-3 h-3 sm:w-3.5 sm:h-3.5 md:w-4 md:h-4 flex-shrink-0" />
                      <span className="hidden xs:inline">
                        {item.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ✅ Notification Center - Más compacto */}
            <div className="flex-shrink-0">
              <NotificationCenter />
            </div>

            {/* User Avatar - Más compacto */}
            {session && (
              <div className="w-6 h-6 sm:w-7 sm:h-7 md:w-9 md:h-9 rounded-full bg-red-700 text-white grid place-items-center font-semibold text-[9px] sm:text-[10px] md:text-sm flex-shrink-0">
                {session.userName?.[0]?.toUpperCase() || "U"}
              </div>
            )}
          </div>
        </div>
      </nav>

      <main className="min-h-[calc(100vh-3rem)] sm:min-h-[calc(100vh-3.5rem)] md:min-h-[calc(100vh-4rem)]">{children}</main>
    </div>
  );
}

