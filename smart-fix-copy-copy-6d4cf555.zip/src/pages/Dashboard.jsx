
import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ClipboardList, Wallet, ChevronRight, StickyNote, Search, Clock, Settings as SettingsIcon, Users, ExternalLink } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/components/utils/helpers";
import WorkOrderWizard from "../components/workorder/WorkOrderWizard";
import OpenDrawerDialog from "../components/cash/OpenDrawerDialog";
import TodaySalesKPI from "../components/dashboard/TodaySalesKPI";
import PinAuthOverlayPro from "../components/dashboard/PinAuthOverlay";
import SendNoteModal from "../components/dashboard/SendNoteModal";
import { ORDER_STATUSES, getStatusConfig, normalizeStatusId } from "@/components/utils/statusRegistry";
import WorkOrderPanel from "../components/workorder/WorkOrderPanel";

import SalesOverviewWidget from "../components/dashboard/SalesOverviewWidget";
import InventoryAlertsWidget from "../components/dashboard/InventoryAlertsWidget";
import PendingRepairsWidget from "../components/dashboard/PendingRepairsWidget";
import CustomerActivityWidget from "../components/dashboard/CustomerActivityWidget";

function readSessionSync() {
  try {
    const raw = sessionStorage.getItem("911-session");
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function Toast({ toast, onClose }) {
  if (!toast) return null;
  return (
    <div className="fixed top-4 right-4 z-[9999]">
      <div className={`min-w-[260px] max-w-sm rounded-lg border px-4 py-3 shadow-lg backdrop-blur-md ${toast.variant === "error" ? "bg-red-600/90 border-red-400 text-white" : "bg-emerald-600/90 border-emerald-400 text-white"}`}>
        <div className="font-semibold">{toast.title}</div>
        {toast.message && <div className="text-sm opacity-90">{toast.message}</div>}
        <button className="mt-2 text-xs underline opacity-90 hover:opacity-100" onClick={onClose}>Cerrar</button>
      </div>
    </div>);

}

const SimplifiedOrderCard = ({ order, onSelect }) => {
  const statusConfig = getStatusConfig(order.status);

  return (
    <div onClick={() => onSelect(order.id)} className="p-3 bg-gray-900 rounded-lg border border-gray-800 hover:border-red-600/50 cursor-pointer transition-all">
      <div className="flex justify-between items-start">
        <div className="min-w-0">
          <p className="font-semibold text-white text-sm truncate">{order.order_number || "SIN #ORDEN"}</p>
          <p className="text-xs text-gray-400 truncate">
            {order.customer_name || "—"} {order.customer_phone ? `• ${order.customer_phone}` : ""}
          </p>
        </div>
        <span className={`px-2 py-0.5 rounded-md border text-xs whitespace-nowrap ${statusConfig.colorClasses}`}>
          {statusConfig.label}
        </span>
      </div>
      <div className="mt-2 pt-2 border-t border-gray-800 flex justify-between items-center text-xs text-gray-500">
        <span className="truncate">{(order.device_brand || "") + " " + (order.device_model || "")}</span>
        <span className="whitespace-nowrap">
          {order.created_date ? format(new Date(order.created_date), "dd MMM, yyyy", { locale: es }) : "—"}
        </span>
      </div>
    </div>);

};

const SimplifiedCustomerCard = ({ customer, onSelect }) => {
  return (
    <div onClick={() => onSelect(customer.id)} className="p-3 bg-gray-900 rounded-lg border border-gray-800 hover:border-red-600/50 cursor-pointer transition-all">
      <div className="flex justify-between items-start">
        <div className="min-w-0">
          <p className="font-semibold text-white text-sm truncate">{customer.full_name || "Nombre desconocido"}</p>
          <p className="text-xs text-gray-400 truncate">
            {customer.phone ? `Tel: ${customer.phone}` : "—"}
            {customer.email ? ` • ${customer.email}` : ""}
          </p>
        </div>
        <ChevronRight className="w-4 h-4 text-gray-500" />
      </div>
      <div className="mt-2 pt-2 border-t border-gray-800 flex justify-between items-center text-xs text-gray-500">
        <span className="truncate">Creado: {customer.created_date ? format(new Date(customer.created_date), "dd MMM, yyyy", { locale: es }) : "—"}</span>
      </div>
    </div>
  );
};

function useAnnouncement(session) {
  const [note, setNote] = useState("");
  const [kvId, setKvId] = useState(null);
  const [updatedAt, setUpdatedAt] = useState(null);

  const load = useCallback(async () => {
    try {
      const list = await base44.entities.KeyValue.filter({ scope: "dashboard_note_single" });
      if (list?.length) {
        setKvId(list[0].id);
        const v = list[0].value_json || {};
        setNote(v.text || "");
        setUpdatedAt(v.updated_at || list[0].updated_date || list[0].created_date || null);
      } else {
        setKvId(null);
        const local = localStorage.getItem("dashboard_note_single") || "";
        setNote(local);
        setUpdatedAt(local ? new Date(0).toISOString() : null);
      }
    } catch {
      const local = localStorage.getItem("dashboard_note_single") || "";
      setNote(local);
      setUpdatedAt(local ? new Date(0).toISOString() : null);
    }
  }, []);

  const save = useCallback(async (text) => {
    const ts = new Date().toISOString();
    setNote(text);
    setUpdatedAt(ts);

    try {
      if (kvId) {
        await base44.entities.KeyValue.update(kvId, { value_json: { text, updated_at: ts } });
      } else {
        const rec = await base44.entities.KeyValue.create({
          scope: "dashboard_note_single",
          value_json: { text, updated_at: ts }
        });
        setKvId(rec.id);
      }

      let me = null;
      try {me = await base44.auth.me();} catch {}

      await base44.entities.AuditLog.create({
        action: "dashboard_note_update",
        entity_type: "config",
        entity_id: kvId || "new",
        user_id: me?.id || null,
        user_name: me?.full_name || me?.email || "Sistema",
        user_role: me?.role || "system",
        changes: { audience: "all", editor_id: me?.id || null }
      });
    } catch {
      localStorage.setItem("dashboard_note_single", text);
      localStorage.setItem("dashboard_note_single_updated_at", ts);
    }
  }, [kvId]);

  useEffect(() => {
    load();
  }, [load]);

  const canEdit = session?.userRole === "admin" || session?.userRole === "manager";

  return { note, setNote, save, canEdit, updatedAt };
}

/* ===================== CACHE HELPERS ===================== */
const CACHE_KEYS = {
  DASHBOARD_DATA: 'dashboard_data_cache',
  DASHBOARD_TS: 'dashboard_data_ts',
};

const CACHE_DURATION = 180 * 1000;

function getCachedData(key, timestampKey, maxAge) {
  try {
    const timestamp = localStorage.getItem(timestampKey);
    if (!timestamp) return null;

    const age = Date.now() - parseInt(timestamp, 10);
    if (age > maxAge) {
      localStorage.removeItem(key);
      localStorage.removeItem(timestampKey);
      return null;
    }

    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    console.warn('Error reading from cache:', e);
    localStorage.removeItem(key);
    localStorage.removeItem(timestampKey);
    return null;
  }
}

function setCachedData(key, timestampKey, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    localStorage.setItem(timestampKey, String(Date.now()));
  } catch (e) {
    console.warn('Cache storage failed:', e);
  }
}

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export default function Dashboard() {
  const navigate = useNavigate();
  const [session, setSession] = useState(() => readSessionSync());
  const [authChecked, setAuthChecked] = useState(false);
  const sessionRef = useRef(session);
  const [loading, setLoading] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [stats, setStats] = useState({ activeOrders: 0, activePunches: 0 });
  const [recentOrders, setRecentOrders] = useState([]);
  const [pendingOrders, setPendingOrders] = useState([]);
  const [recentCustomers, setRecentCustomers] = useState([]);
  const [priceListItems, setPriceListItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [customerSearchTerm, setCustomerSearchTerm] = useState("");
  const [priceSearch, setPriceSearch] = useState("");
  const [showWorkOrderWizard, setShowWorkOrderWizard] = useState(false);
  const [showOpenDrawer, setShowOpenDrawer] = useState(false);
  const lastFetchRef = useRef(0);

  const { note, setNote, save, canEdit, updatedAt } = useAnnouncement(session);
  const [isPunchedIn, setIsPunchedIn] = useState(false);
  const [toast, setToast] = useState(null);
  const showToast = (title, message = "", variant = "success") => {
    setToast({ title, message, variant });
    setTimeout(() => setToast(null), 2500);
  };

  const [featureFlags, setFeatureFlags] = useState({
    dashboard_note_send: true,
    deep_link_open_order: true,
    unified_status_registry: true
  });
  const [showSendNoteModal, setShowSendNoteModal] = useState(false);
  const [showNoteEditor, setShowNoteEditor] = useState(false);
  
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showOrderPanel, setShowOrderPanel] = useState(false);

  useEffect(() => {
    document.body.classList.add("dashboard-fullscreen");
    return () => {document.body.classList.remove("dashboard-fullscreen");};
  }, []);

  useEffect(() => {
    sessionRef.current = session;
    if (session) checkPunchStatus();
  }, [session]);

  const checkPunchStatus = async () => {
    const timeEntryId = sessionStorage.getItem("timeEntryId");
    if (timeEntryId) {
      setIsPunchedIn(true);
      return;
    }
    if (session?.userId) {
      try {
        const openEntries = await base44.entities.TimeEntry.filter({ employee_id: session.userId, clock_out: null });
        if (openEntries.length > 0) {
          sessionStorage.setItem("timeEntryId", openEntries[0].id);
          setIsPunchedIn(true);
        } else {
          setIsPunchedIn(false);
        }
      } catch (err) {
        console.warn("[Dashboard] Error checking punch status:", err);
        setIsPunchedIn(false);
      }
    }
  };

  const handlePunchToggle = async () => {
    if (!session?.userId) return;
    try {
      if (isPunchedIn) {
        const timeEntryId = sessionStorage.getItem("timeEntryId");
        if (timeEntryId) {
          await base44.entities.TimeEntry.update(timeEntryId, { clock_out: new Date().toISOString() });
          sessionStorage.removeItem("timeEntryId");
        } else {
          const openEntries = await base44.entities.TimeEntry.filter({ employee_id: session.userId, clock_out: null });
          if (openEntries?.length) {
            await base44.entities.TimeEntry.update(openEntries[0].id, { clock_out: new Date().toISOString() });
          }
        }
        setIsPunchedIn(false);
        showToast("Turno cerrado ✅", `Hasta luego, ${session.userName?.split(" ")[0] || ""}`);
      } else {
        const newEntry = await base44.entities.TimeEntry.create({
          employee_id: session.userId,
          employee_name: session.userName,
          clock_in: new Date().toISOString()
        });
        sessionStorage.setItem("timeEntryId", newEntry.id);
        setIsPunchedIn(true);
        showToast("¡Ponche registrado! ✅", `Bienvenido, ${session.userName?.split(" ")[0] || ""}`);
      }
      window.dispatchEvent(new Event("force-refresh"));
    } catch (e) {
      console.error("[Dashboard] Punch error:", e);
      showToast("Error al registrar ponche", "Intenta nuevamente.", "error");
    }
  };

  useEffect(() => {
    setAuthChecked(true);
    const tick = () => {
      const s = readSessionSync();
      setSession((prev) => {
        const prevStr = prev ? JSON.stringify(prev) : "";
        const nextStr = s ? JSON.stringify(s) : "";
        return prevStr !== nextStr ? s : prev;
      });
    };
    const iv = setInterval(tick, 5000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    const loadFlags = async () => {
      try {
        const rows = await base44.entities.SystemConfig.filter({ key: "feature_flags" });
        const raw = rows?.[0]?.value || rows?.[0]?.value_json;
        let flags = {
          dashboard_note_send: true,
          deep_link_open_order: true,
          unified_status_registry: true
        };
        if (typeof raw === "string") {
          try {flags = { ...flags, ...JSON.parse(raw) };} catch {}
        } else if (typeof raw === "object" && raw !== null) {
          flags = { ...flags, ...raw };
        }
        setFeatureFlags(flags);
      } catch (err) {
        console.warn("[Dashboard] Error loading feature flags:", err);
      }
    };
    loadFlags();
  }, []);

  const loadFreshData = useCallback(async () => {
    if (!sessionRef.current || !sessionRef.current.userId || !sessionRef.current.userName) return;

    const now = Date.now();
    const timeSinceLastFetch = now - lastFetchRef.current;
    if (timeSinceLastFetch < 60000 && lastFetchRef.current !== 0) {
      console.log('[Dashboard] Skipping fetch - too soon since last request');
      return;
    }
    lastFetchRef.current = now;

    setLoading(true);
    try {
      try {
        await base44.auth.me();
      } catch (e) {
        console.log("[Dashboard] Authentication error:", e.message || e);
        setLoading(false);
        return;
      }

      let orderFilter = {};
      if (sessionRef.current.userRole === "technician") {
        orderFilter.assigned_to = sessionRef.current.userId;
      }

      const orders = await base44.entities.Order.filter(orderFilter, "-updated_date", 15).catch(() => []);
      await delay(300);

      const timeEntries = await base44.entities.TimeEntry.filter({ clock_out: null }).catch(() => []);
      await delay(300);

      const products = await base44.entities.Product.filter({ active: true }, "-created_date", 30).catch(() => []);
      await delay(300);

      const services = await base44.entities.Service.filter({ active: true }, "-created_date", 30).catch(() => []);
      await delay(300);

      const customers = await base44.entities.Customer.filter({}, "-updated_date", 10).catch(() => []);
      await delay(300);

      const registers = await base44.entities.CashRegister.filter({ date: format(new Date(), "yyyy-MM-dd"), status: "open" }).catch(() => []);

      const activeOrders = orders.filter((o) => !["completed", "picked_up", "cancelled"].includes(o.status));
      const pendings = activeOrders.filter((o) => o.status === "pending_order");
      const prioritized = [...activeOrders].sort((a, b) => {
        const ap = a.status === "pending_order" ? 1 : 0;
        const bp = b.status === "pending_order" ? 1 : 0;
        return ap === bp ? 0 : bp - ap;
      });

      const recentOrdersData = prioritized.slice(0, 12);
      const statsData = { activeOrders: activeOrders.length, activePunches: timeEntries.length };
      const priceListData = [
        ...products.map((p) => ({ ...p, type: "product" })),
        ...services.map((s) => ({ ...s, type: "service" }))
      ];

      const drawerOpenState = registers.length > 0;

      setPendingOrders(pendings);
      setRecentOrders(recentOrdersData);
      setStats(statsData);
      setPriceListItems(priceListData);
      setDrawerOpen(drawerOpenState);
      setRecentCustomers(customers);

      setCachedData(CACHE_KEYS.DASHBOARD_DATA, CACHE_KEYS.DASHBOARD_TS, {
        recentOrders: recentOrdersData,
        pendingOrders: pendings,
        stats: statsData,
        priceListItems: priceListData,
        drawerOpen: drawerOpenState,
        recentCustomers: customers,
      });

      console.log('[Dashboard] ✅ Data loaded successfully');
    } catch (e) {
      console.error("[Dashboard] Load error:", e.message || e);
      
      if (e.message?.includes?.('Rate limit')) {
        lastFetchRef.current = Date.now() + 120000;
        showToast("Límite de peticiones alcanzado", "Esperando antes de reintentar...", "error");
      } else {
        showToast("Error de conexión", "No se pudieron cargar todos los datos", "error");
      }
    } finally {
      setLoading(false);
    }
  }, [sessionRef, showToast, lastFetchRef]);

  const loadInitialData = useCallback(async () => {
    if (!sessionRef.current || !sessionRef.current.userId || !sessionRef.current.userName) {
      setLoading(false);
      return;
    }

    const cached = getCachedData(CACHE_KEYS.DASHBOARD_DATA, CACHE_KEYS.DASHBOARD_TS, CACHE_DURATION);
    if (cached) {
      console.log('[Dashboard] Using cached data (valid for 3 minutes)');
      setRecentOrders(cached.recentOrders || []);
      setPendingOrders(cached.pendingOrders || []);
      setStats(cached.stats || { activeOrders: 0, activePunches: 0 });
      setPriceListItems(cached.priceListItems || []);
      setDrawerOpen(cached.drawerOpen || false);
      setRecentCustomers(cached.recentCustomers || []);
      setLoading(false);
      
      return;
    }

    await loadFreshData();
  }, [sessionRef, loadFreshData]);

  useEffect(() => {
    if (!session) {
      setLoading(false);
      return;
    }
    const timer = setTimeout(() => {loadInitialData();}, 100);
    
    const onForce = () => {
      console.log('[Dashboard] Manual refresh triggered');
      loadFreshData();
    };
    
    window.addEventListener("force-refresh", onForce);
    
    const iv = setInterval(() => {
      console.log('[Dashboard] Auto-refresh (every 3 minutes)');
      loadFreshData();
    }, 180000);
    
    return () => {
      clearTimeout(timer);
      clearInterval(iv);
      window.removeEventListener("force-refresh", onForce);
    };
  }, [session, loadInitialData, loadFreshData]);

  const handleNavigate = (path) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate(createPageUrl(path));
  };

  const handleOrderSelect = async (orderId) => {
    try {
      const order = await base44.entities.Order.get(orderId);
      setSelectedOrder(order);
      setShowOrderPanel(true);
    } catch (error) {
      console.error("Error loading order:", error);
      showToast("Error al cargar orden", "Intenta nuevamente", "error");
    }
  };

  const handleCustomerSelect = (customerId) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate(createPageUrl(`Customers?customer=${customerId}`));
  };

  const handleNavigateWithFilter = (statusId) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate(createPageUrl(`Orders?status=${statusId}`));
  };

  const handleLogout = () => {
    sessionStorage.clear();
    localStorage.removeItem("timeEntryId");
    setSession(null);
    navigate(createPageUrl("Dashboard"), { replace: true });
  };

  const filteredOrders = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    const base = recentOrders;
    if (!q) return base;
    const match = (v = "") => String(v).toLowerCase().includes(q);
    const filtered = base.filter((o) => match(o.order_number) || match(o.customer_name) || match(o.customer_phone) || match(o.customer_email) || match(o.device_model) || match(o.device_brand));
    return [...filtered].sort((a, b) => {
      const ap = a.status === "pending_order" ? 1 : 0;
      const bp = b.status === "pending_order" ? 1 : 0;
      return ap === bp ? 0 : bp - ap;
    });
  }, [recentOrders, searchTerm]);

  const filteredCustomers = useMemo(() => {
    const q = customerSearchTerm.trim().toLowerCase();
    const base = recentCustomers;
    if (!q) return base.slice(0, 5);
    const match = (v = "") => String(v).toLowerCase().includes(q);
    return base.filter((c) => match(c.full_name) || match(c.phone) || match(c.email));
  }, [recentCustomers, customerSearchTerm]);

  const filteredPriceList = useMemo(() => {
    const q = priceSearch.trim().toLowerCase();
    if (!q) return [];
    return priceListItems.filter((i) => {
      const name = i.name?.toLowerCase() || "";
      const sku = i.sku?.toLowerCase() || "";
      return name.includes(q) || sku.includes(q);
    }).slice(0, 50);
  }, [priceListItems, priceSearch]);

  const stockPill = (item) => {
    if (item.type !== "product" || typeof item.stock !== "number") return null;
    const cls = item.stock <= 0 ? "bg-red-600/20 text-red-300 border-red-600/30" : item.stock <= (item.min_stock || 0) ? "bg-yellow-600/20 text-yellow-300 border-yellow-600/30" : "bg-emerald-600/20 text-emerald-300 border-emerald-600/30";
    const lbl = item.stock <= 0 ? "Agotado" : item.stock <= (item.min_stock || 0) ? "Bajo stock" : "Disponible";
    return <span className={`px-2 py-0.5 rounded-md border text-xs ${cls}`}>{lbl}</span>;
  };

  useEffect(() => {
    if (!session || !updatedAt || !note) return;
    const isAdminOrManager = session.userRole === "admin" || session.userRole === "manager";
    if (isAdminOrManager) return;
    const key = `dashboard_note_seen_${session.userId || "anon"}`;
    const lastSeen = localStorage.getItem(key);
    if (lastSeen !== updatedAt) {
      showToast("Nueva nota del administrador", note);
      localStorage.setItem(key, updatedAt);
    }
  }, [session, updatedAt, note, showToast]);

  const handleSendNoteResult = (result) => {
    setShowSendNoteModal(false);
    if (result?.success) {
      showToast(
        "Nota enviada ✅",
        `Enviada a ${result.count} ${result.count === 1 ? "usuario" : "usuarios"}`,
        "success"
      );
    } else if (result?.error) {
      showToast("Error al enviar", result.error, "error");
    }
  };

  const statusCounts = useMemo(() => {
    const counts = {
      pending_order: 0,
      waiting_parts: 0,
      reparacion_externa: 0
    };
    
    if (!recentOrders || recentOrders.length === 0) return counts;
    
    ORDER_STATUSES.forEach((s) => {
      counts[s.id] = recentOrders.filter((o) => normalizeStatusId(o.status) === s.id).length;
    });
    return counts;
  }, [recentOrders]);

  const handleIMEILookup = () => {
    window.open("https://es.t-mobile.com/resources/bring-your-own-phone", "_blank", "noopener,noreferrer");
  };

  if (!authChecked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] text-white p-6 grid place-items-center">
        <div className="animate-pulse text-gray-400">Cargando…</div>
      </div>
    );
  }

  if (!session) return <PinAuthOverlayPro onAuthSuccess={(s) => setSession(s)} />;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0B0B0F] to-[#0A0A0D] text-slate-100">
      <style>{`
        body.dashboard-fullscreen nav[aria-orientation="vertical"], 
        body.dashboard-fullscreen .sidebar, 
        body.dashboard-fullscreen .left-nav, 
        body.dashboard-fullscreen [data-sidebar], 
        body.dashboard-fullscreen [aria-label="Sidebar"] { 
          display: none !important; 
        } 
        body.dashboard-fullscreen .with-sidebar, 
        body.dashboard-fullscreen .content, 
        body.dashboard-fullscreen main, 
        body.dashboard-fullscreen #root { 
          margin-left: 0 !important; 
          padding-left: 0 !important; 
        }
      `}</style>
      
      <Toast toast={toast} onClose={() => setToast(null)} />

      <main className="px-3 sm:px-4 md:px-6 py-4 sm:py-6">
        <div className="max-w-[1920px] mx-auto space-y-4 sm:space-y-6">
          {/* Header */}
          <div className="flex flex-col gap-3 sm:gap-0 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-gray-400 text-xs sm:text-sm">
              {format(new Date(), "EEEE, d 'de' MMMM", { locale: es })} — {session?.userName}
            </p>
            <div className="flex flex-wrap items-center gap-2">
              {(session.userRole === "admin" || session.userRole === "manager") && (
                <>
                  <Button 
                    onClick={() => handleNavigate("TimeTracking")} 
                    variant="outline" 
                    className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-full bg-zinc-900/60 border-white/15 text-slate-100 hover:bg-zinc-800 flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm"
                  >
                    <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden xs:inline">Ponches</span>
                  </Button>
                  <Button 
                    onClick={() => handleNavigate("Settings")} 
                    variant="outline" 
                    className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-full bg-zinc-900/60 border-white/15 text-slate-100 hover:bg-zinc-800 flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm"
                  >
                    <SettingsIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden xs:inline">Settings</span>
                  </Button>
                  
                  {note && (
                    <Button 
                      onClick={() => setShowNoteEditor(true)} 
                      variant="outline" 
                      className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-full bg-amber-900/60 border-amber-500/30 text-amber-100 hover:bg-amber-800 flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm"
                    >
                      <StickyNote className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                      <span className="hidden xs:inline">Nota</span>
                    </Button>
                  )}
                </>
              )}
              <Button 
                onClick={handlePunchToggle} 
                className={`h-9 sm:h-10 px-3 sm:px-4 rounded-full font-semibold text-xs sm:text-sm ${
                  isPunchedIn 
                    ? "bg-gradient-to-r from-rose-600 to-rose-800 hover:from-rose-500 hover:to-rose-700" 
                    : "bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700"
                }`}
              >
                {isPunchedIn ? "Cerrar ponche" : "Ponchar"}
              </Button>
              <Button 
                onClick={handleLogout} 
                variant="outline" 
                className="h-9 sm:h-10 px-3 sm:px-4 rounded-full bg-zinc-900/60 border-white/15 text-slate-100 hover:bg-zinc-800 text-xs sm:text-sm"
              >
                Cerrar sesión
              </Button>
            </div>
          </div>

          {/* ✅ Widgets Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            <SalesOverviewWidget />
            <InventoryAlertsWidget />
            <PendingRepairsWidget 
              statusCounts={statusCounts} 
              onNavigateWithFilter={handleNavigateWithFilter}
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              filteredOrders={filteredOrders}
              handleOrderSelect={handleOrderSelect}
            />
            <CustomerActivityWidget />
          </div>

          {/* Nota - THIS CARD IS REMOVED FROM HERE AND MOVED TO A MODAL */}
          {/* <Card className="bg-[#121212] border border-white/10">
            <CardHeader className="pb-2 px-4 sm:px-6 pt-4 sm:pt-6">
              <CardTitle className="text-slate-50 text-lg sm:text-xl font-semibold tracking-tight flex items-center gap-2">
                <StickyNote className="w-4 h-4 sm:w-5 sm:h-5 text-red-500" />
                Nota / Oferta de la semana
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 px-4 sm:px-6">
              {canEdit ? (
                <>
                  <textarea
                    rows={4}
                    className="bg-black/30 text-slate-50 p-3 text-xs sm:text-sm rounded-lg border border-white/10 w-full outline-none resize-none focus:ring-2 focus:ring-red-600"
                    placeholder="Escribe una nota u oferta para todo el equipo…"
                    value={note}
                    onChange={(e) => setNote(e.target.value)} 
                  />
                  <div className="flex flex-wrap gap-2">
                    <Button
                      onClick={() => save(note)}
                      className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-xs sm:text-sm h-9 sm:h-10"
                    >
                      Guardar
                    </Button>
                    {featureFlags.dashboard_note_send && (
                      <Button
                        onClick={() => setShowSendNoteModal(true)}
                        variant="outline" 
                        className="border-white/15 hover:bg-white/10 text-xs sm:text-sm h-9 sm:h-10"
                      >
                        📨 Enviar a Usuario
                      </Button>
                    )}
                  </div>
                  <p className="text-[10px] sm:text-xs text-gray-500">
                    💡 <strong>Guardar:</strong> nota visible para todos en el dashboard.
                    {featureFlags.dashboard_note_send && " • "}
                    {featureFlags.dashboard_note_send && <strong>Enviar:</strong>}
                    {featureFlags.dashboard_note_send && " notificación directa a usuarios específicos."}
                  </p>
                </>
              ) : (
                <div className="bg-black/30 border border-white/10 rounded-lg p-3 text-xs sm:text-sm text-gray-200 min-h-[72px]">
                  {note || "—"}
                </div>
              )}
            </CardContent>
          </Card> */}

          {/* ✅ KPIs - Nueva Orden, Abrir Caja, Lista de Precios + Botón IMEI */}
          <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            <Card className="bg-gradient-to-br from-red-600 to-red-800 border-red-500/30 cursor-pointer hover:shadow-lg hover:shadow-red-500/20" onClick={() => setShowWorkOrderWizard(true)}>
              <CardContent className="p-4 sm:p-6 flex flex-col items-center justify-center text-center space-y-2 sm:space-y-3 h-full">
                <ClipboardList className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                <div>
                  <h3 className="text-lg sm:text-xl font-bold">Nueva Orden</h3>
                  <p className="text-xs sm:text-sm text-red-100">Crear un nuevo ticket</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-600 to-emerald-800 border-green-500/30 cursor-pointer" onClick={() => drawerOpen ? handleNavigate("Financial") : setShowOpenDrawer(true)}>
              <CardContent className="p-4 sm:p-6 flex flex-col items-center justify-center text-center space-y-2 sm:space-y-3">
                <Wallet className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                <div>
                  <h3 className="text-lg sm:text-xl font-bold">{drawerOpen ? "Gestionar Caja" : "Abrir Caja"}</h3>
                  <p className="text-xs sm:text-sm text-green-100">{drawerOpen ? "Caja abierta" : "Caja cerrada"}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#121212] border border-white/10 lg:col-span-1">
              <CardHeader className="pb-2 px-4 sm:px-6 pt-4 sm:pt-6">
                <CardTitle className="flex flex-col sm:flex-row items-start sm:items-center justify-between w-full gap-3">
                  <span className="text-slate-50 flex items-center gap-2 text-base sm:text-lg">
                    {priceSearch.trim() ? "Resultados" : "Buscar en Lista de Precios"}
                  </span>
                  <div className="relative w-full sm:w-auto sm:max-w-xs">
                    <input 
                      type="text" 
                      placeholder="Buscar producto/servicio…" 
                      value={priceSearch} 
                      onChange={(e) => setPriceSearch(e.target.value)} 
                      className="w-full h-9 sm:h-10 px-3 rounded-md bg-black/30 border border-white/10 text-slate-100 text-xs sm:text-sm focus:ring-2 focus:ring-red-600 focus:outline-none" 
                    />
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 sm:px-6 space-y-3">
                {priceSearch.trim() ? (
                  <div className="max-h-72 overflow-y-auto pr-1 space-y-2">
                    {filteredPriceList.length ? (
                      filteredPriceList.map((it) => (
                        <div key={`${it.type}-${it.id}`} className="rounded-lg border border-white/10 bg-black/30 p-3 flex items-center justify-between">
                          <div className="min-w-0">
                            <p className="text-slate-50 text-xs sm:text-sm font-medium truncate">{it.name}</p>
                            <div className="text-[10px] sm:text-xs text-gray-400 flex items-center gap-2">
                              <span className="capitalize">{it.type}</span>
                              {it.sku && <span className="text-gray-500">• {it.sku}</span>}
                              {stockPill(it)}
                            </div>
                          </div>
                          <span className="font-semibold text-green-400 text-sm sm:text-base">
                            ${Number(it.price || 0).toFixed(2)}
                          </span>
                        </div>
                      ))
                    ) : (
                      <p className="text-[10px] sm:text-xs text-gray-500 text-center py-4">Sin resultados.</p>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8 text-xs sm:text-sm">
                    💡 Escribe algo para buscar productos o servicios...
                  </p>
                )}
                
                <Button
                  onClick={handleIMEILookup}
                  variant="outline"
                  className="w-full border-white/15 hover:bg-white/10 text-slate-100 flex items-center justify-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" />
                  Identificar equipo (IMEI)
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Clientes - Responsive */}
          <Card className="bg-[#121212] border border-white/10">
            <CardHeader className="space-y-3 px-4 sm:px-6 pt-4 sm:pt-6">
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="text-slate-50 text-base sm:text-lg font-bold tracking-tight flex items-center gap-2">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5 text-red-500" />
                  {customerSearchTerm.trim() ? "Resultados de búsqueda (Clientes)" : "Clientes Recientes"}
                </CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => handleNavigate("Customers")} 
                  className="text-slate-50 px-2 sm:px-3 text-xs sm:text-sm rounded-md inline-flex items-center gap-1 sm:gap-2 hover:bg-white/5"
                >
                  Ver todos <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4 sm:w-5 sm:h-5 pointer-events-none" />
                <input 
                  type="text" 
                  placeholder="Buscar por nombre, teléfono o email…" 
                  value={customerSearchTerm} 
                  onChange={(e) => setCustomerSearchTerm(e.target.value)} 
                  className="w-full h-10 sm:h-11 px-4 pl-9 sm:pl-10 rounded-lg bg-black/40 border border-white/15 text-slate-100 text-xs sm:text-sm focus:ring-2 focus:ring-red-600 focus:outline-none transition-all" 
                />
              </div>
            </CardHeader>
            <CardContent className="px-4 sm:px-6">
              {customerSearchTerm.trim() || filteredCustomers.length > 0 ? (
                filteredCustomers.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {filteredCustomers.map((c) => (
                      <SimplifiedCustomerCard key={c.id} customer={c} onSelect={handleCustomerSelect} />
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8 text-xs sm:text-sm">
                    Sin coincidencias para tu búsqueda.
                  </p>
                )
              ) : (
                <p className="text-gray-500 text-center py-8 text-xs sm:text-sm">
                  💡 Escribe algo para buscar clientes...
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {showWorkOrderWizard && (
        <WorkOrderWizard 
          open={showWorkOrderWizard} 
          onClose={() => setShowWorkOrderWizard(false)} 
          onSuccess={() => {
            loadFreshData();
            window.dispatchEvent(new Event("force-refresh"));
          }} 
        />
      )}
      {showOpenDrawer && (
        <OpenDrawerDialog 
          open={showOpenDrawer} 
          onClose={() => setShowOpenDrawer(false)} 
          onSuccess={() => {
            loadFreshData();
            window.dispatchEvent(new Event("force-refresh"));
          }} 
        />
      )}

      {showSendNoteModal && (
        <SendNoteModal
          open={showSendNoteModal}
          onClose={handleSendNoteResult}
          initialText={note}
        />
      )}
      
      {showNoteEditor && canEdit && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <Card className="bg-[#121212] border border-white/10 max-w-2xl w-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-slate-50 text-xl font-semibold tracking-tight flex items-center gap-2">
                <StickyNote className="w-5 h-5 text-red-500" />
                Nota / Oferta de la semana
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <textarea
                rows={4}
                className="bg-black/30 text-slate-50 p-3 text-sm rounded-lg border border-white/10 w-full outline-none resize-none focus:ring-2 focus:ring-red-600"
                placeholder="Escribe una nota u oferta para todo el equipo…"
                value={note}
                onChange={(e) => setNote(e.target.value)} 
              />
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() => {
                    save(note);
                    setShowNoteEditor(false);
                  }}
                  className="bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700"
                >
                  Guardar
                </Button>
                {featureFlags.dashboard_note_send && (
                  <Button
                    onClick={() => {
                      setShowNoteEditor(false); // Close editor before opening send modal
                      setShowSendNoteModal(true);
                    }}
                    variant="outline" 
                    className="border-white/15 hover:bg-white/10"
                  >
                    📨 Enviar a Usuario
                  </Button>
                )}
                <Button
                  onClick={() => setShowNoteEditor(false)}
                  variant="outline"
                  className="border-white/15 hover:bg-white/10"
                >
                  Cerrar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {showOrderPanel && selectedOrder && (
        <WorkOrderPanel
          order={selectedOrder}
          onClose={() => {
            setShowOrderPanel(false);
            setSelectedOrder(null);
            loadFreshData();
          }}
          onUpdate={() => {
            loadFreshData();
          }}
        />
      )}
    </div>
  );
}
