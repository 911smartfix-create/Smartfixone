
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Users, Shield, Plus, Edit, Search } from "lucide-react";
import { can, clearPermissionsCache } from "@/components/utils/permissions";

export default function UsersManagement() {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [canManage, setCanManage] = useState(false);
  
  const [showUserDialog, setShowUserDialog] = useState(false);
  const [showRoleDialog, setShowRoleDialog] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [editingRole, setEditingRole] = useState(null);

  useEffect(() => {
    checkPermissions();
    loadData();
  }, []);

  const checkPermissions = async () => {
    try {
      const hasPermission = await can("users.manage");
      setCanManage(hasPermission);
      if (!hasPermission) {
        alert("No tienes permisos para acceder a esta sección");
      }
    } catch (e) {
      console.error("Error checking permissions:", e);
      setCanManage(true); // Fallback: permitir acceso
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [usersData, rolesData, permsData] = await Promise.all([
        base44.entities.User.list(),
        base44.entities.Role.list(),
        base44.entities.Permission.list()
      ]);
      
      setUsers(usersData || []);
      setRoles(rolesData || []);
      setPermissions(permsData || []);
    } catch (e) {
      console.error("Error loading data:", e);
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = users.filter(u =>
    (u.full_name || "").toLowerCase().includes(search.toLowerCase()) ||
    (u.email || "").toLowerCase().includes(search.toLowerCase())
  );

  const getUserRoles = async (userId) => {
    try {
      const userRoles = await base44.entities.UserRole.filter({ user_id: userId });
      const roleIds = userRoles.map(ur => ur.role_id);
      return roles.filter(r => roleIds.includes(r.id));
    } catch {
      return [];
    }
  };

  const handleSaveUser = async (userData) => {
    try {
      let me = null;
      try { me = await base44.auth.me(); } catch {}

      if (editingUser) {
        // Actualizar usuario existente
        await base44.entities.User.update(editingUser.id, userData);
        
        await base44.entities.AuditLog.create({
          action: "user_update",
          entity_type: "user",
          entity_id: editingUser.id,
          user_id: me?.id || null,
          user_name: me?.full_name || me?.email || "Sistema",
          user_role: me?.role || "system",
          changes: userData
        });
      } else {
        // NUEVO: No crear usuario directamente, mostrar mensaje
        alert("Para añadir nuevos usuarios, usa la función 'Invitar Usuario' desde el dashboard de base44.\n\nLos usuarios no pueden ser creados directamente desde la app por seguridad.");
        setShowUserDialog(false);
        return;
      }

      clearPermissionsCache();
      loadData();
      setShowUserDialog(false);
      setEditingUser(null);
    } catch (e) {
      console.error("Error saving user:", e);
      alert("Error al guardar usuario: " + (e.message || "Error desconocido"));
    }
  };

  const handleAssignRole = async (userId, roleId, assign = true) => {
    try {
      let me = null;
      try { me = await base44.auth.me(); } catch {}

      if (assign) {
        await base44.entities.UserRole.create({
          user_id: userId,
          role_id: roleId,
          assigned_by: me?.id || null,
          assigned_at: new Date().toISOString()
        });
        
        await base44.entities.AuditLog.create({
          action: "role_assign",
          entity_type: "user",
          entity_id: userId,
          user_id: me?.id || null,
          user_name: me?.full_name || me?.email || "Sistema",
          changes: { role_id: roleId, action: "assign" }
        });
      } else {
        const userRoles = await base44.entities.UserRole.filter({ user_id: userId, role_id: roleId });
        if (userRoles.length > 0) {
          await base44.entities.UserRole.delete(userRoles[0].id);
          
          await base44.entities.AuditLog.create({
            action: "role_revoke",
            entity_type: "user",
            entity_id: userId,
            user_id: me?.id || null,
            user_name: me?.full_name || me?.email || "Sistema",
            changes: { role_id: roleId, action: "revoke" }
          });
        }
      }

      clearPermissionsCache();
      loadData();
    } catch (e) {
      console.error("Error assigning role:", e);
      alert("Error al asignar rol");
    }
  };

  if (!canManage) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] p-6 grid place-items-center">
        <div className="text-center text-white">
          <Shield className="w-16 h-16 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold mb-2">Acceso Denegado</h2>
          <p className="text-gray-400">No tienes permisos para acceder a esta sección</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Users className="w-8 h-8 text-red-500" />
              Usuarios y Roles
            </h1>
            <p className="text-gray-400 mt-1">Gestión de usuarios, roles y permisos</p>
          </div>
          {/* Botón deshabilitado con tooltip */}
          <div className="relative group">
            <Button
              disabled
              className="bg-red-600/50 cursor-not-allowed"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Usuario
            </Button>
            <div className="absolute right-0 top-full mt-2 w-64 p-3 bg-gray-900 border border-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 text-white">
              <p className="text-xs text-gray-300">
                Para añadir usuarios, usa la función "Invitar Usuario" desde el dashboard de base44.
              </p>
            </div>
          </div>
        </div>

        {/* Búsqueda */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Buscar por nombre o email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-black border-white/15 text-white"
          />
        </div>

        {/* Lista de usuarios */}
        <Card className="bg-[#121212] border-white/10">
          <CardHeader>
            <CardTitle className="text-white">Usuarios ({filteredUsers.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-gray-400">Cargando...</div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-8 text-gray-400">No se encontraron usuarios</div>
            ) : (
              <div className="space-y-2">
                {filteredUsers.map(user => (
                  <UserCard
                    key={user.id}
                    user={user}
                    roles={roles}
                    onEdit={() => {
                      setEditingUser(user);
                      setShowUserDialog(true);
                    }}
                    onAssignRole={handleAssignRole}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Lista de roles */}
        <Card className="bg-[#121212] border-white/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Roles del Sistema</CardTitle>
              <Button
                size="sm"
                onClick={() => setShowRoleDialog(true)}
                className="bg-red-600 hover:bg-red-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Rol
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {roles.map(role => (
                <RoleCard
                  key={role.id}
                  role={role}
                  permissions={permissions}
                  onEdit={() => {
                    setEditingRole(role);
                    setShowRoleDialog(true);
                  }}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dialogs */}
      <UserDialog
        open={showUserDialog}
        user={editingUser}
        roles={roles}
        onClose={() => {
          setShowUserDialog(false);
          setEditingUser(null);
        }}
        onSave={handleSaveUser}
      />

      <RoleDialog
        open={showRoleDialog}
        role={editingRole}
        permissions={permissions}
        onClose={() => {
          setShowRoleDialog(false);
          setEditingRole(null);
        }}
        onSave={async (roleData) => {
          try {
            if (editingRole) {
              await base44.entities.Role.update(editingRole.id, roleData);
            } else {
              await base44.entities.Role.create(roleData);
            }
            loadData();
            setShowRoleDialog(false);
            setEditingRole(null);
          } catch (e) {
            alert("Error al guardar rol");
          }
        }}
      />
    </div>
  );
}

function UserCard({ user, roles, onEdit, onAssignRole }) {
  const [userRoles, setUserRoles] = useState([]);
  const [showRoles, setShowRoles] = useState(false);

  useEffect(() => {
    loadUserRoles();
  }, [user.id]);

  const loadUserRoles = async () => {
    try {
      const userRolesData = await base44.entities.UserRole.filter({ user_id: user.id });
      const roleIds = userRolesData.map(ur => ur.role_id);
      const userRolesList = roles.filter(r => roleIds.includes(r.id));
      setUserRoles(userRolesList);
    } catch {}
  };

  return (
    <div className="p-4 bg-black/30 rounded-lg border border-white/10">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-white">{user.full_name || user.email}</h3>
            {!user.active && (
              <Badge className="bg-gray-600/20 text-gray-300">Inactivo</Badge>
            )}
          </div>
          <p className="text-sm text-gray-400 mt-1">{user.email}</p>
          <div className="flex flex-wrap gap-1 mt-2">
            {userRoles.map(role => (
              <Badge key={role.id} className="bg-red-600/20 text-red-300 border-red-600/30">
                {role.name}
              </Badge>
            ))}
            {userRoles.length === 0 && (
              <span className="text-xs text-gray-500">Sin roles asignados</span>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowRoles(!showRoles)}
            className="border-white/15 text-white"
          >
            <Shield className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={onEdit}
            className="border-white/15 text-white"
          >
            <Edit className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {showRoles && (
        <div className="mt-3 pt-3 border-t border-white/10 space-y-2">
          <Label className="text-sm text-gray-300">Asignar roles:</Label>
          {roles.map(role => {
            const hasRole = userRoles.some(ur => ur.id === role.id);
            return (
              <div key={role.id} className="flex items-center justify-between p-2 bg-black/20 rounded">
                <span className="text-sm text-white">{role.name}</span>
                <input
                  type="checkbox"
                  checked={hasRole}
                  onChange={(e) => onAssignRole(user.id, role.id, e.target.checked)}
                  className="w-4 h-4 accent-red-600"
                />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function RoleCard({ role, permissions, onEdit }) {
  const [rolePerms, setRolePerms] = useState([]);

  useEffect(() => {
    loadRolePermissions();
  }, [role.id]);

  const loadRolePermissions = async () => {
    try {
      const rp = await base44.entities.RolePermission.filter({ role_id: role.id });
      setRolePerms(rp);
    } catch {}
  };

  return (
    <div className="p-4 bg-black/30 rounded-lg border border-white/10">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-white">{role.name}</h3>
            {role.is_system && (
              <Badge className="bg-blue-600/20 text-blue-300 border-blue-600/30">Sistema</Badge>
            )}
          </div>
          <p className="text-sm text-gray-400 mt-1">{role.description || "Sin descripción"}</p>
          <div className="mt-2 text-xs text-gray-500">
            {rolePerms.length} {rolePerms.length === 1 ? "permiso" : "permisos"}
          </div>
        </div>
        {!role.is_system && (
          <Button
            size="sm"
            variant="outline"
            onClick={onEdit}
            className="border-white/15 text-white"
          >
            <Edit className="w-4 h-4" />
          </Button>
        )}
      </div>
    </div>
  );
}

function UserDialog({ open, user, roles, onClose, onSave }) {
  const [formData, setFormData] = useState({
    full_name: "",
    active: true
  });

  useEffect(() => {
    if (user) {
      setFormData({
        full_name: user.full_name || "",
        active: user.active !== false
      });
    } else {
      setFormData({
        full_name: "",
        active: true
      });
    }
  }, [user, open]);

  const handleSubmit = () => {
    if (!user) {
      alert("No se pueden crear usuarios nuevos desde aquí. Usa 'Invitar Usuario' desde el dashboard de base44.");
      onClose();
      return;
    }
    
    if (!formData.full_name) {
      alert("El nombre es requerido");
      return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white">
        <DialogHeader>
          <DialogTitle>{user ? "Editar Usuario" : "Nuevo Usuario"}</DialogTitle>
        </DialogHeader>
        
        {!user && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 mb-4">
            <p className="text-amber-200 text-sm">
              ⚠️ Los usuarios deben ser invitados desde el dashboard de base44 por seguridad.
              Este diálogo solo permite editar usuarios existentes.
            </p>
          </div>
        )}
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Nombre completo</Label>
            <Input
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              className="bg-black border-gray-700 text-white"
              disabled={!user}
            />
          </div>
          
          {user && (
            <>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={user.email}
                  disabled
                  className="bg-black/50 border-gray-700 text-gray-500 cursor-not-allowed"
                />
                <p className="text-xs text-gray-500">El email no se puede cambiar</p>
              </div>
              
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.active}
                  onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                  className="w-4 h-4 accent-red-600"
                />
                <Label>Usuario activo</Label>
              </div>
            </>
          )}
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="border-gray-700">
            Cancelar
          </Button>
          {user && (
            <Button onClick={handleSubmit} className="bg-red-600 hover:bg-red-700">
              Guardar
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function RoleDialog({ open, role, permissions, onClose, onSave }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    active: true,
    selectedPermissions: []
  });

  useEffect(() => {
    const load = async () => {
      if (role) {
        const rp = await base44.entities.RolePermission.filter({ role_id: role.id });
        setFormData({
          name: role.name || "",
          description: role.description || "",
          active: role.active !== false,
          selectedPermissions: rp.map(p => p.permission_code)
        });
      } else {
        setFormData({
          name: "",
          description: "",
          active: true,
          selectedPermissions: []
        });
      }
    };
    if (open) load();
  }, [role, open]);

  const handleSubmit = async () => {
    if (!formData.name) {
      alert("El nombre es requerido");
      return;
    }
    
    const roleData = {
      name: formData.name,
      description: formData.description,
      active: formData.active
    };
    
    await onSave(roleData);
    
    // Guardar permisos si es edición
    if (role) {
      // Eliminar permisos anteriores
      const oldPerms = await base44.entities.RolePermission.filter({ role_id: role.id });
      for (const perm of oldPerms) {
        await base44.entities.RolePermission.delete(perm.id);
      }
      
      // Crear nuevos
      for (const permCode of formData.selectedPermissions) {
        await base44.entities.RolePermission.create({
          role_id: role.id,
          permission_code: permCode
        });
      }
    }
  };

  const togglePermission = (permCode) => {
    setFormData(prev => ({
      ...prev,
      selectedPermissions: prev.selectedPermissions.includes(permCode)
        ? prev.selectedPermissions.filter(p => p !== permCode)
        : [...prev.selectedPermissions, permCode]
    }));
  };

  const permsByCategory = permissions.reduce((acc, perm) => {
    const cat = perm.category || "other";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(perm);
    return acc;
  }, {});

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{role ? "Editar Rol" : "Nuevo Rol"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Nombre</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-black border-gray-700 text-white"
            />
          </div>
          <div className="space-y-2">
            <Label>Descripción</Label>
            <Input
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="bg-black border-gray-700 text-white"
            />
          </div>

          <div className="space-y-3">
            <Label>Permisos</Label>
            {Object.entries(permsByCategory).map(([category, perms]) => (
              <div key={category} className="space-y-2">
                <h4 className="text-sm font-semibold text-gray-300 capitalize">{category}</h4>
                {perms.map(perm => (
                  <div key={perm.code} className="flex items-center gap-2 p-2 bg-black/20 rounded">
                    <input
                      type="checkbox"
                      checked={formData.selectedPermissions.includes(perm.code)}
                      onChange={() => togglePermission(perm.code)}
                      className="w-4 h-4 accent-red-600"
                    />
                    <div className="flex-1">
                      <div className="text-sm text-white">{perm.code}</div>
                      <div className="text-xs text-gray-400">{perm.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="border-gray-700">
            Cancelar
          </Button>
          <Button onClick={handleSubmit} className="bg-red-600 hover:bg-red-700">
            Guardar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
