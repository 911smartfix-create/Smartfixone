// === Inventory.jsx — 911 SmartFix — REDISEÑO INVENTARIO ===
// 👈 versión enfocada en: Productos / Piezas-Accesorios / Servicios
// 👈 incluye: costo, precio, stock, stock mínimo, suplidor, categorías, modelos compatibles
// 👈 incluye: módulo sencillo de Órdenes de Compra con attach de PDF
// 👈 NO toca nada fuera de este archivo

import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Plus,
  Package,
  Wrench,
  HandPlatter,
  AlertTriangle,
  FileText,
  Upload,
  Trash2,
  Edit,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// 👇 helpers
const money = (n) => `$${Number(n || 0).toFixed(2)}`;
const stockState = (item) => {
  // productos y piezas/accesorios comparten lógica de stock
  if (item.kind === "service") {
    return { tag: "Servicio", color: "text-gray-400" };
  }
  const st = Number(item.stock || 0);
  const min = Number(item.min_stock || 0);
  if (st <= 0) return { tag: "Agotado", color: "text-red-400" };
  if (st <= min) return { tag: "Bajo", color: "text-amber-400" };
  return { tag: "OK", color: "text-emerald-400" };
};

// === Tarjeta de inventario ===
function InventoryCard({ item, onEdit, onDelete }) {
  const st = stockState(item);
  const Icon =
    item.kind === "product"
      ? Package
      : item.kind === "part"
      ? Wrench
      : HandPlatter;

  return (
    <div className="bg-[#111]/70 border border-white/10 rounded-2xl p-4 flex flex-col gap-3 hover:border-red-500/40 transition">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2">
          <div className="w-9 h-9 rounded-full bg-white/5 grid place-items-center">
            <Icon
              className={
                item.kind === "service"
                  ? "w-5 h-5 text-purple-300"
                  : "w-5 h-5 text-red-300"
              }
            />
          </div>
          <div>
            <p className="font-semibold text-white leading-tight">
              {item.name || "—"}
            </p>
            <p className="text-[11px] text-white/40">
              {item.category || (item.kind === "part"
                ? "Pieza / Accesorio"
                : item.kind === "product"
                ? "Producto"
                : "Servicio")}
            </p>
          </div>
        </div>
        <div className="flex gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={() => onEdit(item)}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-red-300 hover:text-red-200"
            onClick={() => onDelete(item)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* precios */}
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-lg font-bold text-emerald-300">
            {money(item.price)}
          </p>
          <p className="text-xs text-white/30">
            Costo {money(item.cost)}{" "}
            {item.kind !== "service" ? "· c/u" : ""}
          </p>
          {item.supplier_name && (
            <p className="text-[11px] text-white/25">
              Suplidor: {item.supplier_name}
            </p>
          )}
        </div>

        {/* stock */}
        {item.kind !== "service" ? (
          <div className="text-right">
            <p className={`text-lg font-semibold ${st.color}`}>
              {Number(item.stock || 0)}
            </p>
            <p className="text-[10px] text-white/30">{st.tag}</p>
          </div>
        ) : (
          <Badge className="bg-purple-500/20 text-purple-100 border-purple-500/30 text-[10px]">
            Servicio
          </Badge>
        )}
      </div>

      {/* compatibilidad / descripción corta */}
      {(item.compatibility_models?.length || item.description) && (
        <p className="text-[11px] text-white/35 line-clamp-2">
          {item.description ||
            item.compatibility_models?.join(", ")}
        </p>
      )}

      {/* alerta de bajo stock */}
      {item.kind !== "service" &&
        Number(item.stock || 0) > 0 &&
        Number(item.stock || 0) <= Number(item.min_stock || 0) && (
          <div className="flex items-center gap-2 text-[11px] text-amber-200 bg-amber-500/10 border border-amber-400/30 px-2 py-1 rounded-md">
            <AlertTriangle className="w-3.5 h-3.5" />
            Bajo stock
          </div>
        )}
    </div>
  );
}

// === Modal para crear/editar item ===
function InventoryItemDialog({ open, onOpenChange, value, onSave }) {
  const [form, setForm] = useState(
    value || {
      kind: "product", // product | part | service  // 👈
      name: "",
      price: 0,
      cost: 0,
      stock: 0,
      min_stock: 0,
      category: "",
      supplier_name: "",
      description: "",
      compatibility_models_text: "",
    }
  );

  useEffect(() => {
    if (value) {
      setForm({
        ...value,
        compatibility_models_text: Array.isArray(value.compatibility_models)
          ? value.compatibility_models.join("\n")
          : "",
      });
    }
  }, [value]);

  const handleSave = async () => {
    const payload = {
      ...form,
      price: Number(form.price || 0),
      cost: Number(form.cost || 0),
      category: form.category || "",
      supplier_name: form.supplier_name || "",
      description: form.description || "",
    };

    // 👇 solo productos y piezas llevan stock
    if (form.kind === "product" || form.kind === "part") {
      payload.stock = Number(form.stock || 0);
      payload.min_stock = Number(form.min_stock || 0);
    } else {
      delete payload.stock;
      delete payload.min_stock;
    }

    // 👇 compatibilidad
    payload.compatibility_models = (form.compatibility_models_text || "")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);

    await onSave?.(payload);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0f0f10] border border-white/10 max-w-2xl text-white">
        <DialogHeader>
          <DialogTitle>
            {value?.id ? "Editar artículo" : "Nuevo artículo"}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 py-2">
          {/* tipo */}
          <div className="md:col-span-2">
            <p className="text-xs text-white/35 mb-1">Tipo de artículo</p>
            <div className="flex gap-2">
              {[
                { id: "product", label: "Producto" },
                { id: "part", label: "Pieza / Accesorio" },
                { id: "service", label: "Servicio" },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setForm((f) => ({ ...f, kind: opt.id }))}
                  className={`px-3 h-9 rounded-full border text-sm ${
                    form.kind === opt.id
                      ? "bg-red-600 text-white border-red-600"
                      : "bg-white/5 border-white/10 text-white/60 hover:bg-white/10"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <Input
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            placeholder="Nombre del artículo"
            className="bg-black/20 border-white/10"
          />

          <Input
            value={form.category}
            onChange={(e) =>
              setForm((f) => ({ ...f, category: e.target.value }))
            }
            placeholder="Categoría (ej. iPhone, Mac, Consola…)"
            className="bg-black/20 border-white/10"
          />

          <Input
            type="number"
            value={form.price}
            onChange={(e) =>
              setForm((f) => ({ ...f, price: e.target.value }))
            }
            placeholder="Precio de venta"
            className="bg-black/20 border-white/10"
          />

          <Input
            type="number"
            value={form.cost}
            onChange={(e) => setForm((f) => ({ ...f, cost: e.target.value }))}
            placeholder="Costo"
            className="bg-black/20 border-white/10"
          />

          {(form.kind === "product" || form.kind === "part") && (
            <>
              <Input
                type="number"
                value={form.stock}
                onChange={(e) =>
                  setForm((f) => ({ ...f, stock: e.target.value }))
                }
                placeholder="Cantidad en stock"
                className="bg-black/20 border-white/10"
              />
              <Input
                type="number"
                value={form.min_stock}
                onChange={(e) =>
                  setForm((f) => ({ ...f, min_stock: e.target.value }))
                }
                placeholder="Avisar cuando baje a…"
                className="bg-black/20 border-white/10"
              />
            </>
          )}

          <Input
            value={form.supplier_name}
            onChange={(e) =>
              setForm((f) => ({ ...f, supplier_name: e.target.value }))
            }
            placeholder="Suplidor (opcional)"
            className="bg-black/20 border-white/10 md:col-span-2"
          />

          <Textarea
            value={form.description}
            onChange={(e) =>
              setForm((f) => ({ ...f, description: e.target.value }))
            }
            placeholder="Descripción / notas internas"
            className="bg-black/20 border-white/10 md:col-span-2"
          />

          <Textarea
            value={form.compatibility_models_text}
            onChange={(e) =>
              setForm((f) => ({
                ...f,
                compatibility_models_text: e.target.value,
              }))
            }
            placeholder="Modelos compatibles (uno por línea)"
            className="bg-black/20 border-white/10 md:col-span-2 h-20"
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} className="bg-red-600 hover:bg-red-700">
            Guardar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// === Modal de Órdenes de Compra (simple) ===
function PurchaseOrdersDialog({ open, onOpenChange, orders = [], onUpload }) {
  const [selectedPO, setSelectedPO] = useState(null);
  const [file, setFile] = useState(null);

  const handleAttach = async () => {
    if (!selectedPO || !file) return;
    await onUpload?.(selectedPO, file);
    setFile(null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0f0f10] border border-white/10 max-w-3xl text-white">
        <DialogHeader>
          <DialogTitle>Órdenes de compra</DialogTitle>
        </DialogHeader>

        <div className="space-y-3 max-h-[55vh] overflow-y-auto">
          {orders.length === 0 ? (
            <p className="text-white/40 text-sm">
              Aún no hay órdenes de compra.
            </p>
          ) : (
            orders.map((po) => (
              <div
                key={po.id}
                className={`flex items-center justify-between gap-3 rounded-lg border px-3 py-2 cursor-pointer ${
                  selectedPO === po.id
                    ? "border-red-500/60 bg-red-500/5"
                    : "border-white/10 hover:border-white/30"
                }`}
                onClick={() => setSelectedPO(po.id)}
              >
                <div>
                  <p className="text-sm font-medium">{po.po_number}</p>
                  <p className="text-[11px] text-white/30">
                    {po.supplier_name || "Suplidor no definido"}
                  </p>
                </div>
                <Badge className="bg-white/5 text-white/60 border-white/10">
                  {po.status || "borrador"}
                </Badge>
              </div>
            ))
          )}
        </div>

        <div className="mt-4 border-t border-white/10 pt-3 space-y-2">
          <p className="text-xs text-white/40">
            Adjuntar PDF de esta orden de compra
          </p>
          <Input
            type="file"
            accept="application/pdf"
            className="bg-black/20 border-white/10"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
          />
          <Button
            disabled={!selectedPO || !file}
            onClick={handleAttach}
            className="bg-red-600 hover:bg-red-700"
          >
            <Upload className="w-4 h-4 mr-2" />
            Subir PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// === Componente principal ===
export default function Inventory() {
  const [items, setItems] = useState([]);
  const [poList, setPoList] = useState([]);
  const [tab, setTab] = useState("all"); // all | product | part | service
  const [q, setQ] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState(null);
  const [showPO, setShowPO] = useState(false);

  // paginación simple
  const [page, setPage] = useState(1);
  const pageSize = 24;

  // cargar inventario
  useEffect(() => {
    (async () => {
      try {
        // 👇 aquí lo separamos por entidades reales de base44
        const [pRes, sRes, poRes] = await Promise.allSettled([
          base44.entities.Product?.list?.() ?? [],
          base44.entities.Service?.list?.() ?? [],
          base44.entities.PurchaseOrder?.list?.("-created_date", 100) ?? [],
        ]);

        const prods =
          pRes.status === "fulfilled"
            ? (pRes.value || []).map((p) => ({ ...p, kind: "product" }))
            : [];
        const svcs =
            sRes.status === "fulfilled"
              ? (sRes.value || []).map((s) => ({ ...s, kind: "service" }))
              : [];

        // 👇 piezas/accesorios las podemos sacar del mismo Product si vienen con category = "piezas" o "accesorios"
        const parts = prods
          .filter((p) =>
            String(p.category || "").toLowerCase().match(/pieza|acces/)
          )
          .map((p) => ({ ...p, kind: "part" }));

        // 👇 productos de verdad (no piezas)
        const onlyProducts = prods.filter(
          (p) =>
            !String(p.category || "").toLowerCase().match(/pieza|acces/)
        );

        // combinamos: productos + piezas + servicios
        const all = [...onlyProducts, ...parts, ...svcs].sort((a, b) =>
          String(a.name || "").localeCompare(String(b.name || ""))
        );
        setItems(all);

        const POlist =
          poRes.status === "fulfilled" ? poRes.value || [] : [];
        setPoList(POlist);
      } catch (err) {
        console.error("load inventory", err);
      }
    })();
  }, []);

  // filtrar
  const filtered = useMemo(() => {
    let list = items.slice();
    if (tab !== "all") {
      list = list.filter((it) => it.kind === tab);
    }
    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter(
        (it) =>
          String(it.name || "").toLowerCase().includes(t) ||
          String(it.category || "").toLowerCase().includes(t) ||
          String(it.supplier_name || "").toLowerCase().includes(t) ||
          (Array.isArray(it.compatibility_models) &&
            it.compatibility_models.join(" ").toLowerCase().includes(t))
      );
    }
    return list;
  }, [items, tab, q]);

  // paginado
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageItems = filtered.slice(
    (page - 1) * pageSize,
    (page - 1) * pageSize + pageSize
  );

  // guardar item
  const handleSaveItem = async (payload) => {
    try {
      // 👇 mapear payload a entidad real
      if (payload.kind === "service") {
        // services
        if (payload.id) {
          await base44.entities.Service.update(payload.id, {
            name: payload.name,
            category: payload.category,
            price: payload.price,
            cost: payload.cost,
            description: payload.description,
            compatibility_models: payload.compatibility_models,
          });
        } else {
          await base44.entities.Service.create({
            name: payload.name,
            category: payload.category,
            price: payload.price,
            cost: payload.cost,
            description: payload.description,
            compatibility_models: payload.compatibility_models,
          });
        }
      } else {
        // product o part
        const data = {
          name: payload.name,
          category: payload.category,
          price: payload.price,
          cost: payload.cost,
          stock: payload.stock,
          min_stock: payload.min_stock,
          supplier_name: payload.supplier_name,
          description: payload.description,
          compatibility_models: payload.compatibility_models,
        };

        if (payload.id) {
          await base44.entities.Product.update(payload.id, data);
        } else {
          await base44.entities.Product.create(data);
        }
      }

      // recargar
      const newProds = await base44.entities.Product.list();
      const newSvcs = await base44.entities.Service.list();

      // reprocesar productos/piezas
      const parts = newProds
        .filter((p) =>
          String(p.category || "").toLowerCase().match(/pieza|acces/)
        )
        .map((p) => ({ ...p, kind: "part" }));
      const onlyProducts = newProds.filter(
        (p) =>
          !String(p.category || "").toLowerCase().match(/pieza|acces/)
      );
      const newAll = [
        ...onlyProducts.map((p) => ({ ...p, kind: "product" })),
        ...parts,
        ...newSvcs.map((s) => ({ ...s, kind: "service" })),
      ].sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));

      setItems(newAll);
      setShowDialog(false);
      setEditing(null);
    } catch (err) {
      console.error("save item", err);
      alert("No se pudo guardar el artículo.");
    }
  };

  // borrar
  const handleDeleteItem = async (item) => {
    const ok = confirm(`¿Eliminar "${item.name}"?`);
    if (!ok) return;
    try {
      if (item.kind === "service") {
        await base44.entities.Service.delete(item.id);
      } else {
        await base44.entities.Product.delete(item.id);
      }
      setItems((prev) => prev.filter((x) => x.id !== item.id));
    } catch (err) {
      console.error("delete item", err);
      alert("No se pudo eliminar.");
    }
  };

  // subir PDF a PO
  const handleUploadPO = async (poId, file) => {
    try {
      let fileUrl = "";
      if (base44?.integrations?.Core?.UploadFile) {
        const r = await base44.integrations.Core.UploadFile({ file });
        fileUrl =
          r.file_url || r.url || r.public_url || r.signed_url || r.download_url;
      } else if (base44?.files?.upload) {
        const r = await base44.files.upload(file);
        fileUrl =
          r.file_url || r.url || r.public_url || r.signed_url || r.download_url;
      }

      if (fileUrl) {
        await base44.entities.PurchaseOrder.update(poId, {
          attachment_url: fileUrl,
        });
        // refrescar lista
        const po = await base44.entities.PurchaseOrder.list(
          "-created_date",
          100
        );
        setPoList(po || []);
        alert("PDF adjuntado.");
      } else {
        alert("No se pudo subir el archivo.");
      }
    } catch (err) {
      console.error("upload po pdf", err);
      alert("No se pudo adjuntar el PDF.");
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] text-white p-4 md:p-6 lg:p-8">
      {/* header */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">
            Inventario 911 SmartFix
          </h1>
          <p className="text-xs text-white/40">
            Productos, Piezas/Accesorios y Servicios en un solo lugar.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={() => setShowPO(true)}
            variant="outline"
            className="border-white/15"
          >
            <FileText className="w-4 h-4 mr-2" />
            Órdenes de compra
          </Button>
          <Button
            onClick={() => {
              setEditing(null);
              setShowDialog(true);
            }}
            className="bg-gradient-to-r from-red-600 to-red-800"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo ítem
          </Button>
        </div>
      </div>

      {/* filtros */}
      <div className="flex flex-wrap gap-2 items-center mb-4">
        {[
          { id: "all", label: "Todo" },
          { id: "product", label: "Productos" },
          { id: "part", label: "Piezas / Accesorios" },
          { id: "service", label: "Servicios" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => {
              setTab(t.id);
              setPage(1);
            }}
            className={`px-3 h-9 rounded-full border text-sm ${
              tab === t.id
                ? "bg-white text-black border-white"
                : "bg-white/5 border-white/10 text-white/60 hover:bg-white/10"
            }`}
          >
            {t.label}
          </button>
        ))}

        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
          <Input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
            placeholder="Buscar por nombre, categoría, suplidor, modelo…"
            className="pl-9 bg-black/25 border-white/10"
          />
        </div>
      </div>

      {/* grid */}
      <div className="flex-1 overflow-y-auto app-scroll">
        {pageItems.length === 0 ? (
          <div className="text-center py-16 text-white/20">
            No hay elementos en esta vista.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-4">
            {pageItems.map((item) => (
              <InventoryCard
                key={item.kind + "-" + item.id}
                item={item}
                onEdit={(it) => {
                  setEditing(it);
                  setShowDialog(true);
                }}
                onDelete={handleDeleteItem}
              />
            ))}
          </div>
        )}
      </div>

      {/* paginacion */}
      <div className="flex items-center justify-between mt-4 text-sm text-white/40">
        <p>
          Mostrando {pageItems.length} de {filtered.length} ítems
        </p>
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="outline"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="border-white/10"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span>
            {page} / {pageCount}
          </span>
          <Button
            size="icon"
            variant="outline"
            disabled={page >= pageCount}
            onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
            className="border-white/10"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* dialog item */}
      {showDialog && (
        <InventoryItemDialog
          open={showDialog}
          onOpenChange={setShowDialog}
          value={editing}
          onSave={handleSaveItem}
        />
      )}

      {/* dialog órdenes de compra */}
      {showPO && (
        <PurchaseOrdersDialog
          open={showPO}
          onOpenChange={setShowPO}
          orders={poList}
          onUpload={handleUploadPO}
        />
      )}
    </div>
  );
}