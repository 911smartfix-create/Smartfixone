
import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, User, Phone, Mail, History, Edit, Trash2, ChevronRight } from "lucide-react";
import CreateCustomerDialog from "../components/customers/CreateCustomerDialog";
import CustomerOrdersDialog from "../components/customers/CustomerOrdersDialog";

export default function Customers() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showOrdersDialog, setShowOrdersDialog] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);

  const queryClient = useQueryClient();

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list("-created_date"),
  });

  const deleteCustomerMutation = useMutation({
    mutationFn: (customerId) => base44.entities.Customer.delete(customerId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
    },
  });

  const filteredCustomers = useMemo(() => {
    if (!searchQuery) return customers;
    const query = searchQuery.toLowerCase();
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(query) ||
        c.phone.includes(query) ||
        (c.email && c.email.toLowerCase().includes(query))
    );
  }, [customers, searchQuery]);

  const handleDelete = async (customerId) => {
    if (window.confirm("¿Estás seguro de eliminar este cliente?")) {
      try {
        await deleteCustomerMutation.mutateAsync(customerId);
      } catch (error) {
        alert("Error al eliminar el cliente: " + error.message);
      }
    }
  };

  const handleEdit = (customer) => {
    setEditingCustomer(customer);
    setShowCreateDialog(true);
  };

  const handleViewOrders = async (customer) => {
    try {
      // Cargar las órdenes del cliente
      const orders = await base44.entities.Order.filter({ customer_id: customer.id });
      setSelectedCustomer({ ...customer, orders: orders || [] });
      setShowOrdersDialog(true);
    } catch (error) {
      console.error("Error loading customer orders:", error);
      // Ensure orders is an empty array even if fetching fails, to prevent undefined errors
      setSelectedCustomer({ ...customer, orders: [] });
      setShowOrdersDialog(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] text-white">
      {/* Header - Responsive */}
      <div className="sticky top-0 z-10 bg-black/80 backdrop-blur-xl border-b border-red-900/30 px-4 sm:px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold">Clientes</h1>
              <p className="text-gray-400 text-sm mt-1">
                {customers.length} {customers.length === 1 ? "cliente" : "clientes"} registrados
              </p>
            </div>
            <Button
              onClick={() => {
                setEditingCustomer(null);
                setShowCreateDialog(true);
              }}
              className="bg-gradient-to-r from-[#FF0000] to-red-800 hover:from-red-700 hover:to-red-900 w-full sm:w-auto"
            >
              <Plus className="w-5 h-5 mr-2" />
              Nuevo Cliente
            </Button>
          </div>

          {/* Search Bar */}
          <div className="mt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4 sm:w-5 sm:h-5" />
              <Input
                placeholder="Buscar por nombre, teléfono o email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 sm:pl-12 bg-black/40 border-white/15 text-white placeholder:text-gray-500 h-10 sm:h-11"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full mx-auto mb-3"></div>
            <p className="text-gray-400">Cargando clientes...</p>
          </div>
        ) : filteredCustomers.length === 0 ? (
          <div className="text-center py-12">
            <User className="w-16 h-16 mx-auto mb-4 text-gray-600" />
            <p className="text-gray-400 mb-4">
              {searchQuery ? "No se encontraron clientes" : "No hay clientes registrados"}
            </p>
            {!searchQuery && (
              <Button
                onClick={() => setShowCreateDialog(true)}
                className="bg-gradient-to-r from-[#FF0000] to-red-800"
              >
                <Plus className="w-5 h-5 mr-2" />
                Crear Primer Cliente
              </Button>
            )}
          </div>
        ) : (
          <>
            {/* Mobile/Tablet - Card List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:hidden gap-3 sm:gap-4">
              {filteredCustomers.map((customer) => (
                <Card
                  key={customer.id}
                  className="bg-[#121212] border-white/10 hover:border-red-600/30 transition-all cursor-pointer"
                  onClick={() => handleViewOrders(customer)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white font-bold text-sm sm:text-base flex-shrink-0">
                          {customer.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0 flex-1">
                          <h3 className="text-white font-semibold text-sm sm:text-base truncate">
                            {customer.name}
                          </h3>
                          {customer.total_orders > 0 && (
                            <Badge className="bg-red-600/20 text-red-300 border-red-600/30 text-xs mt-1">
                              {customer.total_orders} {customer.total_orders === 1 ? "orden" : "órdenes"}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 text-xs sm:text-sm">
                      <div className="flex items-center gap-2 text-gray-400">
                        <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0" />
                        <span className="truncate">{customer.phone}</span>
                      </div>
                      {customer.email && (
                        <div className="flex items-center gap-2 text-gray-400">
                          <Mail className="w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0" />
                          <span className="truncate">{customer.email}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 mt-4 pt-3 border-t border-white/10">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEdit(customer);
                        }}
                        className="flex-1 border-white/15 hover:bg-white/5 text-xs sm:text-sm h-8"
                      >
                        <Edit className="w-3.5 h-3.5 mr-1.5" />
                        Editar
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(customer.id);
                        }}
                        className="flex-1 border-red-600/30 text-red-400 hover:bg-red-600/10 text-xs sm:text-sm h-8"
                      >
                        <Trash2 className="w-3.5 h-3.5 mr-1.5" />
                        Eliminar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Desktop - Table */}
            <div className="hidden lg:block bg-[#121212] border border-white/10 rounded-xl overflow-hidden">
              <table className="w-full">
                <thead className="bg-black/40 border-b border-white/10">
                  <tr>
                    <th className="text-left p-4 text-gray-400 font-medium text-sm">Cliente</th>
                    <th className="text-left p-4 text-gray-400 font-medium text-sm">Teléfono</th>
                    <th className="text-left p-4 text-gray-400 font-medium text-sm">Email</th>
                    <th className="text-center p-4 text-gray-400 font-medium text-sm">Órdenes</th>
                    <th className="text-right p-4 text-gray-400 font-medium text-sm">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCustomers.map((customer) => (
                    <tr
                      key={customer.id}
                      className="border-b border-white/5 hover:bg-white/5 transition-colors cursor-pointer"
                      onClick={() => handleViewOrders(customer)}
                    >
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white font-bold">
                            {customer.name.charAt(0).toUpperCase()}
                          </div>
                          <span className="text-white font-medium">{customer.name}</span>
                        </div>
                      </td>
                      <td className="p-4 text-gray-300">{customer.phone}</td>
                      <td className="p-4 text-gray-300">{customer.email || "—"}</td>
                      <td className="p-4 text-center">
                        <Badge className="bg-red-600/20 text-red-300 border-red-600/30">
                          {customer.total_orders || 0}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewOrders(customer);
                            }}
                            className="hover:bg-white/5"
                          >
                            <History className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEdit(customer);
                            }}
                            className="hover:bg-white/5"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDelete(customer.id);
                            }}
                            className="hover:bg-red-600/10 text-red-400"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Dialogs */}
      <CreateCustomerDialog
        open={showCreateDialog}
        onClose={() => {
          setShowCreateDialog(false);
          setEditingCustomer(null);
        }}
        customer={editingCustomer}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ["customers"] });
          setShowCreateDialog(false);
          setEditingCustomer(null);
        }}
      />

      {selectedCustomer && (
        <CustomerOrdersDialog
          open={showOrdersDialog}
          onClose={() => {
            setShowOrdersDialog(false);
            setSelectedCustomer(null);
          }}
          customer={selectedCustomer}
          orders={selectedCustomer.orders || []}
        />
      )}
    </div>
  );
}
