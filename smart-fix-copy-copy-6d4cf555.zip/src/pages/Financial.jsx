import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown,
  Wallet, 
  Receipt,
  Download,
  CreditCard,
  Landmark,
  FileText,
  RefreshCw,
  Plus,
  Calendar,
  Filter
} from "lucide-react";
import { format, startOfDay, endOfDay, isWithinInterval, startOfMonth, endOfMonth } from "date-fns";
import { es } from "date-fns/locale";
import OpenDrawerDialog from "../components/cash/OpenDrawerDialog";
import CloseDrawerDialog from "../components/cash/CloseDrawerDialog";
import ExpenseDialog from "../components/financial/ExpenseDialog";

const StatCard = ({ title, value, icon: Icon, color, trend, onClick }) => (
  <Card 
    className={`bg-gradient-to-br from-[#2B2B2B] to-black border-${color}-900/30 hover:shadow-lg hover:shadow-${color}-600/20 transition-all ${onClick ? 'cursor-pointer' : ''}`}
    onClick={onClick}
  >
    <CardContent className="pt-6">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-400 uppercase tracking-wide">{title}</p>
          <p className={`text-3xl font-bold text-${color}-400 mt-2`}>{value}</p>
          {trend && (
            <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
              {trend.direction === 'up' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              {trend.text}
            </p>
          )}
        </div>
        <div className={`p-3 rounded-xl bg-${color}-600/20 border border-${color}-500/30`}>
          <Icon className={`w-6 h-6 text-${color}-400`} />
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function Financial() {
  const [sales, setSales] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [currentDrawer, setCurrentDrawer] = useState(null);
  const [showOpenDrawer, setShowOpenDrawer] = useState(false);
  const [showCloseDrawer, setShowCloseDrawer] = useState(false);
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const [dateFilter, setDateFilter] = useState("today");
  const [activeTab, setActiveTab] = useState("dashboard");

  useEffect(() => {
    loadData();
    
    const interval = setInterval(loadData, 30000);
    
    const handleRefresh = () => {
      console.log('[Financial] Refresh triggered');
      loadData();
    };
    window.addEventListener("force-refresh", handleRefresh);
    window.addEventListener("sale-completed", handleRefresh);
    
    return () => {
      clearInterval(interval);
      window.removeEventListener("force-refresh", handleRefresh);
      window.removeEventListener("sale-completed", handleRefresh);
    };
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      console.log('[Financial] 🔄 Loading all data...');
      
      // ✅ Verificar autenticación primero
      try {
        await base44.auth.me();
      } catch (authError) {
        console.log('[Financial] ⚠️ Not authenticated, redirecting to login');
        await base44.auth.redirectToLogin();
        setLoading(false);
        return;
      }
      
      const today = format(new Date(), "yyyy-MM-dd");
      
      const [salesData, transactionsData, registers, cashMovements] = await Promise.all([
        base44.entities.Sale.list("-created_date", 500),
        base44.entities.Transaction.list("-created_date", 500),
        base44.entities.CashRegister.filter({ date: today }),
        base44.entities.CashDrawerMovement.list("-created_date", 500)
      ]);
      
      console.log('[Financial] 📊 Data loaded:', {
        sales: salesData?.length || 0,
        transactions: transactionsData?.length || 0,
        registers: registers?.length || 0,
        movements: cashMovements?.length || 0
      });
      
      // Log primeras ventas para debug
      if (salesData?.length > 0) {
        console.log('[Financial] 📝 Sample sale:', salesData[0]);
      }
      if (transactionsData?.length > 0) {
        console.log('[Financial] 💰 Sample transaction:', transactionsData[0]);
      }
      
      const validSales = (salesData || []).filter(s => !s.voided);
      const validTransactions = transactionsData || [];
      
      console.log('[Financial] ✅ Valid data:', {
        validSales: validSales.length,
        validTransactions: validTransactions.length
      });
      
      // Separar gastos e ingresos
      const revenueTransactions = validTransactions.filter(t => t.type === 'revenue');
      const expenseTransactions = validTransactions.filter(t => t.type === 'expense');
      const expenseMovements = (cashMovements || []).filter(m => m.type === 'expense');
      
      console.log('[Financial] 💵 Revenue transactions:', revenueTransactions.length);
      console.log('[Financial] 💸 Expense transactions:', expenseTransactions.length);
      
      // Combinar gastos
      const allExpenses = [
        ...expenseTransactions.map(t => ({
          ...t,
          source: 'transaction',
          category: t.category || 'other_expense'
        })),
        ...expenseMovements.map(m => ({
          ...m,
          source: 'movement',
          amount: m.amount,
          description: m.description,
          category: 'other_expense',
          created_date: m.created_date
        }))
      ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
      
      setSales(validSales);
      setTransactions(validTransactions);
      setExpenses(allExpenses);
      
      const openRegister = registers.find(r => r.status === 'open');
      setDrawerOpen(!!openRegister);
      setCurrentDrawer(openRegister);
      
      console.log('[Financial] ✅ State updated successfully');
      
    } catch (error) {
      console.error('[Financial] ❌ Error loading data:', error);
      setSales([]);
      setTransactions([]);
      setExpenses([]);
    }
    setLoading(false);
  };

  const getDateRange = () => {
    const now = new Date();
    switch (dateFilter) {
      case "today":
        return { start: startOfDay(now), end: endOfDay(now) };
      case "month":
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case "all":
        return { start: new Date(0), end: new Date() };
      default:
        return { start: startOfDay(now), end: endOfDay(now) };
    }
  };

  const stats = useMemo(() => {
    const { start, end } = getDateRange();

    // Ventas en rango
    const filteredSales = sales.filter(s => {
      try {
        const date = new Date(s.created_date);
        return isWithinInterval(date, { start, end });
      } catch {
        return false;
      }
    });

    // Transacciones de ingresos en rango
    const revenueTransactions = transactions.filter(t => {
      try {
        const date = new Date(t.created_date);
        return t.type === 'revenue' && isWithinInterval(date, { start, end });
      } catch {
        return false;
      }
    });

    // Gastos en rango
    const filteredExpenses = expenses.filter(e => {
      try {
        const date = new Date(e.created_date);
        return isWithinInterval(date, { start, end });
      } catch {
        return false;
      }
    });

    const totalRevenue = revenueTransactions.reduce((sum, t) => sum + (t.amount || 0), 0);
    const totalExpenses = filteredExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    const netProfit = totalRevenue - totalExpenses;
    const salesCount = filteredSales.length;
    const avgTicket = salesCount > 0 ? totalRevenue / salesCount : 0;

    // Por método de pago
    const byMethod = filteredSales.reduce((acc, s) => {
      if (s.payment_method === 'mixed' && s.payment_details?.methods) {
        s.payment_details.methods.forEach(m => {
          acc[m.method] = (acc[m.method] || 0) + (m.amount || 0);
        });
      } else {
        const method = s.payment_method || 'cash';
        acc[method] = (acc[method] || 0) + (s.total || 0);
      }
      return acc;
    }, {});

    // Gastos por categoría
    const expensesByCategory = filteredExpenses.reduce((acc, e) => {
      const cat = e.category || 'other_expense';
      acc[cat] = (acc[cat] || 0) + (e.amount || 0);
      return acc;
    }, {});

    return {
      totalRevenue,
      totalExpenses,
      netProfit,
      salesCount,
      avgTicket,
      byMethod,
      expensesByCategory,
      filteredSales,
      filteredExpenses,
      revenueTransactions
    };
  }, [sales, transactions, expenses, dateFilter]);

  const paymentMethodIcons = {
    cash: Wallet,
    card: CreditCard,
    ath_movil: Landmark,
    transfer: Landmark,
    mixed: DollarSign,
  };

  const categoryLabels = {
    rent: "Renta",
    utilities: "Utilidades (Luz, Agua, etc.)",
    supplies: "Suministros",
    payroll: "Nómina",
    parts: "Piezas/Inventario",
    other_expense: "Otros Gastos"
  };

  const handleActionSuccess = () => {
    setShowOpenDrawer(false);
    setShowCloseDrawer(false);
    setShowExpenseDialog(false);
    loadData();
  };

  const handleExport = () => {
    const csvData = [
      ['Tipo', 'Fecha', 'Descripción', 'Monto', 'Método', 'Categoría'],
      ...stats.filteredSales.map(s => [
        'Ingreso',
        format(new Date(s.created_date), 'dd/MM/yyyy HH:mm'),
        `Venta ${s.sale_number}`,
        s.total,
        s.payment_method,
        'Venta'
      ]),
      ...stats.filteredExpenses.map(e => [
        'Gasto',
        format(new Date(e.created_date), 'dd/MM/yyyy HH:mm'),
        e.description,
        e.amount,
        '-',
        categoryLabels[e.category] || e.category
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte-financiero-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] p-4 md:p-8">
      <div className="max-w-[1600px] mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#FF0000] to-red-700 bg-clip-text text-transparent">
              Centro Financiero
            </h1>
            <p className="text-gray-400 mt-2">Control completo de ingresos, gastos y flujo de caja</p>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <div className="flex items-center gap-2 bg-black/40 rounded-lg p-1">
              <Button 
                size="sm"
                variant={dateFilter === "today" ? "default" : "ghost"}
                onClick={() => setDateFilter("today")}
                className={dateFilter === "today" ? "bg-red-600 hover:bg-red-700" : ""}
              >
                Hoy
              </Button>
              <Button 
                size="sm"
                variant={dateFilter === "month" ? "default" : "ghost"}
                onClick={() => setDateFilter("month")}
                className={dateFilter === "month" ? "bg-red-600 hover:bg-red-700" : ""}
              >
                Este Mes
              </Button>
              <Button 
                size="sm"
                variant={dateFilter === "all" ? "default" : "ghost"}
                onClick={() => setDateFilter("all")}
                className={dateFilter === "all" ? "bg-red-600 hover:bg-red-700" : ""}
              >
                Todo
              </Button>
            </div>

            <Button 
              variant="outline" 
              onClick={loadData}
              disabled={loading}
              className="border-white/10"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`}/>
              Actualizar
            </Button>
            
            <Button variant="outline" onClick={handleExport} className="border-white/10">
              <Download className="w-4 h-4 mr-2"/> Exportar
            </Button>

            <Button 
              onClick={() => setShowExpenseDialog(true)}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Plus className="w-4 h-4 mr-2"/> Registrar Gasto
            </Button>
            
            {drawerOpen ? 
              <Button onClick={() => setShowCloseDrawer(true)} className="bg-red-800 hover:bg-red-900">
                <Wallet className="w-4 h-4 mr-2"/> Cerrar Caja
              </Button> :
              <Button onClick={() => setShowOpenDrawer(true)} className="bg-green-600 hover:bg-green-700">
                <Wallet className="w-4 h-4 mr-2"/> Abrir Caja
              </Button>
            }
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard 
            title="Ingresos" 
            value={`$${stats.totalRevenue.toFixed(2)}`} 
            icon={TrendingUp} 
            color="green"
            trend={{ direction: 'up', text: `${stats.salesCount} ventas` }}
          />
          
          <StatCard 
            title="Gastos" 
            value={`$${stats.totalExpenses.toFixed(2)}`} 
            icon={TrendingDown} 
            color="red"
            trend={{ direction: 'down', text: `${stats.filteredExpenses.length} registros` }}
          />
          
          <StatCard 
            title="Utilidad Neta" 
            value={`$${stats.netProfit.toFixed(2)}`} 
            icon={DollarSign} 
            color={stats.netProfit >= 0 ? "emerald" : "red"}
          />
          
          <StatCard 
            title="Ticket Promedio" 
            value={`$${stats.avgTicket.toFixed(2)}`} 
            icon={Receipt} 
            color="blue"
          />
          
          <StatCard 
            title="Efectivo" 
            value={`$${(stats.byMethod.cash || 0).toFixed(2)}`} 
            icon={Wallet} 
            color="yellow"
          />
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-black/40 border border-white/10">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="sales">Ventas ({stats.filteredSales.length})</TabsTrigger>
            <TabsTrigger value="expenses">Gastos ({stats.filteredExpenses.length})</TabsTrigger>
            <TabsTrigger value="methods">Por Método</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gastos por categoría */}
              <Card className="bg-gradient-to-br from-[#2B2B2B] to-black border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Gastos por Categoría</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(stats.expensesByCategory).length > 0 ? (
                      Object.entries(stats.expensesByCategory).map(([category, amount]) => (
                        <div key={category} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                          <span className="text-gray-300">{categoryLabels[category] || category}</span>
                          <span className="text-red-400 font-semibold">${amount.toFixed(2)}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-8">No hay gastos registrados</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Métodos de pago */}
              <Card className="bg-gradient-to-br from-[#2B2B2B] to-black border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Ingresos por Método</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(stats.byMethod).length > 0 ? (
                      Object.entries(stats.byMethod).map(([method, amount]) => {
                        const Icon = paymentMethodIcons[method] || DollarSign;
                        return (
                          <div key={method} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                            <div className="flex items-center gap-2">
                              <Icon className="w-4 h-4 text-gray-400" />
                              <span className="text-gray-300 capitalize">
                                {method === 'ath_movil' ? 'ATH Móvil' : method === 'mixed' ? 'Mixto' : method}
                              </span>
                            </div>
                            <span className="text-green-400 font-semibold">${amount.toFixed(2)}</span>
                          </div>
                        );
                      })
                    ) : (
                      <p className="text-gray-500 text-center py-8">No hay ingresos registrados</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Sales Tab */}
          <TabsContent value="sales">
            <Card className="bg-gradient-to-br from-[#2B2B2B] to-black border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Historial de Ventas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto max-h-[60vh] app-scroll">
                  <table className="w-full text-sm">
                    <thead className="text-left text-gray-400 sticky top-0 bg-black/50 backdrop-blur-sm">
                      <tr>
                        <th className="p-3">Fecha/Hora</th>
                        <th className="p-3">Recibo #</th>
                        <th className="p-3">Cliente</th>
                        <th className="p-3">Items</th>
                        <th className="p-3">Método</th>
                        <th className="p-3">Monto</th>
                        <th className="p-3">Usuario</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr><td colSpan="7" className="p-8 text-center text-gray-500">
                          <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
                          Cargando...
                        </td></tr>
                      ) : stats.filteredSales.length === 0 ? (
                        <tr><td colSpan="7" className="p-8 text-center text-gray-500">
                          No hay ventas en el período seleccionado
                        </td></tr>
                      ) : (
                        stats.filteredSales.map(s => {
                          const Icon = paymentMethodIcons[s.payment_method] || DollarSign;
                          const saleDate = new Date(s.created_date);
                          
                          return (
                            <tr key={s.id} className="border-t border-gray-800 hover:bg-gray-900/50">
                              <td className="p-3">
                                <div className="flex flex-col">
                                  <span className="text-white">{format(saleDate, 'dd/MM/yyyy')}</span>
                                  <span className="text-gray-500 text-xs">{format(saleDate, 'HH:mm:ss')}</span>
                                </div>
                              </td>
                              <td className="p-3 font-mono text-gray-300">{s.sale_number}</td>
                              <td className="p-3 text-gray-300">{s.customer_name || 'Cliente General'}</td>
                              <td className="p-3 text-gray-400">{s.items?.length || 0} items</td>
                              <td className="p-3">
                                <Badge variant="outline" className="capitalize flex items-center gap-1.5 w-fit">
                                  <Icon className="w-3 h-3"/>
                                  {s.payment_method === 'mixed' ? 'Mixto' : 
                                   s.payment_method === 'ath_movil' ? 'ATH Móvil' :
                                   s.payment_method}
                                </Badge>
                              </td>
                              <td className="p-3 font-bold text-green-400">${(s.total || 0).toFixed(2)}</td>
                              <td className="p-3 text-gray-400">{s.employee || '—'}</td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Expenses Tab */}
          <TabsContent value="expenses">
            <Card className="bg-gradient-to-br from-[#2B2B2B] to-black border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span>Historial de Gastos</span>
                  <Button 
                    onClick={() => setShowExpenseDialog(true)}
                    size="sm"
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <Plus className="w-4 h-4 mr-2"/> Nuevo Gasto
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto max-h-[60vh] app-scroll">
                  <table className="w-full text-sm">
                    <thead className="text-left text-gray-400 sticky top-0 bg-black/50 backdrop-blur-sm">
                      <tr>
                        <th className="p-3">Fecha/Hora</th>
                        <th className="p-3">Descripción</th>
                        <th className="p-3">Categoría</th>
                        <th className="p-3">Monto</th>
                        <th className="p-3">Registrado por</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr><td colSpan="5" className="p-8 text-center text-gray-500">
                          <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
                          Cargando...
                        </td></tr>
                      ) : stats.filteredExpenses.length === 0 ? (
                        <tr><td colSpan="5" className="p-8 text-center text-gray-500">
                          No hay gastos en el período seleccionado
                        </td></tr>
                      ) : (
                        stats.filteredExpenses.map((e, idx) => {
                          const expenseDate = new Date(e.created_date);
                          
                          return (
                            <tr key={e.id || idx} className="border-t border-gray-800 hover:bg-gray-900/50">
                              <td className="p-3">
                                <div className="flex flex-col">
                                  <span className="text-white">{format(expenseDate, 'dd/MM/yyyy')}</span>
                                  <span className="text-gray-500 text-xs">{format(expenseDate, 'HH:mm:ss')}</span>
                                </div>
                              </td>
                              <td className="p-3 text-gray-300">{e.description || '—'}</td>
                              <td className="p-3">
                                <Badge variant="outline" className="capitalize">
                                  {categoryLabels[e.category] || e.category}
                                </Badge>
                              </td>
                              <td className="p-3 font-bold text-red-400">${(e.amount || 0).toFixed(2)}</td>
                              <td className="p-3 text-gray-400">{e.recorded_by || e.employee || '—'}</td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Methods Tab */}
          <TabsContent value="methods">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.entries(stats.byMethod).map(([method, amount]) => {
                const Icon = paymentMethodIcons[method] || DollarSign;
                const methodSales = stats.filteredSales.filter(s => {
                  if (s.payment_method === method) return true;
                  if (s.payment_method === 'mixed' && s.payment_details?.methods) {
                    return s.payment_details.methods.some(m => m.method === method);
                  }
                  return false;
                });

                return (
                  <Card key={method} className="bg-gradient-to-br from-[#2B2B2B] to-black border-gray-800">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-white">
                        <Icon className="w-5 h-5" />
                        <span className="capitalize">
                          {method === 'ath_movil' ? 'ATH Móvil' : method === 'mixed' ? 'Mixto' : method}
                        </span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-400">Total</p>
                          <p className="text-3xl font-bold text-green-400">${amount.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-400">Transacciones</p>
                          <p className="text-xl font-semibold text-white">{methodSales.length}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-400">Promedio</p>
                          <p className="text-lg text-gray-300">
                            ${methodSales.length > 0 ? (amount / methodSales.length).toFixed(2) : '0.00'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      {showOpenDrawer && (
        <OpenDrawerDialog 
          open={showOpenDrawer} 
          onClose={() => setShowOpenDrawer(false)} 
          onSuccess={handleActionSuccess}
        />
      )}
      
      {showCloseDrawer && (
        <CloseDrawerDialog 
          open={showCloseDrawer} 
          onClose={() => setShowCloseDrawer(false)} 
          onSuccess={handleActionSuccess}
          drawer={currentDrawer}
          stats={stats}
        />
      )}

      {showExpenseDialog && (
        <ExpenseDialog
          open={showExpenseDialog}
          onClose={() => setShowExpenseDialog(false)}
          onSuccess={handleActionSuccess}
          drawer={currentDrawer}
        />
      )}
    </div>
  );
}