import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Settings as SettingsIcon,
  Save,
  RefreshCw,
  LayoutDashboard,
  ClipboardList,
  ShoppingCart,
  Users,
  Package,
  BarChart3,
  Briefcase,
  Cog,
  Plus,
  Trash2,
  Edit
} from "lucide-react";

const DEFAULT_SETTINGS = {
  dashboard: {
    showDailySales: true,
    showActiveRepairs: true,
    showPendingToOrder: true,
    showRecentPOS: true,
    showSearchBar: true,
    showKpiCards: true
  },
  orders: {
    defaultOrderView: "list",
    openOrderInPanel: true,
    hideRecentCustomersBar: false,
    showDeviceIcons: true,
    mobileAccordionsSingleOpen: false
  },
  workOrder: {
    enableWizardChecklist: true,
    showAccessBlock: true,
    workOrderStatusList: [
      "intake",
      "diagnosing",
      "awaiting_approval",
      "pending_order",
      "waiting_parts",
      "reparacion_externa",
      "in_progress",
      "ready_for_pickup",
      "picked_up",
      "completed",
      "cancelled"
    ],
    autoOpenPOSOnAddItem: true,
    allowPhotoUploads: true,
    savePhotosTo: "attachments"
  },
  pos: {
    posMobileLayout: true,
    allowPartialPaymentsFromOrder: true,
    autoAttachPaymentToOrder: true,
    showRecentTransactionsOnDashboard: true
  },
  customers: {
    allowCustomerEditFromOrder: true,
    showCustomerWhatsAppButton: true,
    customerDefaultCountryCode: "+1 787"
  },
  inventory: {
    linkServicesToInventory: true,
    showSuggestedPartsByModel: true,
    allowDeleteItemsFromOrder: true,
    showStockBadge: true
  },
  reports: {
    showSalesReport: true,
    showRepairsReport: true,
    showEmployeesReport: true,
    defaultReportRange: "week"
  },
  employees: {
    allowNotesAssignToEmployees: true,
    showPunchButtons: true
  },
  system: {
    locale: "es-PR",
    taxRate: 0.115,
    currencySymbol: "$",
    storeName: "911 SmartFix",
    hideBottomNavOnWorkOrder: true,
    theme: "dark"
  }
};

function SwitchToggle({ checked, onChange, disabled }) {
  return (
    <button
      type="button"
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`
        relative inline-flex h-6 w-11 items-center rounded-full transition-colors
        ${checked ? "bg-red-600" : "bg-gray-700"}
        ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
      `}
    >
      <span
        className={`
          inline-block h-4 w-4 transform rounded-full bg-white transition-transform
          ${checked ? "translate-x-6" : "translate-x-1"}
        `}
      />
    </button>
  );
}

function SettingRow({ label, description, children }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-white/10 last:border-0">
      <div className="flex-1 pr-4">
        <p className="text-sm font-medium text-white">{label}</p>
        {description && <p className="text-xs text-gray-400 mt-0.5">{description}</p>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

function EmployeeModal({ open, onClose, onSave, employee }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    role: "technician",
    punch_pin: "",
    active: true,
    notes: ""
  });

  useEffect(() => {
    if (employee) {
      setFormData(employee);
    } else {
      setFormData({
        name: "",
        email: "",
        phone: "",
        role: "technician",
        punch_pin: "",
        active: true,
        notes: ""
      });
    }
  }, [employee, open]);

  if (!open) return null;

  const handleSave = () => {
    if (!formData.name.trim()) {
      alert("El nombre es requerido");
      return;
    }
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm">
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg bg-[#111114] border-white/10">
          <CardHeader>
            <CardTitle className="text-white">
              {employee ? "Editar Empleado" : "Nuevo Empleado"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">Nombre *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-black/40 border-white/15 text-white"
                placeholder="Juan Pérez"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-gray-300">Email</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-black/40 border-white/15 text-white"
                  placeholder="juan@example.com"
                />
              </div>
              <div>
                <Label className="text-gray-300">Teléfono</Label>
                <Input
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="bg-black/40 border-white/15 text-white"
                  placeholder="787-123-4567"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-gray-300">Rol *</Label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="w-full h-10 px-3 rounded-md bg-black/40 border border-white/15 text-white"
                >
                  <option value="admin">Administrador</option>
                  <option value="manager">Gerente</option>
                  <option value="technician">Técnico</option>
                  <option value="cashier">Cajero</option>
                </select>
              </div>
              <div>
                <Label className="text-gray-300">PIN Ponche</Label>
                <Input
                  type="text"
                  maxLength={4}
                  value={formData.punch_pin}
                  onChange={(e) => setFormData({ ...formData, punch_pin: e.target.value.replace(/\D/g, "") })}
                  className="bg-black/40 border-white/15 text-white"
                  placeholder="1234"
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Notas</Label>
              <Input
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="bg-black/40 border-white/15 text-white"
                placeholder="Notas adicionales..."
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <Label className="text-gray-300">Estado Activo</Label>
              <SwitchToggle
                checked={formData.active}
                onChange={(val) => setFormData({ ...formData, active: val })}
              />
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button
                variant="outline"
                onClick={onClose}
                className="border-white/15"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSave}
                className="bg-red-600 hover:bg-red-700"
              >
                Guardar
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function Settings() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [employees, setEmployees] = useState([]);
  const [showEmployeeModal, setShowEmployeeModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);

  useEffect(() => {
    loadSettings();
    loadEmployees();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const records = await base44.entities.AppSettings.filter({ slug: "app-main-settings" });
      if (records && records.length > 0) {
        const loadedSettings = records[0].payload || DEFAULT_SETTINGS;
        setSettings({ ...DEFAULT_SETTINGS, ...loadedSettings });
      } else {
        const localSettings = localStorage.getItem("app-main-settings");
        if (localSettings) {
          setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(localSettings) });
        }
      }
    } catch (error) {
      console.error("Error loading settings:", error);
      const localSettings = localStorage.getItem("app-main-settings");
      if (localSettings) {
        setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(localSettings) });
      }
    } finally {
      setLoading(false);
    }
  };

  const loadEmployees = async () => {
    try {
      const emps = await base44.entities.AppEmployee.list("-created_date", 100);
      setEmployees(emps || []);
    } catch (error) {
      console.error("Error loading employees:", error);
      setEmployees([]);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const records = await base44.entities.AppSettings.filter({ slug: "app-main-settings" });
      
      if (records && records.length > 0) {
        await base44.entities.AppSettings.update(records[0].id, {
          payload: settings
        });
      } else {
        await base44.entities.AppSettings.create({
          slug: "app-main-settings",
          payload: settings,
          description: "Configuración principal de la aplicación"
        });
      }
      
      localStorage.setItem("app-main-settings", JSON.stringify(settings));
      
      alert("✅ Configuración guardada exitosamente");
    } catch (error) {
      console.error("Error saving settings:", error);
      localStorage.setItem("app-main-settings", JSON.stringify(settings));
      alert("⚠️ Guardado en caché local. No se pudo sincronizar con el servidor.");
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (section, key, value) => {
    setSettings({
      ...settings,
      [section]: {
        ...settings[section],
        [key]: value
      }
    });
  };

  const handleSaveEmployee = async (empData) => {
    try {
      if (editingEmployee) {
        await base44.entities.AppEmployee.update(editingEmployee.id, empData);
      } else {
        await base44.entities.AppEmployee.create(empData);
      }
      await loadEmployees();
      setShowEmployeeModal(false);
      setEditingEmployee(null);
    } catch (error) {
      console.error("Error saving employee:", error);
      alert("Error al guardar empleado");
    }
  };

  const handleDeleteEmployee = async (empId) => {
    if (!confirm("¿Eliminar este empleado?")) return;
    try {
      await base44.entities.AppEmployee.delete(empId);
      await loadEmployees();
    } catch (error) {
      console.error("Error deleting employee:", error);
      alert("Error al eliminar empleado");
    }
  };

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "orders", label: "Órdenes", icon: ClipboardList },
    { id: "workOrder", label: "Work Order", icon: ClipboardList },
    { id: "pos", label: "POS", icon: ShoppingCart },
    { id: "customers", label: "Clientes", icon: Users },
    { id: "inventory", label: "Inventario", icon: Package },
    { id: "reports", label: "Reportes", icon: BarChart3 },
    { id: "employees", label: "Empleados", icon: Briefcase },
    { id: "system", label: "Sistema", icon: Cog }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-400">Cargando configuración...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <SettingsIcon className="w-8 h-8 text-red-600" />
            <h1 className="text-3xl font-bold text-white">Configuración</h1>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={loadSettings}
              disabled={saving}
              className="border-white/15"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Recargar
            </Button>
            <Button
              onClick={saveSettings}
              disabled={saving}
              className="bg-red-600 hover:bg-red-700"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? "Guardando..." : "Guardar Cambios"}
            </Button>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Sidebar */}
          <div className="w-64 flex-shrink-0">
            <Card className="bg-[#111114] border-white/10 sticky top-6">
              <CardContent className="p-3">
                <nav className="space-y-1">
                  {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`
                          w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                          ${activeTab === tab.id
                            ? "bg-red-600 text-white"
                            : "text-gray-400 hover:text-white hover:bg-white/5"
                          }
                        `}
                      >
                        <Icon className="w-4 h-4" />
                        {tab.label}
                      </button>
                    );
                  })}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Content */}
          <div className="flex-1">
            <Card className="bg-[#111114] border-white/10">
              <CardHeader className="border-b border-white/10">
                <CardTitle className="text-white text-xl">
                  {tabs.find(t => t.id === activeTab)?.label}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {activeTab === "dashboard" && (
                  <div className="space-y-2">
                    <SettingRow
                      label="Mostrar ventas del día"
                      description="Tarjeta con las ventas totales de hoy"
                    >
                      <SwitchToggle
                        checked={settings.dashboard.showDailySales}
                        onChange={(val) => updateSetting("dashboard", "showDailySales", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar reparaciones activas"
                      description="Contador de órdenes en proceso"
                    >
                      <SwitchToggle
                        checked={settings.dashboard.showActiveRepairs}
                        onChange={(val) => updateSetting("dashboard", "showActiveRepairs", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar pendientes de ordenar"
                      description="Alerta de trabajos esperando piezas"
                    >
                      <SwitchToggle
                        checked={settings.dashboard.showPendingToOrder}
                        onChange={(val) => updateSetting("dashboard", "showPendingToOrder", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar transacciones POS recientes"
                      description="Lista de últimas ventas del día"
                    >
                      <SwitchToggle
                        checked={settings.dashboard.showRecentPOS}
                        onChange={(val) => updateSetting("dashboard", "showRecentPOS", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar barra de búsqueda"
                      description="Búsqueda global en el dashboard"
                    >
                      <SwitchToggle
                        checked={settings.dashboard.showSearchBar}
                        onChange={(val) => updateSetting("dashboard", "showSearchBar", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar tarjetas KPI"
                      description="Métricas rápidas (Nueva Orden, Abrir Caja, etc.)"
                    >
                      <SwitchToggle
                        checked={settings.dashboard.showKpiCards}
                        onChange={(val) => updateSetting("dashboard", "showKpiCards", val)}
                      />
                    </SettingRow>
                  </div>
                )}

                {activeTab === "orders" && (
                  <div className="space-y-2">
                    <SettingRow
                      label="Vista por defecto"
                      description="Cómo mostrar las órdenes al cargar"
                    >
                      <select
                        value={settings.orders.defaultOrderView}
                        onChange={(e) => updateSetting("orders", "defaultOrderView", e.target.value)}
                        className="px-3 py-1.5 rounded-md bg-black/40 border border-white/15 text-white text-sm"
                      >
                        <option value="list">Lista</option>
                        <option value="cards">Tarjetas</option>
                      </select>
                    </SettingRow>
                    <SettingRow
                      label="Abrir orden en panel lateral"
                      description="Mostrar detalles sin salir de la lista"
                    >
                      <SwitchToggle
                        checked={settings.orders.openOrderInPanel}
                        onChange={(val) => updateSetting("orders", "openOrderInPanel", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Ocultar barra de clientes recientes"
                      description="No mostrar últimos clientes en órdenes"
                    >
                      <SwitchToggle
                        checked={settings.orders.hideRecentCustomersBar}
                        onChange={(val) => updateSetting("orders", "hideRecentCustomersBar", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar íconos de dispositivos"
                      description="Iconos visuales por tipo de equipo"
                    >
                      <SwitchToggle
                        checked={settings.orders.showDeviceIcons}
                        onChange={(val) => updateSetting("orders", "showDeviceIcons", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Acordeones móviles un solo abierto"
                      description="Cerrar automáticamente al abrir otro"
                    >
                      <SwitchToggle
                        checked={settings.orders.mobileAccordionsSingleOpen}
                        onChange={(val) => updateSetting("orders", "mobileAccordionsSingleOpen", val)}
                      />
                    </SettingRow>
                  </div>
                )}

                {activeTab === "workOrder" && (
                  <div className="space-y-2">
                    <SettingRow
                      label="Habilitar checklist en wizard"
                      description="Paso de inspección con ítems personalizables"
                    >
                      <SwitchToggle
                        checked={settings.workOrder.enableWizardChecklist}
                        onChange={(val) => updateSetting("workOrder", "enableWizardChecklist", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar bloque de acceso/seguridad"
                      description="PIN, password y patrón del dispositivo"
                    >
                      <SwitchToggle
                        checked={settings.workOrder.showAccessBlock}
                        onChange={(val) => updateSetting("workOrder", "showAccessBlock", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Auto-abrir POS al agregar item"
                      description="Ir directo a cobrar después de añadir pieza"
                    >
                      <SwitchToggle
                        checked={settings.workOrder.autoOpenPOSOnAddItem}
                        onChange={(val) => updateSetting("workOrder", "autoOpenPOSOnAddItem", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Permitir subir fotos"
                      description="Habilitar carga de imágenes en órdenes"
                    >
                      <SwitchToggle
                        checked={settings.workOrder.allowPhotoUploads}
                        onChange={(val) => updateSetting("workOrder", "allowPhotoUploads", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Guardar fotos en"
                      description="Dónde almacenar las imágenes subidas"
                    >
                      <select
                        value={settings.workOrder.savePhotosTo}
                        onChange={(e) => updateSetting("workOrder", "savePhotosTo", e.target.value)}
                        className="px-3 py-1.5 rounded-md bg-black/40 border border-white/15 text-white text-sm"
                      >
                        <option value="attachments">Adjuntos</option>
                        <option value="comments">Comentarios</option>
                        <option value="both">Ambos</option>
                      </select>
                    </SettingRow>
                  </div>
                )}

                {activeTab === "pos" && (
                  <div className="space-y-2">
                    <SettingRow
                      label="Layout móvil optimizado"
                      description="Interfaz adaptada para tablets/teléfonos"
                    >
                      <SwitchToggle
                        checked={settings.pos.posMobileLayout}
                        onChange={(val) => updateSetting("pos", "posMobileLayout", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Permitir pagos parciales desde orden"
                      description="Abonar sin completar el total"
                    >
                      <SwitchToggle
                        checked={settings.pos.allowPartialPaymentsFromOrder}
                        onChange={(val) => updateSetting("pos", "allowPartialPaymentsFromOrder", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Auto-vincular pago a orden"
                      description="Registrar automáticamente en el historial"
                    >
                      <SwitchToggle
                        checked={settings.pos.autoAttachPaymentToOrder}
                        onChange={(val) => updateSetting("pos", "autoAttachPaymentToOrder", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar transacciones en dashboard"
                      description="Últimas ventas del día en inicio"
                    >
                      <SwitchToggle
                        checked={settings.pos.showRecentTransactionsOnDashboard}
                        onChange={(val) => updateSetting("pos", "showRecentTransactionsOnDashboard", val)}
                      />
                    </SettingRow>
                  </div>
                )}

                {activeTab === "customers" && (
                  <div className="space-y-2">
                    <SettingRow
                      label="Permitir editar cliente desde orden"
                      description="Modificar datos sin salir del trabajo"
                    >
                      <SwitchToggle
                        checked={settings.customers.allowCustomerEditFromOrder}
                        onChange={(val) => updateSetting("customers", "allowCustomerEditFromOrder", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar botón WhatsApp"
                      description="Enlace directo a conversación"
                    >
                      <SwitchToggle
                        checked={settings.customers.showCustomerWhatsAppButton}
                        onChange={(val) => updateSetting("customers", "showCustomerWhatsAppButton", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Código de país por defecto"
                      description="Prefijo telefónico predeterminado"
                    >
                      <select
                        value={settings.customers.customerDefaultCountryCode}
                        onChange={(e) => updateSetting("customers", "customerDefaultCountryCode", e.target.value)}
                        className="px-3 py-1.5 rounded-md bg-black/40 border border-white/15 text-white text-sm"
                      >
                        <option value="+1 787">+1 787 (PR)</option>
                        <option value="+1 939">+1 939 (PR)</option>
                        <option value="+1">+1 (USA)</option>
                        <option value="+52">+52 (MX)</option>
                        <option value="+34">+34 (ES)</option>
                      </select>
                    </SettingRow>
                  </div>
                )}

                {activeTab === "inventory" && (
                  <div className="space-y-2">
                    <SettingRow
                      label="Vincular servicios a inventario"
                      description="Relacionar servicios con piezas"
                    >
                      <SwitchToggle
                        checked={settings.inventory.linkServicesToInventory}
                        onChange={(val) => updateSetting("inventory", "linkServicesToInventory", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Sugerir piezas por modelo"
                      description="Autocompletar según dispositivo"
                    >
                      <SwitchToggle
                        checked={settings.inventory.showSuggestedPartsByModel}
                        onChange={(val) => updateSetting("inventory", "showSuggestedPartsByModel", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Permitir eliminar items de orden"
                      description="Botón para quitar piezas/servicios"
                    >
                      <SwitchToggle
                        checked={settings.inventory.allowDeleteItemsFromOrder}
                        onChange={(val) => updateSetting("inventory", "allowDeleteItemsFromOrder", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar badge de stock"
                      description="Indicador de disponibilidad en tiempo real"
                    >
                      <SwitchToggle
                        checked={settings.inventory.showStockBadge}
                        onChange={(val) => updateSetting("inventory", "showStockBadge", val)}
                      />
                    </SettingRow>
                  </div>
                )}

                {activeTab === "reports" && (
                  <div className="space-y-2">
                    <SettingRow
                      label="Mostrar reporte de ventas"
                      description="Acceso a estadísticas de ventas"
                    >
                      <SwitchToggle
                        checked={settings.reports.showSalesReport}
                        onChange={(val) => updateSetting("reports", "showSalesReport", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar reporte de reparaciones"
                      description="Métricas de órdenes completadas"
                    >
                      <SwitchToggle
                        checked={settings.reports.showRepairsReport}
                        onChange={(val) => updateSetting("reports", "showRepairsReport", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Mostrar reporte de empleados"
                      description="Productividad y ponches"
                    >
                      <SwitchToggle
                        checked={settings.reports.showEmployeesReport}
                        onChange={(val) => updateSetting("reports", "showEmployeesReport", val)}
                      />
                    </SettingRow>
                    <SettingRow
                      label="Rango por defecto"
                      description="Período inicial al abrir reportes"
                    >
                      <select
                        value={settings.reports.defaultReportRange}
                        onChange={(e) => updateSetting("reports", "defaultReportRange", e.target.value)}
                        className="px-3 py-1.5 rounded-md bg-black/40 border border-white/15 text-white text-sm"
                      >
                        <option value="today">Hoy</option>
                        <option value="week">Semana</option>
                        <option value="month">Mes</option>
                      </select>
                    </SettingRow>
                  </div>
                )}

                {activeTab === "employees" && (
                  <div className="space-y-4">
                    <div className="space-y-2 pb-4 border-b border-white/10">
                      <SettingRow
                        label="Permitir asignar notas a empleados"
                        description="Comentarios dirigidos a usuarios específicos"
                      >
                        <SwitchToggle
                          checked={settings.employees.allowNotesAssignToEmployees}
                          onChange={(val) => updateSetting("employees", "allowNotesAssignToEmployees", val)}
                        />
                      </SettingRow>
                      <SettingRow
                        label="Mostrar botones de ponche"
                        description="Control de entrada/salida en dashboard"
                      >
                        <SwitchToggle
                          checked={settings.employees.showPunchButtons}
                          onChange={(val) => updateSetting("employees", "showPunchButtons", val)}
                        />
                      </SettingRow>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-white">Gestión de Empleados</h3>
                        <Button
                          onClick={() => {
                            setEditingEmployee(null);
                            setShowEmployeeModal(true);
                          }}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Nuevo Empleado
                        </Button>
                      </div>

                      <div className="space-y-2">
                        {employees.map((emp) => (
                          <div
                            key={emp.id}
                            className="flex items-center justify-between p-3 bg-black/40 border border-white/10 rounded-lg"
                          >
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <p className="text-white font-medium">{emp.name}</p>
                                <Badge className={emp.active ? "bg-green-600/20 text-green-300" : "bg-gray-600/20 text-gray-300"}>
                                  {emp.active ? "Activo" : "Inactivo"}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-3 mt-1 text-xs text-gray-400">
                                {emp.email && <span>{emp.email}</span>}
                                {emp.phone && <span>• {emp.phone}</span>}
                                <span>• {emp.role}</span>
                                {emp.punch_pin && <span>• PIN: {emp.punch_pin}</span>}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingEmployee(emp);
                                  setShowEmployeeModal(true);
                                }}
                                className="border-white/15"
                              >
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteEmployee(emp.id)}
                                className="border-white/15 text-red-400 hover:text-red-300"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        ))}

                        {employees.length === 0 && (
                          <div className="text-center py-8 text-gray-500">
                            No hay empleados registrados
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "system" && (
                  <div className="space-y-2">
                    <SettingRow label="Idioma / Locale">
                      <Input
                        value={settings.system.locale}
                        onChange={(e) => updateSetting("system", "locale", e.target.value)}
                        className="w-32 bg-black/40 border-white/15 text-white"
                      />
                    </SettingRow>
                    <SettingRow
                      label="Tasa de impuesto (IVU)"
                      description="Porcentaje como decimal (ej: 0.115 = 11.5%)"
                    >
                      <Input
                        type="number"
                        step="0.001"
                        value={settings.system.taxRate}
                        onChange={(e) => updateSetting("system", "taxRate", parseFloat(e.target.value))}
                        className="w-32 bg-black/40 border-white/15 text-white"
                      />
                    </SettingRow>
                    <SettingRow label="Símbolo de moneda">
                      <Input
                        value={settings.system.currencySymbol}
                        onChange={(e) => updateSetting("system", "currencySymbol", e.target.value)}
                        className="w-20 bg-black/40 border-white/15 text-white"
                      />
                    </SettingRow>
                    <SettingRow
                      label="Nombre del negocio"
                      description="Aparece en reportes y documentos"
                    >
                      <Input
                        value={settings.system.storeName}
                        onChange={(e) => updateSetting("system", "storeName", e.target.value)}
                        className="w-64 bg-black/40 border-white/15 text-white"
                      />
                    </SettingRow>
                    <SettingRow
                      label="Ocultar nav inferior en work order"
                      description="Maximizar espacio al editar órdenes"
                    >
                      <SwitchToggle
                        checked={settings.system.hideBottomNavOnWorkOrder}
                        onChange={(val) => updateSetting("system", "hideBottomNavOnWorkOrder", val)}
                      />
                    </SettingRow>
                    <SettingRow label="Tema">
                      <select
                        value={settings.system.theme}
                        onChange={(e) => updateSetting("system", "theme", e.target.value)}
                        className="px-3 py-1.5 rounded-md bg-black/40 border border-white/15 text-white text-sm"
                      >
                        <option value="dark">Oscuro</option>
                        <option value="light">Claro</option>
                      </select>
                    </SettingRow>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <EmployeeModal
        open={showEmployeeModal}
        onClose={() => {
          setShowEmployeeModal(false);
          setEditingEmployee(null);
        }}
        onSave={handleSaveEmployee}
        employee={editingEmployee}
      />
    </div>
  );
}