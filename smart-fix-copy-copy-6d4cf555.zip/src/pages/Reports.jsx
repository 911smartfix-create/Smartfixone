
import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Download,
  Upload,
  Calendar,
  DollarSign,
  Package,
  Users,
  ClipboardList,
  TrendingUp,
  FileText,
  Filter,
  RefreshCw,
  Eye,
  Wallet
} from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, parseISO } from "date-fns";
import { es } from "date-fns/locale";

const StatCard = ({ title, value, subtitle, icon: Icon, color }) => (
  <Card className="bg-gradient-to-br from-[#2B2B2B] to-black border-white/10">
    <CardContent className="pt-6">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <p className="text-xs font-medium text-gray-400 uppercase tracking-wide">{title}</p>
          <p className={`text-2xl font-bold text-${color}-400 mt-2`}>{value}</p>
          {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
        </div>
        <div className={`p-3 rounded-xl bg-${color}-600/20 border border-${color}-500/30`}>
          <Icon className={`w-5 h-5 text-${color}-400`} />
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function Reports() {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("sales");
  
  // Filtros de fecha
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  
  // Datos
  const [sales, setSales] = useState([]);
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [timeEntries, setTimeEntries] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    loadData();
  }, [startDate, endDate]);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [salesData, ordersData, productsData, timeData, transactionsData] = await Promise.allSettled([
        base44.entities.Sale.list("-created_date", 200).catch(() => []),
        base44.entities.Order.list("-created_date", 200).catch(() => []),
        base44.entities.Product.list("-created_date", 100).catch(() => []),
        base44.entities.TimeEntry.list("-created_date", 200).catch(() => []),
        base44.entities.Transaction.list("-created_date", 200).catch(() => [])
      ]);
      
      setSales(salesData.status === "fulfilled" ? salesData.value || [] : []);
      setOrders(ordersData.status === "fulfilled" ? ordersData.value || [] : []);
      setProducts(productsData.status === "fulfilled" ? productsData.value || [] : []);
      setTimeEntries(timeData.status === "fulfilled" ? timeData.value || [] : []);
      setTransactions(transactionsData.status === "fulfilled" ? transactionsData.value || [] : []);
    } catch (error) {
      console.error("Error loading reports data:", error);
      setError("Error al cargar datos. Por favor intenta de nuevo.");
    }
    setLoading(false);
  };

  // Filtrar datos por rango de fechas
  const filterByDateRange = (items, dateField = 'created_date') => {
    return items.filter(item => {
      try {
        const itemDate = new Date(item[dateField]);
        const start = new Date(startDate);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        return itemDate >= start && itemDate <= end;
      } catch {
        return false;
      }
    });
  };

  // Datos filtrados
  const filteredSales = useMemo(() => filterByDateRange(sales.filter(s => !s.voided)), [sales, startDate, endDate]);
  const filteredOrders = useMemo(() => filterByDateRange(orders), [orders, startDate, endDate]);
  const filteredTimeEntries = useMemo(() => filterByDateRange(timeEntries, 'clock_in'), [timeEntries, startDate, endDate]);
  const filteredTransactions = useMemo(() => filterByDateRange(transactions), [transactions, startDate, endDate]);

  // Análisis de ventas
  const salesAnalysis = useMemo(() => {
    const totalRevenue = filteredSales.reduce((sum, s) => sum + (s.total || 0), 0);
    const totalTransactions = filteredSales.length;
    const avgTicket = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;
    
    const productSales = {};
    const serviceSales = {};
    
    filteredSales.forEach(sale => {
      (sale.items || []).forEach(item => {
        if (item.type === 'product') {
          if (!productSales[item.name]) {
            productSales[item.name] = { name: item.name, quantity: 0, revenue: 0 };
          }
          productSales[item.name].quantity += item.quantity || 0;
          productSales[item.name].revenue += (item.price || 0) * (item.quantity || 0);
        } else {
          if (!serviceSales[item.name]) {
            serviceSales[item.name] = { name: item.name, count: 0, revenue: 0 };
          }
          serviceSales[item.name].count += 1;
          serviceSales[item.name].revenue += (item.price || 0) * (item.quantity || 1);
        }
      });
    });
    
    const topProducts = Object.values(productSales)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);
    
    const topServices = Object.values(serviceSales)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);
    
    const paymentMethods = filteredSales.reduce((acc, s) => {
      const method = s.payment_method || 'cash';
      acc[method] = (acc[method] || 0) + (s.total || 0);
      return acc;
    }, {});
    
    return {
      totalRevenue,
      totalTransactions,
      avgTicket,
      topProducts,
      topServices,
      paymentMethods
    };
  }, [filteredSales]);

  // Análisis de órdenes
  const ordersAnalysis = useMemo(() => {
    const totalOrders = filteredOrders.length;
    const completedOrders = filteredOrders.filter(o => o.status === 'completed' || o.status === 'picked_up').length;
    const activeOrders = filteredOrders.filter(o => !['completed', 'picked_up', 'cancelled'].includes(o.status)).length;
    const cancelledOrders = filteredOrders.filter(o => o.status === 'cancelled').length;
    
    const avgRepairValue = filteredOrders.length > 0
      ? filteredOrders.reduce((sum, o) => sum + (o.cost_estimate || 0), 0) / filteredOrders.length
      : 0;
    
    const deviceTypes = filteredOrders.reduce((acc, o) => {
      const type = o.device_type || 'Unknown';
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {});
    
    const statusBreakdown = filteredOrders.reduce((acc, o) => {
      const status = o.status || 'unknown';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});
    
    return {
      totalOrders,
      completedOrders,
      activeOrders,
      cancelledOrders,
      completionRate: totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 0,
      avgRepairValue,
      deviceTypes,
      statusBreakdown
    };
  }, [filteredOrders]);

  // Análisis de inventario
  const inventoryAnalysis = useMemo(() => {
    const totalProducts = products.length;
    const totalValue = products.reduce((sum, p) => sum + (p.stock || 0) * (p.cost || 0), 0);
    const lowStock = products.filter(p => (p.stock || 0) <= (p.min_stock || 5)).length;
    const outOfStock = products.filter(p => (p.stock || 0) === 0).length;
    
    const categoryBreakdown = products.reduce((acc, p) => {
      const cat = p.category || 'other';
      acc[cat] = (acc[cat] || 0) + 1;
      return acc;
    }, {});
    
    return {
      totalProducts,
      totalValue,
      lowStock,
      outOfStock,
      categoryBreakdown
    };
  }, [products]);

  // Análisis de tiempo
  const timeAnalysis = useMemo(() => {
    const totalHours = filteredTimeEntries.reduce((sum, entry) => {
      if (entry.clock_out) {
        const hours = (new Date(entry.clock_out) - new Date(entry.clock_in)) / (1000 * 60 * 60);
        return sum + hours;
      }
      return sum;
    }, 0);
    
    const employeeHours = filteredTimeEntries.reduce((acc, entry) => {
      const name = entry.employee_name || 'Unknown';
      if (entry.clock_out) {
        const hours = (new Date(entry.clock_out) - new Date(entry.clock_in)) / (1000 * 60 * 60);
        acc[name] = (acc[name] || 0) + hours;
      }
      return acc;
    }, {});
    
    return {
      totalHours,
      totalEntries: filteredTimeEntries.length,
      employeeHours
    };
  }, [filteredTimeEntries]);

  // Exportar a CSV
  const exportToCSV = (data, filename) => {
    if (!data || data.length === 0) {
      alert("No hay datos para exportar");
      return;
    }
    
    const headers = Object.keys(data[0]).join(",");
    const rows = data.map(row => 
      Object.values(row).map(val => 
        typeof val === 'string' && val.includes(',') ? `"${val}"` : val
      ).join(",")
    );
    
    const csv = [headers, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${filename}_${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Exportar ventas
  const exportSalesReport = () => {
    const data = filteredSales.map(s => ({
      fecha: format(new Date(s.created_date), "yyyy-MM-dd HH:mm"),
      numero_venta: s.sale_number,
      cliente: s.customer_name,
      subtotal: s.subtotal,
      impuestos: s.tax_amount,
      total: s.total,
      metodo_pago: s.payment_method,
      empleado: s.employee
    }));
    exportToCSV(data, "reporte_ventas");
  };

  // Exportar órdenes
  const exportOrdersReport = () => {
    const data = filteredOrders.map(o => ({
      fecha: format(new Date(o.created_date), "yyyy-MM-dd"),
      numero_orden: o.order_number,
      cliente: o.customer_name,
      telefono: o.customer_phone,
      dispositivo: `${o.device_brand || ''} ${o.device_model || ''}`,
      problema: o.initial_problem,
      estado: o.status,
      estimado: o.cost_estimate,
      pagado: o.amount_paid,
      saldo: o.balance_due
    }));
    exportToCSV(data, "reporte_ordenes");
  };

  // Exportar inventario
  const exportInventoryReport = () => {
    const data = products.map(p => ({
      nombre: p.name,
      sku: p.sku,
      categoria: p.category,
      precio: p.price,
      costo: p.cost,
      stock: p.stock,
      stock_minimo: p.min_stock,
      activo: p.active ? "Sí" : "No"
    }));
    exportToCSV(data, "reporte_inventario");
  };

  // Exportar ponches
  const exportTimeReport = () => {
    const data = filteredTimeEntries.map(t => ({
      fecha: format(new Date(t.clock_in), "yyyy-MM-dd"),
      empleado: t.employee_name,
      entrada: t.clock_in ? format(new Date(t.clock_in), "HH:mm") : "N/A",
      salida: t.clock_out ? format(new Date(t.clock_out), "HH:mm") : "Activo",
      horas: t.clock_out ? ((new Date(t.clock_out) - new Date(t.clock_in)) / (1000 * 60 * 60)).toFixed(2) : "N/A"
    }));
    exportToCSV(data, "reporte_ponches");
  };

  // Importar desde CSV
  const handleImport = async (e, type) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result;
        const lines = text.split("\n");
        const headers = lines[0].split(",").map(h => h.trim());
        
        const data = lines.slice(1)
          .filter(line => line.trim())
          .map(line => {
            const values = line.split(",");
            const obj = {};
            headers.forEach((header, i) => {
              obj[header] = values[i]?.trim();
            });
            return obj;
          });
        
        console.log("Datos importados:", data);
        alert(`${data.length} registros importados. Funcionalidad de importación en desarrollo.`);
        
      } catch (error) {
        console.error("Error importando archivo:", error);
        alert("Error al importar el archivo. Verifique el formato.");
      }
    };
    reader.readAsText(file);
  };

  // Atajos de fecha
  const setDateRange = (range) => {
    const today = new Date();
    switch (range) {
      case "today":
        setStartDate(format(today, "yyyy-MM-dd"));
        setEndDate(format(today, "yyyy-MM-dd"));
        break;
      case "week":
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - 7);
        setStartDate(format(weekStart, "yyyy-MM-dd"));
        setEndDate(format(today, "yyyy-MM-dd"));
        break;
      case "month":
        setStartDate(format(startOfMonth(today), "yyyy-MM-dd"));
        setEndDate(format(endOfMonth(today), "yyyy-MM-dd"));
        break;
      case "last_month":
        const lastMonth = subMonths(today, 1);
        setStartDate(format(startOfMonth(lastMonth), "yyyy-MM-dd"));
        setEndDate(format(endOfMonth(lastMonth), "yyyy-MM-dd"));
        break;
      default:
        // Handle custom ranges or do nothing
        break;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D0D0D] to-[#1A1A1A] p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#FF0000] to-red-700 bg-clip-text text-transparent">
              Centro de Reportes
            </h1>
            <p className="text-gray-400 text-sm mt-1">
              Análisis detallado de ventas, órdenes, inventario y más
            </p>
          </div>
          
          <Button
            onClick={loadData}
            variant="outline"
            className="border-white/15 bg-zinc-900/60"
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Actualizar
          </Button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-900/50 border border-red-700 text-red-300 p-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        {/* Filtros de fecha */}
        <Card className="bg-[#121212] border-white/10">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 space-y-2">
                <label className="text-xs text-gray-400 uppercase">Fecha Inicio</label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="bg-black/40 border-white/15"
                />
              </div>
              
              <div className="flex-1 space-y-2">
                <label className="text-xs text-gray-400 uppercase">Fecha Fin</label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="bg-black/40 border-white/15"
                />
              </div>
              
              <div className="flex-1 space-y-2">
                <label className="text-xs text-gray-400 uppercase">Atajos</label>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => setDateRange("today")} className="border-white/15">
                    Hoy
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setDateRange("week")} className="border-white/15">
                    7 días
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setDateRange("month")} className="border-white/15">
                    Este mes
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setDateRange("last_month")} className="border-white/15">
                    Mes pasado
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-[#121212] border border-white/10">
            <TabsTrigger value="sales" className="data-[state=active]:bg-red-600">
              <DollarSign className="w-4 h-4 mr-2" />
              Ventas
            </TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-red-600">
              <ClipboardList className="w-4 h-4 mr-2" />
              Órdenes
            </TabsTrigger>
            <TabsTrigger value="inventory" className="data-[state=active]:bg-red-600">
              <Package className="w-4 h-4 mr-2" />
              Inventario
            </TabsTrigger>
            <TabsTrigger value="time" className="data-[state=active]:bg-red-600">
              <Users className="w-4 h-4 mr-2" />
              Ponches
            </TabsTrigger>
          </TabsList>

          {/* VENTAS */}
          <TabsContent value="sales" className="space-y-6">
            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <StatCard
                title="Ingresos Totales"
                value={`$${salesAnalysis.totalRevenue.toFixed(2)}`}
                subtitle={`${salesAnalysis.totalTransactions} transacciones`}
                icon={DollarSign}
                color="green"
              />
              <StatCard
                title="Ticket Promedio"
                value={`$${salesAnalysis.avgTicket.toFixed(2)}`}
                subtitle="Por transacción"
                icon={TrendingUp}
                color="blue"
              />
              <StatCard
                title="IVU Recaudado"
                value={`$${(salesAnalysis.totalRevenue * 0.115).toFixed(2)}`}
                subtitle="11.5% de ventas"
                icon={FileText}
                color="purple"
              />
            </div>

            {/* Acciones */}
            <div className="flex flex-wrap gap-3">
              <Button onClick={exportSalesReport} className="bg-red-600 hover:bg-red-700">
                <Download className="w-4 h-4 mr-2" />
                Exportar Ventas (CSV)
              </Button>
              <Button variant="outline" className="border-white/15" asChild>
                <label className="cursor-pointer">
                  <Upload className="w-4 h-4 mr-2" />
                  Importar Ventas (CSV)
                  <input
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={(e) => handleImport(e, "sales")}
                  />
                </label>
              </Button>
            </div>

            {/* Productos más vendidos */}
            <Card className="bg-[#121212] border-white/10">
              <CardHeader>
                <CardTitle>Top 10 Productos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {salesAnalysis.topProducts.map((product, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                      <div className="flex-1">
                        <p className="text-white font-medium">{product.name}</p>
                        <p className="text-xs text-gray-400">{product.quantity} unidades vendidas</p>
                      </div>
                      <Badge className="bg-green-600/20 text-green-300">
                        ${product.revenue.toFixed(2)}
                      </Badge>
                    </div>
                  ))}
                  {salesAnalysis.topProducts.length === 0 && (
                    <p className="text-gray-500 text-center py-8">No hay datos en este rango</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Servicios más vendidos */}
            <Card className="bg-[#121212] border-white/10">
              <CardHeader>
                <CardTitle>Top 10 Servicios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {salesAnalysis.topServices.map((service, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                      <div className="flex-1">
                        <p className="text-white font-medium">{service.name}</p>
                        <p className="text-xs text-gray-400">{service.count} servicios realizados</p>
                      </div>
                      <Badge className="bg-blue-600/20 text-blue-300">
                        ${service.revenue.toFixed(2)}
                      </Badge>
                    </div>
                  ))}
                  {salesAnalysis.topServices.length === 0 && (
                    <p className="text-gray-500 text-center py-8">No hay datos en este rango</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Métodos de pago */}
            <Card className="bg-[#121212] border-white/10">
              <CardHeader>
                <CardTitle>Ingresos por Método de Pago</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(salesAnalysis.paymentMethods).map(([method, amount]) => (
                    <div key={method} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                      <div className="flex items-center gap-2">
                        {method === 'cash' && <Wallet className="w-4 h-4 text-green-400" />}
                        {method === 'card' && <DollarSign className="w-4 h-4 text-blue-400" />}
                        {method === 'ath_movil' && <DollarSign className="w-4 h-4 text-purple-400" />}
                        {method === 'mixed' && <DollarSign className="w-4 h-4 text-yellow-400" />}
                        <span className="text-white capitalize">{method === 'cash' ? 'Efectivo' : method === 'card' ? 'Tarjeta' : method === 'ath_movil' ? 'ATH Móvil' : 'Mixto'}</span>
                      </div>
                      <Badge className="bg-white/10 text-white">
                        ${amount.toFixed(2)}
                      </Badge>
                    </div>
                  ))}
                  {Object.keys(salesAnalysis.paymentMethods).length === 0 && (
                    <p className="text-gray-500 text-center py-8">No hay datos en este rango</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ÓRDENES */}
          <TabsContent value="orders" className="space-y-6">
            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <StatCard
                title="Total Órdenes"
                value={ordersAnalysis.totalOrders}
                subtitle={`${ordersAnalysis.activeOrders} activas`}
                icon={ClipboardList}
                color="blue"
              />
              <StatCard
                title="Completadas"
                value={ordersAnalysis.completedOrders}
                subtitle={`${ordersAnalysis.completionRate.toFixed(1)}% tasa`}
                icon={FileText}
                color="green"
              />
              <StatCard
                title="Valor Promedio"
                value={`$${ordersAnalysis.avgRepairValue.toFixed(2)}`}
                subtitle="Por orden"
                icon={DollarSign}
                color="purple"
              />
              <StatCard
                title="Canceladas"
                value={ordersAnalysis.cancelledOrders}
                subtitle={`${((ordersAnalysis.cancelledOrders / Math.max(ordersAnalysis.totalOrders, 1)) * 100).toFixed(1)}%`}
                icon={FileText}
                color="red"
              />
            </div>

            {/* Acciones */}
            <div className="flex flex-wrap gap-3">
              <Button onClick={exportOrdersReport} className="bg-red-600 hover:bg-red-700">
                <Download className="w-4 h-4 mr-2" />
                Exportar Órdenes (CSV)
              </Button>
              <Button variant="outline" className="border-white/15" asChild>
                <label className="cursor-pointer">
                  <Upload className="w-4 h-4 mr-2" />
                  Importar Órdenes (CSV)
                  <input
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={(e) => handleImport(e, "orders")}
                  />
                </label>
              </Button>
            </div>

            {/* Por tipo de dispositivo */}
            <Card className="bg-[#121212] border-white/10">
              <CardHeader>
                <CardTitle>Órdenes por Tipo de Dispositivo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(ordersAnalysis.deviceTypes)
                    .sort(([,a], [,b]) => b - a)
                    .map(([type, count]) => (
                      <div key={type} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                        <span className="text-white capitalize">{type}</span>
                        <Badge className="bg-white/10 text-white">{count} órdenes</Badge>
                      </div>
                    ))}
                  {Object.keys(ordersAnalysis.deviceTypes).length === 0 && (
                    <p className="text-gray-500 text-center py-8">No hay datos en este rango</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Por estado */}
            <Card className="bg-[#121212] border-white/10">
              <CardHeader>
                <CardTitle>Órdenes por Estado</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(ordersAnalysis.statusBreakdown)
                    .sort(([,a], [,b]) => b - a)
                    .map(([status, count]) => (
                      <div key={status} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                        <span className="text-white capitalize">{status.replace(/_/g, ' ')}</span>
                        <Badge className="bg-white/10 text-white">{count}</Badge>
                      </div>
                    ))}
                  {Object.keys(ordersAnalysis.statusBreakdown).length === 0 && (
                    <p className="text-gray-500 text-center py-8">No hay datos en este rango</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* INVENTARIO */}
          <TabsContent value="inventory" className="space-y-6">
            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <StatCard
                title="Total Productos"
                value={inventoryAnalysis.totalProducts}
                subtitle="En catálogo"
                icon={Package}
                color="blue"
              />
              <StatCard
                title="Valor Inventario"
                value={`$${inventoryAnalysis.totalValue.toFixed(2)}`}
                subtitle="Costo total"
                icon={DollarSign}
                color="green"
              />
              <StatCard
                title="Stock Bajo"
                value={inventoryAnalysis.lowStock}
                subtitle="Requieren reorden"
                icon={FileText}
                color="yellow"
              />
              <StatCard
                title="Agotados"
                value={inventoryAnalysis.outOfStock}
                subtitle="Sin stock"
                icon={FileText}
                color="red"
              />
            </div>

            {/* Acciones */}
            <div className="flex flex-wrap gap-3">
              <Button onClick={exportInventoryReport} className="bg-red-600 hover:bg-red-700">
                <Download className="w-4 h-4 mr-2" />
                Exportar Inventario (CSV)
              </Button>
              <Button variant="outline" className="border-white/15" asChild>
                <label className="cursor-pointer">
                  <Upload className="w-4 h-4 mr-2" />
                  Importar Productos (CSV)
                  <input
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={(e) => handleImport(e, "inventory")}
                  />
                </label>
              </Button>
            </div>

            {/* Por categoría */}
            <Card className="bg-[#121212] border-white/10">
              <CardHeader>
                <CardTitle>Productos por Categoría</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(inventoryAnalysis.categoryBreakdown)
                    .sort(([,a], [,b]) => b - a)
                    .map(([category, count]) => (
                      <div key={category} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                        <span className="text-white capitalize">{category.replace(/_/g, ' ')}</span>
                        <Badge className="bg-white/10 text-white">{count} productos</Badge>
                      </div>
                    ))}
                  {Object.keys(inventoryAnalysis.categoryBreakdown).length === 0 && (
                    <p className="text-gray-500 text-center py-8">No hay productos</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* PONCHES */}
          <TabsContent value="time" className="space-y-6">
            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <StatCard
                title="Total Horas"
                value={timeAnalysis.totalHours.toFixed(1)}
                subtitle={`${timeAnalysis.totalEntries} entradas`}
                icon={Users}
                color="purple"
              />
              <StatCard
                title="Horas Promedio"
                value={(timeAnalysis.totalHours / Math.max(Object.keys(timeAnalysis.employeeHours).length, 1)).toFixed(1)}
                subtitle="Por empleado"
                icon={TrendingUp}
                color="blue"
              />
              <StatCard
                title="Empleados Activos"
                value={Object.keys(timeAnalysis.employeeHours).length}
                subtitle="Con registros"
                icon={Users}
                color="green"
              />
            </div>

            {/* Acciones */}
            <div className="flex flex-wrap gap-3">
              <Button onClick={exportTimeReport} className="bg-red-600 hover:bg-red-700">
                <Download className="w-4 h-4 mr-2" />
                Exportar Ponches (CSV)
              </Button>
              <Button variant="outline" className="border-white/15" asChild>
                <label className="cursor-pointer">
                  <Upload className="w-4 h-4 mr-2" />
                  Importar Ponches (CSV)
                  <input
                    type="file"
                    accept=".csv"
                    className="hidden"
                    onChange={(e) => handleImport(e, "time")}
                  />
                </label>
              </Button>
            </div>

            {/* Horas por empleado */}
            <Card className="bg-[#121212] border-white/10">
              <CardHeader>
                <CardTitle>Horas por Empleado</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(timeAnalysis.employeeHours)
                    .sort(([,a], [,b]) => b - a)
                    .map(([name, hours]) => (
                      <div key={name} className="flex items-center justify-between p-3 bg-black/30 rounded-lg">
                        <span className="text-white">{name}</span>
                        <Badge className="bg-white/10 text-white">{hours.toFixed(1)} hrs</Badge>
                      </div>
                    ))}
                  {Object.keys(timeAnalysis.employeeHours).length === 0 && (
                    <p className="text-gray-500 text-center py-8">No hay datos en este rango</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
